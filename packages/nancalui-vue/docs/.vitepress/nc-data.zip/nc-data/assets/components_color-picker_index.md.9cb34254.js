import{V as f}from"./framework.1c17ccd8.js";import{_ as F}from"./plugin-vue_export-helper.21dcd24c.js";import{f as w,G as x,H as B,b as d,a6 as h,V as y,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const b={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:l,createVNode:p,openBlock:c,createElementBlock:r}=f;function u(C,a){const i=l("n-color-picker");return c(),r("div",null,[p(i)])}return{render:u,...{}}}(),"render-demo-1":function(){const{toDisplayString:l,createTextVNode:p,resolveComponent:c,withCtx:r,createVNode:u,openBlock:m,createElementBlock:C}=f;function a(s,k){const _=c("n-button"),v=c("n-color-picker");return m(),C("div",null,[u(_,{variant:"common",onClick:s.isShowAlpha},{default:r(()=>[p("test showAlpha Be "+l(s.show),1)]),_:1},8,["onClick"]),u(v,{modelValue:s.color,"onUpdate:modelValue":k[0]||(k[0]=A=>s.color=A),"show-alpha":s.show},null,8,["modelValue","show-alpha"])])}const{defineComponent:i,watch:o,ref:e}=f,g=i({setup(){const s=e(!0);return{color:e("rgba(83, 199, 212, 0.72)"),isShowAlpha:()=>{s.value=!s.value},show:s}}});return{render:a,...g}}(),"render-demo-2":function(){const{resolveComponent:l,createVNode:p,openBlock:c,createElementBlock:r}=f;function u(o,e){const g=l("n-color-picker");return c(),r("div",null,[p(g,{modelValue:o.color,"onUpdate:modelValue":e[0]||(e[0]=s=>o.color=s),mode:"hex"},null,8,["modelValue"])])}const{defineComponent:m,watch:C,ref:a}=f,i=m({setup(){return{color:a("#FF6827A1")}}});return{render:u,...i}}(),"render-demo-3":function(){const{toDisplayString:l,createTextVNode:p,resolveComponent:c,withCtx:r,createVNode:u,openBlock:m,createElementBlock:C}=f;function a(s,k){const _=c("n-button"),v=c("n-color-picker");return m(),C("div",null,[u(_,{variant:"common",onClick:s.isShowAlpha},{default:r(()=>[p("test showAlpha Be "+l(s.show),1)]),_:1},8,["onClick"]),u(v,{"show-history":s.show,modelValue:s.color,"onUpdate:modelValue":k[0]||(k[0]=A=>s.color=A),mode:"hsl"},null,8,["show-history","modelValue"])])}const{defineComponent:i,watch:o,ref:e}=f,g=i({setup(){let s=e(!0);const k=()=>{s.value=!s.value};return{color:e("hsla(353, 1, 0.58, 1)"),isShowAlpha:k,show:s}}});return{render:a,...g}}(),"render-demo-4":function(){const{resolveComponent:l,createVNode:p,openBlock:c,createElementBlock:r}=f;function u(o,e){const g=l("n-color-picker");return c(),r("div",null,[p(g,{swatches:o.colors,modelValue:o.color,"onUpdate:modelValue":e[0]||(e[0]=s=>o.color=s)},null,8,["swatches","modelValue"])])}const{defineComponent:m,watch:C,ref:a}=f,i=m({setup(){const o=["#f44336","#e91e63","#9c27b0","#673ab7","#3f51b5","#2196f3","#03a9f4","#00bcd4","#009688","#4caf50"];return{color:a("rgba(155, 39, 176, 1)"),colors:o}}});return{render:u,...i}}(),"render-demo-5":function(){const{resolveComponent:l,createVNode:p,normalizeStyle:c,createElementVNode:r,withCtx:u,openBlock:m,createElementBlock:C}=f,a={style:{display:"flex",flexDirection:"column",alignItems:"center"}};function i(k,_){const v=l("n-icon"),A=l("n-color-picker");return m(),C("div",null,[p(A,{modelValue:k.color,"onUpdate:modelValue":_[0]||(_[0]=E=>k.color=E),style:{width:"20px",height:"20px"}},{default:u(({color:E,textColor:Q,formattedColor:R})=>[r("div",a,[p(v,{name:"font"}),r("div",{style:c({backgroundColor:E,height:"5px",width:"100%"})},null,4)])]),_:1},8,["modelValue"])])}const{defineComponent:o,watch:e,ref:g}=f,s=o({setup(){return{color:g("rgba(155, 39, 176, 1)")}}});return{render:i,...s}}()}},nn='{"title":"ColorPicker \u989C\u8272\u9009\u62E9\u5668","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u989C\u8272\u900F\u660E\u5EA6","slug":"\u989C\u8272\u900F\u660E\u5EA6"},{"level":3,"title":"\u989C\u8272\u6A21\u5F0F","slug":"\u989C\u8272\u6A21\u5F0F"},{"level":3,"title":"\u5386\u53F2\u989C\u8272","slug":"\u5386\u53F2\u989C\u8272"},{"level":3,"title":"\u57FA\u7840\u9762\u677F\u81EA\u5B9A\u4E49","slug":"\u57FA\u7840\u9762\u677F\u81EA\u5B9A\u4E49"},{"level":3,"title":"\u989C\u8272\u5C55\u793A\u81EA\u5B9A\u4E49","slug":"\u989C\u8272\u5C55\u793A\u81EA\u5B9A\u4E49"},{"level":3,"title":"ColorPicker \u53C2\u6570","slug":"colorpicker-\u53C2\u6570"},{"level":3,"title":"ColorPicker \u63D2\u69FD","slug":"colorpicker-\u63D2\u69FD"}],"relativePath":"components/color-picker/index.md","lastUpdated":1680156089335}',V=y('<h1 id="colorpicker-\u989C\u8272\u9009\u62E9\u5668" tabindex="-1">ColorPicker \u989C\u8272\u9009\u62E9\u5668 <a class="header-anchor" href="#colorpicker-\u989C\u8272\u9009\u62E9\u5668" aria-hidden="true">#</a></h1><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5141\u8BB8\u7528\u6237\u4F7F\u7528\u5404\u79CD\u4EA4\u4E92\u65B9\u6CD5\u6765\u9009\u62E9\u989C\u8272</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',4),D=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),S=n("h3",{id:"\u989C\u8272\u900F\u660E\u5EA6",tabindex:"-1"},[t("\u989C\u8272\u900F\u660E\u5EA6 "),n("a",{class:"header-anchor",href:"#\u989C\u8272\u900F\u660E\u5EA6","aria-hidden":"true"},"#")],-1),N=n("p",null,"\u5141\u8BB8\u7528\u6237\u52A8\u6001\u8C03\u8282\u5C55\u793A alpha \u6A21\u5F0F \u9ED8\u8BA4\u60C5\u51B5\u4E0B\u4E3A true",-1),q=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"variant"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("common"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("isShowAlpha"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("test showAlpha Be {{ show }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("color"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":show-alpha"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("show"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" watch"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" show "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" color "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'rgba(83, 199, 212, 0.72)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"isShowAlpha"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      show`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token operator"},"!"),t("show"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      color`),n("span",{class:"token punctuation"},","),t(`
      isShowAlpha`),n("span",{class:"token punctuation"},","),t(`
      show`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),P=n("h3",{id:"\u989C\u8272\u6A21\u5F0F",tabindex:"-1"},[t("\u989C\u8272\u6A21\u5F0F "),n("a",{class:"header-anchor",href:"#\u989C\u8272\u6A21\u5F0F","aria-hidden":"true"},"#")],-1),U=n("p",null,"\u8BBE\u7F6E mode \u5C55\u793A\u54CD\u5E94\u989C\u8272\u6A21\u5F0F",-1),j=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("color"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"mode"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hex"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" watch"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" color "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'#FF6827A1'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      color`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),T=n("h3",{id:"\u5386\u53F2\u989C\u8272",tabindex:"-1"},[t("\u5386\u53F2\u989C\u8272 "),n("a",{class:"header-anchor",href:"#\u5386\u53F2\u989C\u8272","aria-hidden":"true"},"#")],-1),I=n("p",null,"\u81EA\u5B9A\u4E49\u662F\u5426\u5C55\u793A\u5386\u53F2\u989C\u8272 \u9ED8\u8BA4\u60C5\u51B5\u4E0B\u4E3A true",-1),$=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"variant"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("common"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("isShowAlpha"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("test showAlpha Be {{ show }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),t(),n("span",{class:"token attr-name"},":show-history"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("show"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("color"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"mode"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hsl"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" watch"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" show "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"isShowAlpha"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      show`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token operator"},"!"),t("show"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" color "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'hsla(353, 1, 0.58, 1)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      color`),n("span",{class:"token punctuation"},","),t(`
      isShowAlpha`),n("span",{class:"token punctuation"},","),t(`
      show`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),z=n("h3",{id:"\u57FA\u7840\u9762\u677F\u81EA\u5B9A\u4E49",tabindex:"-1"},[t("\u57FA\u7840\u9762\u677F\u81EA\u5B9A\u4E49 "),n("a",{class:"header-anchor",href:"#\u57FA\u7840\u9762\u677F\u81EA\u5B9A\u4E49","aria-hidden":"true"},"#")],-1),G=n("p",null,"\u8BBE\u7F6E\u53EF\u81EA\u5B9A\u4E49\u914D\u7F6E\u7684\u57FA\u7840\u9762\u677F\u989C\u8272\u6837\u672C",-1),H=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),t(),n("span",{class:"token attr-name"},":swatches"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("colors"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("color"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" watch"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" colors "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'#f44336'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#e91e63'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#9c27b0'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#673ab7'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#3f51b5'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#2196f3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#03a9f4'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#00bcd4'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#009688'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'#4caf50'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" color "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'rgba(155, 39, 176, 1)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      color`),n("span",{class:"token punctuation"},","),t(`
      colors`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),J=n("h3",{id:"\u989C\u8272\u5C55\u793A\u81EA\u5B9A\u4E49",tabindex:"-1"},[t("\u989C\u8272\u5C55\u793A\u81EA\u5B9A\u4E49 "),n("a",{class:"header-anchor",href:"#\u989C\u8272\u5C55\u793A\u81EA\u5B9A\u4E49","aria-hidden":"true"},"#")],-1),K=n("p",null,"\u8BBE\u7F6E\u81EA\u5B9A\u4E49\u9009\u4E2D\u5C55\u793A",-1),L=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-color-picker")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("color"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 20px"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 20px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#default"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("{ color, textColor, formattedColor }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"flexDirection"),n("span",{class:"token punctuation"},":"),t(" column"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"alignItems"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-icon")]),t(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("font"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},":style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("{ backgroundColor: color, height: '5px', width: '100%' }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-color-picker")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" watch"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" color "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'rgba(155, 39, 176, 1)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      color`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),M=y('<h3 id="colorpicker-\u53C2\u6570" tabindex="-1">ColorPicker \u53C2\u6570 <a class="header-anchor" href="#colorpicker-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">mode</td><td style="text-align:left;"><code>String</code></td><td style="text-align:left;"><code>rgb</code></td><td style="text-align:left;">\u5207\u6362\u989C\u8272\u6A21\u5F0F</td><td style="text-align:left;"><a href="#%E9%A2%9C%E8%89%B2%E6%A8%A1%E5%BC%8F">\u989C\u8272\u6A21\u5F0F</a></td></tr><tr><td style="text-align:left;">dotSize</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;"><code>15</code></td><td style="text-align:left;">\u8C03\u8272\u677F\u5706\u70B9\u5927\u5C0F</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">swatches</td><td style="text-align:left;"><code>Array</code></td><td style="text-align:left;"></td><td style="text-align:left;">\u9884\u5B9A\u4E49\u6837\u672C\u9762\u677F</td><td style="text-align:left;"><a href="#%E5%9F%BA%E7%A1%80%E9%9D%A2%E6%9D%BF%E8%87%AA%E5%AE%9A%E4%B9%89">\u8272\u5757\u6837\u672C</a></td></tr><tr><td style="text-align:left;">show-alpha</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;"><code>true</code></td><td style="text-align:left;">\u662F\u5426\u5C55\u793A\u900F\u660E\u5EA6\u8FDB\u5EA6\u6761</td><td style="text-align:left;"><a href="#%E9%A2%9C%E8%89%B2%E9%80%8F%E6%98%8E%E5%BA%A6">\u900F\u660E\u5EA6\u5C55\u793A</a></td></tr><tr><td style="text-align:left;">show-history</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;"><code>true</code></td><td style="text-align:left;">\u662F\u5426\u5C55\u793A\u5386\u53F2\u989C\u8272</td><td style="text-align:left;"><a href="#%E5%8E%86%E5%8F%B2%E9%A2%9C%E8%89%B2">\u5386\u53F2\u989C\u8272\u5C55\u793A</a></td></tr><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>String</code></td><td style="text-align:left;"></td><td style="text-align:left;">\u7ED1\u5B9A\u989C\u8272 Value \u652F\u6301\uFF08hex , rgb , hsl , hsv \uFF09</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="colorpicker-\u63D2\u69FD" tabindex="-1">ColorPicker \u63D2\u69FD <a class="header-anchor" href="#colorpicker-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u63D2\u69FD\u540D</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">default</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u989C\u8272\u5C55\u793A</td></tr></tbody></table>',4);function O(l,p,c,r,u,m){const C=w("render-demo-0"),a=w("demo"),i=w("render-demo-1"),o=w("render-demo-2"),e=w("render-demo-3"),g=w("render-demo-4"),s=w("render-demo-5");return x(),B("div",null,[V,d(a,{sourceCode:`<template>
  <n-color-picker></n-color-picker>
</template>
`},{highlight:h(()=>[D]),default:h(()=>[d(C)]),_:1}),S,N,d(a,{sourceCode:`<template>
  <n-button variant="common" @click="isShowAlpha">test showAlpha Be {{ show }}</n-button>
  <n-color-picker v-model="color" :show-alpha="show"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const show = ref(true);
    const color = ref('rgba(83, 199, 212, 0.72)');
    const isShowAlpha = () => {
      show.value = !show.value;
    };
    return {
      color,
      isShowAlpha,
      show,
    };
  },
});
<\/script>
`},{highlight:h(()=>[q]),default:h(()=>[d(i)]),_:1}),P,U,d(a,{sourceCode:`<template>
  <n-color-picker v-model="color" mode="hex"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const color = ref('#FF6827A1');
    return {
      color,
    };
  },
});
<\/script>
`},{highlight:h(()=>[j]),default:h(()=>[d(o)]),_:1}),T,I,d(a,{sourceCode:`<template>
  <n-button variant="common" @click="isShowAlpha">test showAlpha Be {{ show }}</n-button>
  <n-color-picker :show-history="show" v-model="color" mode="hsl"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    let show = ref(true);
    const isShowAlpha = () => {
      show.value = !show.value;
    };
    const color = ref('hsla(353, 1, 0.58, 1)');
    return {
      color,
      isShowAlpha,
      show,
    };
  },
});
<\/script>
`},{highlight:h(()=>[$]),default:h(()=>[d(e)]),_:1}),z,G,d(a,{sourceCode:`<template>
  <n-color-picker :swatches="colors" v-model="color"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50'];
    const color = ref('rgba(155, 39, 176, 1)');
    return {
      color,
      colors,
    };
  },
});
<\/script>
`},{highlight:h(()=>[H]),default:h(()=>[d(g)]),_:1}),J,K,d(a,{sourceCode:`<template>
  <n-color-picker v-model="color" style="width: 20px; height: 20px">
    <template #default="{ color, textColor, formattedColor }">
      <div style="display: flex; flexDirection: column; alignItems: center;">
        <n-icon name="font" />
        <div :style="{ backgroundColor: color, height: '5px', width: '100%' }"></div>
      </div>
    </template>
  </n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const color = ref('rgba(155, 39, 176, 1)');
    return {
      color,
    };
  },
});
<\/script>
`},{highlight:h(()=>[L]),default:h(()=>[d(s)]),_:1}),M])}var tn=F(b,[["render",O]]);export{nn as __pageData,tn as default};
