import{V as g}from"./framework.1c17ccd8.js";import{_ as B}from"./plugin-vue_export-helper.21dcd24c.js";import{f,G as E,H as N,b as m,a6 as k,V as b,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const A={name:"component-doc",components:{"render-demo-0":function(){const{createElementVNode:s,resolveComponent:o,createVNode:c,withCtx:r,createTextVNode:d,openBlock:h,createElementBlock:p}=g,u={class:"nancalui-handle-width"},w={class:"nancalui-handle-width-left",ref:"leftNode"},v={style:{display:"flex","justify-content":"center","align-items":"center",width:"100%",height:"100%"}},y={class:"nancalui-handle-width-right",ref:"rightNode"};function F(e,a){const l=o("n-icon"),i=o("NChandleWidth");return h(),p("div",null,[s("div",u,[s("div",w,"\u5DE6\u8FB9",512),c(i,{onWidthChange:e.widthChange,bgcolor:"#333333"},{content:r(()=>[s("div",v,[c(l,{name:"like"})])]),_:1},8,["onWidthChange"]),s("div",y,"\u53F3\u8FB9",512)]),d(" ----------------------------------------------------- ")])}const{defineComponent:C,ref:D,getCurrentInstance:_}=g,x=C({setup(){const{proxy:e}=_();let a=D(220);function l(i){a.value+=i,a.value<160?a.value=160:a.value>500?a.value=500:(e.$refs.leftNode.style.setProperty("--lwidth",a.value+"px"),e.$refs.rightNode.style.setProperty("--rwidth","calc(100% - "+(a.value+15)+"px)"))}return{widthChange:l}}});return{render:F,...x}}()}},T='{"title":"HandleWidth \u5BBD\u9AD8\u62D6\u62FD\u7EC4\u4EF6","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"}],"relativePath":"components/handle-width/index.md","lastUpdated":1684218049390}',W=b('<h1 id="handlewidth-\u5BBD\u9AD8\u62D6\u62FD\u7EC4\u4EF6" tabindex="-1">HandleWidth \u5BBD\u9AD8\u62D6\u62FD\u7EC4\u4EF6 <a class="header-anchor" href="#handlewidth-\u5BBD\u9AD8\u62D6\u62FD\u7EC4\u4EF6" aria-hidden="true">#</a></h1><p>\u5BBD\u9AD8\u62D6\u62FD\u7EC4\u4EF6</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u4E00\u4E2A\u5143\u7D20\u9700\u8981\u62D6\u62FD\u52A8\u6001\u6539\u53D8\u5176\u5BBD\u5EA6\u6216\u8005\u9AD8\u5EA6\u65F6\u4F7F\u7528\uFF0C(\u9700\u914D\u5408 css \u4F7F\u7528)</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),$=n("div",null,[n("code",null,"type"),t("\u6A2A\u5411\u62D6\u62FD\u8FD8\u662F\u7EB5\u5411\u62D6\u62FD\uFF0C"),n("code",null,"hwidth"),t("\u62D6\u62FD\u5143\u7D20\u672C\u8EAB\u7684\u5BBD\u6216\u8005\u9AD8\u5EA6\uFF0C"),n("code",null,"pwidth"),t("\u5DE6\u8FB9\u5143\u7D20\u7684\u5BBD\u5EA6,"),n("code",null,"bgcolor"),t("\u62D6\u62FD\u5143\u7D20\u80CC\u666F\uFF0C"),n("code",null,"borderColor"),t("\u62D6\u62FD\u5143\u7D20\u8FB9\u6846\u989C\u8272")],-1),V=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("nancalui-handle-width"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("nancalui-handle-width-left"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("leftNode"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u5DE6\u8FB9"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("NChandleWidth")]),t(),n("span",{class:"token attr-name"},"@widthChange"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("widthChange"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"bgcolor"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("#333333"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t("100%"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t("100%")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
          `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-icon")]),t(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("like"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-icon")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("NChandleWidth")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("nancalui-handle-width-right"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("rightNode"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u53F3\u8FB9"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  -----------------------------------------------------
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" getCurrentInstance "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token punctuation"},"{"),t(" proxy "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"getCurrentInstance"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" width "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"220"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"widthChange"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"movement"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      width`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"+="),t(" movement"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("width"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"<"),t(),n("span",{class:"token number"},"160"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
        width`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"160"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"else"),t(),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("width"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},">"),t(),n("span",{class:"token number"},"500"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
        width`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"500"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"else"),t(),n("span",{class:"token punctuation"},"{"),t(`
        proxy`),n("span",{class:"token punctuation"},"."),t("$refs"),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'leftNode'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("style"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"setProperty"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'--lwidth'"),n("span",{class:"token punctuation"},","),t(" width"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token string"},"'px'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
        proxy`),n("span",{class:"token punctuation"},"."),t("$refs"),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'rightNode'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("style"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"setProperty"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'--rwidth'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'calc(100% - '"),t(),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token punctuation"},"("),t("width"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token number"},"15"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token string"},"'px)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      widthChange`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),t(),n("span",{class:"token attr-name"},"scoped"),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
$`),n("span",{class:"token property"},"leftWidth"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--lwidth"),n("span",{class:"token punctuation"},","),t(" 220px"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
$`),n("span",{class:"token property"},"rightWidth"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--rwidth"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token function"},"calc"),n("span",{class:"token punctuation"},"("),t("100% - 216px"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token selector"},".nancalui-handle-width"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 300px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),t(" 1px solid gray"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},"&-left"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" $leftWidth"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" #eff1f5"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
  `),n("span",{class:"token selector"},"&-right"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" $rightWidth"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" #ffffff"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1);function q(s,o,c,r,d,h){const p=f("render-demo-0"),u=f("demo");return E(),N("div",null,[W,m(u,{sourceCode:`<template>
  <div class="nancalui-handle-width">
    <div class="nancalui-handle-width-left" ref="leftNode">\u5DE6\u8FB9</div>
    <NChandleWidth @widthChange="widthChange" bgcolor="#333333">
      <template #content>
        <div style="display: flex;justify-content: center;align-items: center;width:100%;height:100%">
          <n-icon name="like"></n-icon>
        </div>
      </template>
    </NChandleWidth>
    <div class="nancalui-handle-width-right" ref="rightNode">\u53F3\u8FB9</div>
  </div>
  -----------------------------------------------------
</template>

<script>
import { defineComponent, ref, getCurrentInstance } from 'vue';

export default defineComponent({
  setup() {
    const { proxy } = getCurrentInstance();
    let width = ref(220);
    function widthChange(movement) {
      width.value += movement;
      if (width.value < 160) {
        width.value = 160;
      } else if (width.value > 500) {
        width.value = 500;
      } else {
        proxy.$refs['leftNode'].style.setProperty('--lwidth', width.value + 'px');
        proxy.$refs['rightNode'].style.setProperty('--rwidth', 'calc(100% - ' + (width.value + 15) + 'px)');
      }
    }
    return {
      widthChange,
    };
  },
});
<\/script>
<style scoped lang="scss">
$leftWidth: var(--lwidth, 220px);
$rightWidth: var(--rwidth, calc(100% - 216px));
.nancalui-handle-width {
  width: 100%;
  height: 300px;
  display: flex;
  border: 1px solid gray;
  &-left {
    width: $leftWidth;
    height: 100%;
    background: #eff1f5;
  }
  &-right {
    width: $rightWidth;
    height: 100%;
    background: #ffffff;
  }
}
</style>
`},{description:k(()=>[$]),highlight:k(()=>[V]),default:k(()=>[m(p)]),_:1})])}var G=B(A,[["render",q]]);export{T as __pageData,G as default};
