import{V as E}from"./framework.1c17ccd8.js";import{_ as M}from"./plugin-vue_export-helper.21dcd24c.js";import{f as P,G as q,H,b as B,a6 as v,V as z,I as t,k as a}from"./framework.1f85532f.js";import"./framework.40290dff.js";const V={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:d,resolveComponent:g,withModifiers:p,withCtx:l,createVNode:y,createElementVNode:N,openBlock:h,createElementBlock:f}=E,C={class:"edit-box"};function D(o,u){const r=g("n-button"),m=g("n-public-table");return h(),f("div",null,[N("div",null,[y(m,{ref:"publicTable1",tableHeadTitles:o.attrList1,tableData:o.dataSource1,tableHeight:o.tableHeight,isDisplayAction:!0,loading:o.loading1,actionWidth:200,pagination:o.paginationData1,onTablePageChange:o.tablePageChange1,onHandleSelectionChange:o.getSelectData1},{editor:l(({editor:e})=>[N("div",C,[y(r,{class:"has-right-border",variant:"text",onClick:p(c=>o.test1(e),["prevent"])},{default:l(()=>[d("\u89E3\u7ED1")]),_:2},1032,["onClick"]),y(r,{class:"has-right-border",variant:"text",onClick:p(c=>o.test1(e),["prevent"])},{default:l(()=>[d("\u79FB\u9664")]),_:2},1032,["onClick"]),y(r,{class:"has-right-border",variant:"text",onClick:p(c=>o.test1(e),["prevent"])},{default:l(()=>[d("\u67E5\u770B")]),_:2},1032,["onClick"])])]),_:1},8,["tableHeadTitles","tableData","tableHeight","loading","pagination","onTablePageChange","onHandleSelectionChange"])])])}const{defineComponent:i,ref:b}=E,s=i({setup(){const o=b(),u=b(!1),r=n=>{console.log(n)},m=b({pageSizes:[2,4,48],pageSize:2}),e=b(300),c=[{id:1,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob",lastName:"Thornton",gender:"Female",date:"1990/01/12"},{id:3,firstName:"ssadsa",lastName:"fdfd",date:"1990/01/11",gender:"Male"},{id:4,firstName:"ewew",lastName:"rtt",gender:"Female",date:"1990/01/12"},{id:5,firstName:"ghgh",lastName:"assa",date:"1990/01/11",gender:"Male"},{id:6,firstName:"oioi",lastName:"mnmn",gender:"Female",date:"1990/01/12"}],S=b({list:[{id:1,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob",lastName:"Thornton",gender:"Female",date:"1990/01/12"}],pageNum:1,pageSize:2,total:6});return{dataSource1:S,attrList1:[{name:"\u5BF9\u8C61\u540D\u79F0",prop:"firstName"},{name:"\u5BF9\u8C61\u7C7B\u578B",prop:"lastName"},{name:"\u521B\u5EFA\u4EBA",prop:"gender"},{name:"\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4",prop:"date"}],test1:r,loading1:u,paginationData1:m,tablePageChange1:(n,F)=>{u.value=!0;let x=(n.currentPage-1)*n.pageSize,w=n.currentPage*n.pageSize,_=c.slice(x,w);S.value={list:_,pageNum:n.currentPage,pageSize:n.pageSize,total:6},u.value=!1},publicTable1:o,getSelectData1:n=>{console.log(n)},tableHeight:e}}});return{render:D,...s}}(),"render-demo-1":function(){const{createTextVNode:d,resolveComponent:g,withCtx:p,createVNode:l,createElementVNode:y,openBlock:N,createElementBlock:h}=E,f=y("span",null,"\u6682\u65E0\u6570\u636E",-1);function C(s,o){const u=g("n-input"),r=g("n-button"),m=g("n-public-table");return N(),h("div",null,[y("div",null,[l(m,{ref:"publicTable2",tableHeadTitles:s.attrList2,tableData:s.dataSource2,isDisplayAction:!0,loading:s.loading2,isNeedSelection:!0,pagination:s.paginationData2,onTablePageChange:s.tablePageChange2,onHandleSelectionChange:s.getSelectData2},{firstName:p(({editor:e})=>[l(u,{modelValue:e.row.firstName,"onUpdate:modelValue":c=>e.row.firstName=c},{default:p(()=>[d("\u6D4B\u8BD52")]),_:2},1032,["modelValue","onUpdate:modelValue"])]),editor:p(({editor:e})=>[l(r,{type:"text",onClick:c=>s.test2(e)},{default:p(()=>[d("\u6D4B\u8BD5")]),_:2},1032,["onClick"])]),empty:p(()=>[f]),_:1},8,["tableHeadTitles","tableData","loading","pagination","onTablePageChange","onHandleSelectionChange"])])])}const{defineComponent:D,ref:i}=E,b=D({setup(){const s=i(),o=i(!1),u=k=>{console.log(k)},r=i({pageSizes:[2,4,48],pageSize:2}),m=[{id:1,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob",lastName:"Thornton",gender:"Female",date:"1990/01/12"},{id:3,firstName:"ssadsa",lastName:"fdfd",date:"1990/01/11",gender:"Male"},{id:4,firstName:"ewew",lastName:"rtt",gender:"Female",date:"1990/01/12"},{id:5,firstName:"ghgh",lastName:"assa",date:"1990/01/11",gender:"Male"},{id:6,firstName:"oioi",lastName:"mnmn",gender:"Female",date:"1990/01/12"}],e=i({list:[{id:1,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob",lastName:"Thornton",gender:"Female",date:"1990/01/12"}],pageNum:1,pageSize:2,total:6});return{dataSource2:e,attrList2:[{name:"\u5BF9\u8C61\u540D\u79F0",prop:"firstName",slot:"firstName",resizeable:!0},{name:"\u5BF9\u8C61\u7C7B\u578B",prop:"lastName"},{name:"\u521B\u5EFA\u4EBA",prop:"gender"},{name:"\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4",prop:"date"}],test2:u,loading2:o,paginationData2:r,tablePageChange2:(k,T)=>{let n=(k.currentPage-1)*k.pageSize,F=k.currentPage*k.pageSize,x=m.slice(n,F);e.value={list:x,pageNum:k.currentPage,pageSize:k.pageSize,total:6}},publicTable2:s,getSelectData2:k=>{console.log(k)}}}});return{render:C,...b}}(),"render-demo-2":function(){const{createTextVNode:d,resolveComponent:g,withCtx:p,createVNode:l,createElementVNode:y,openBlock:N,createElementBlock:h}=E,f=y("span",null,"\u6682\u65E0\u6570\u636E",-1);function C(s,o){const u=g("n-button"),r=g("n-input"),m=g("n-public-table");return N(),h("div",null,[y("div",null,[l(u,{type:"text",onClick:s.getCheckedRows,style:{"margin-bottom":"20px"}},{default:p(()=>[d("\u83B7\u53D6\u52FE\u9009\u6570\u636E")]),_:1},8,["onClick"]),l(m,{ref:"publicTable3",tableHeadTitles:s.attrList3,tableData:s.dataSource3,isDisplayAction:!0,loading:s.loading3,isNeedSelection:!0,pagination:s.paginationData3,configData:s.configData3,onTablePageChange:s.tablePageChange3,onHandleSelectionChange:s.getSelectData3},{firstName:p(({editor:e})=>[l(r,{modelValue:e.row.firstName,"onUpdate:modelValue":c=>e.row.firstName=c},{default:p(()=>[d("\u6D4B\u8BD52")]),_:2},1032,["modelValue","onUpdate:modelValue"])]),editor:p(({editor:e})=>[l(u,{type:"text",onClick:c=>s.test3(e)},{default:p(()=>[d("\u6D4B\u8BD5")]),_:2},1032,["onClick"])]),empty:p(()=>[f]),_:1},8,["tableHeadTitles","tableData","loading","pagination","configData","onTablePageChange","onHandleSelectionChange"])])])}const{defineComponent:D,ref:i}=E,b=D({setup(){const s=i(),o=i(!1),u=n=>{console.log(n)},r=i({pageSizes:[2,4,48],pageSize:2}),m=i({selectRow:[{id:1,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:5,firstName:"Mark",lastName:"Otto",date:"1990/01/11",gender:"Male"}]}),e=[{id:1,firstName:"Mark33333",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob33333",lastName:"Thornton",gender:"Female",date:"1990/01/12"},{id:3,firstName:"ssadsa",lastName:"fdfd",date:"1990/01/11",gender:"Male"},{id:4,firstName:"ewew",lastName:"rtt",gender:"Female",date:"1990/01/12"},{id:5,firstName:"ghgh",lastName:"assa",date:"1990/01/11",gender:"Male"},{id:6,firstName:"oioi",lastName:"mnmn",gender:"Female",date:"1990/01/12"}],c=i({list:[{id:1,firstName:"Mark33333",lastName:"Otto",date:"1990/01/11",gender:"Male"},{id:2,firstName:"Jacob33333",lastName:"Thornton",gender:"Female",date:"1990/01/12"}],pageNum:1,pageSize:2,total:6});return{dataSource3:c,attrList3:[{name:"\u5BF9\u8C61\u540D\u79F0",prop:"firstName",slot:"firstName",resizeable:!0},{name:"\u5BF9\u8C61\u7C7B\u578B",prop:"lastName"},{name:"\u521B\u5EFA\u4EBA",prop:"gender"},{name:"\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4",prop:"date"}],test3:u,loading3:o,paginationData3:r,tablePageChange3:(n,F)=>{let x=(n.currentPage-1)*n.pageSize,w=n.currentPage*n.pageSize,_=e.slice(x,w);c.value={list:_,pageNum:n.currentPage,pageSize:n.pageSize,total:6}},publicTable3:s,getSelectData3:(n,F)=>{console.log(n),console.log(F)},configData3:m,getCheckedRows:()=>{var F;let n=(F=s.value)==null?void 0:F.getCheckedRows();console.log(n)}}}});return{render:C,...b}}()}},X='{"title":"PublicTable \u590D\u5408 table \u7EC4\u4EF6","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u591A\u9009\u6846","slug":"\u591A\u9009\u6846"},{"level":3,"title":"\u591A\u9009\u6846\u7981\u6B62\u7F16\u8F91\u56DE\u663E\u6570\u636E","slug":"\u591A\u9009\u6846\u7981\u6B62\u7F16\u8F91\u56DE\u663E\u6570\u636E"},{"level":3,"title":"publicTable \u53C2\u6570","slug":"publictable-\u53C2\u6570"},{"level":3,"title":"Table \u4E8B\u4EF6","slug":"table-\u4E8B\u4EF6"}],"relativePath":"components/public-table/index.md","lastUpdated":1685697824935}',L=z('<h1 id="publictable-\u590D\u5408-table-\u7EC4\u4EF6" tabindex="-1">PublicTable \u590D\u5408 table \u7EC4\u4EF6 <a class="header-anchor" href="#publictable-\u590D\u5408-table-\u7EC4\u4EF6" aria-hidden="true">#</a></h1><p>\u590D\u5408 table \u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u96C6\u5408\u5206\u9875\u5668\u7FFB\u9875\u3001\u591A\u9009\u3001\u5404\u5217\u81EA\u5B9A\u4E49\u63D2\u69FD,\u5217\u5BBD\u62D6\u52A8\u5BBD\u5EA6\uFF0C\u56DE\u663E\u52FE\u9009\u6570\u636E\u7B49\u529F\u80FD\u65F6\u4F7F\u7528\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),O=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-public-table")]),a(`
      `),t("span",{class:"token attr-name"},"ref"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("publicTable1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableHeadTitles"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("attrList1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableData"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("dataSource1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableHeight"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("tableHeight"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":isDisplayAction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("true"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":loading"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("loading1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":actionWidth"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("200"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":pagination"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("paginationData1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@tablePageChange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("tablePageChange1"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@handle-selection-change"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("getSelectData1"),t("span",{class:"token punctuation"},'"')]),a(`
    `),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#editor"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("{ editor }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("div")]),a(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("edit-box"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("has-right-border"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click.prevent"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("test1(editor)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u89E3\u7ED1"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("has-right-border"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click.prevent"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("test1(editor)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u79FB\u9664"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("has-right-border"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click.prevent"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("test1(editor)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u67E5\u770B"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-public-table")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[a(`
`),t("span",{class:"token keyword"},"import"),a(),t("span",{class:"token punctuation"},"{"),a(" defineComponent"),t("span",{class:"token punctuation"},","),a(" ref "),t("span",{class:"token punctuation"},"}"),a(),t("span",{class:"token keyword"},"from"),a(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),a(`

`),t("span",{class:"token keyword"},"export"),a(),t("span",{class:"token keyword"},"default"),a(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token punctuation"},"{"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" publicTable1 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" loading1 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"test1"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"editor"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("editor"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" paginationData1 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"pageSizes"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"48"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" tableHeight "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token number"},"300"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`

    `),t("span",{class:"token keyword"},"const"),a(" allData "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"3"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ssadsa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'fdfd'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ewew'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'rtt'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ghgh'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'assa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'oioi'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'mnmn'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" dataSource1 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" attrList1 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u540D\u79F0'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'firstName'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u7C7B\u578B'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'lastName'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u521B\u5EFA\u4EBA'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'gender'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'date'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"tablePageChange1"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[a("a"),t("span",{class:"token punctuation"},","),a(" b")]),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      loading1`),t("span",{class:"token punctuation"},"."),a("value "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" starPos "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),a("a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"-"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" endPos "),t("span",{class:"token operator"},"="),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" _currentPageData "),t("span",{class:"token operator"},"="),a(" allData"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"slice"),t("span",{class:"token punctuation"},"("),a("starPos"),t("span",{class:"token punctuation"},","),a(" endPos"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`

      dataSource1`),t("span",{class:"token punctuation"},"."),a("value "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(" _currentPageData"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
      loading1`),t("span",{class:"token punctuation"},"."),a("value "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"getSelectData1"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"data"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("data"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`

    `),t("span",{class:"token keyword"},"return"),a(),t("span",{class:"token punctuation"},"{"),a(" dataSource1"),t("span",{class:"token punctuation"},","),a(" attrList1"),t("span",{class:"token punctuation"},","),a(" test1"),t("span",{class:"token punctuation"},","),a(" loading1"),t("span",{class:"token punctuation"},","),a(" paginationData1"),t("span",{class:"token punctuation"},","),a(" tablePageChange1"),t("span",{class:"token punctuation"},","),a(" publicTable1"),t("span",{class:"token punctuation"},","),a(" getSelectData1"),t("span",{class:"token punctuation"},","),a(" tableHeight "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("script")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"}),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("style")]),t("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),J=t("h3",{id:"\u591A\u9009\u6846",tabindex:"-1"},[a("\u591A\u9009\u6846 "),t("a",{class:"header-anchor",href:"#\u591A\u9009\u6846","aria-hidden":"true"},"#")],-1),R=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-public-table")]),a(`
      `),t("span",{class:"token attr-name"},"ref"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("publicTable2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableHeadTitles"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("attrList2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableData"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("dataSource2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":isDisplayAction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("true"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":loading"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("loading2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":isNeedSelection"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("true"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":pagination"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("paginationData2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@tablePageChange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("tablePageChange2"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@handle-selection-change"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("getSelectData2"),t("span",{class:"token punctuation"},'"')]),a(`
    `),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#firstName"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("{ editor }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-input")]),a(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("editor.row.firstName"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u6D4B\u8BD52"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-input")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#editor"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("{ editor }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("test2(editor)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u6D4B\u8BD5"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#empty"),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("span")]),t("span",{class:"token punctuation"},">")]),a("\u6682\u65E0\u6570\u636E"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("span")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-public-table")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[a(`
`),t("span",{class:"token keyword"},"import"),a(),t("span",{class:"token punctuation"},"{"),a(" defineComponent"),t("span",{class:"token punctuation"},","),a(" ref "),t("span",{class:"token punctuation"},"}"),a(),t("span",{class:"token keyword"},"from"),a(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),a(`

`),t("span",{class:"token keyword"},"export"),a(),t("span",{class:"token keyword"},"default"),a(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token punctuation"},"{"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" publicTable2 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" loading2 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"test2"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"editor"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("editor"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" paginationData2 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"pageSizes"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"48"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" allData "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"3"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ssadsa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'fdfd'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ewew'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'rtt'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ghgh'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'assa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'oioi'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'mnmn'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" dataSource2 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" attrList2 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u540D\u79F0'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'firstName'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"slot"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'firstName'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"resizeable"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u7C7B\u578B'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'lastName'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u521B\u5EFA\u4EBA'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'gender'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'date'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"tablePageChange2"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[a("a"),t("span",{class:"token punctuation"},","),a(" b")]),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" starPos "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),a("a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"-"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" endPos "),t("span",{class:"token operator"},"="),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" _currentPageData "),t("span",{class:"token operator"},"="),a(" allData"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"slice"),t("span",{class:"token punctuation"},"("),a("starPos"),t("span",{class:"token punctuation"},","),a(" endPos"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
      dataSource2`),t("span",{class:"token punctuation"},"."),a("value "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(" _currentPageData"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"getSelectData2"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"data"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("data"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`

    `),t("span",{class:"token keyword"},"return"),a(),t("span",{class:"token punctuation"},"{"),a(" dataSource2"),t("span",{class:"token punctuation"},","),a(" attrList2"),t("span",{class:"token punctuation"},","),a(" test2"),t("span",{class:"token punctuation"},","),a(" loading2"),t("span",{class:"token punctuation"},","),a(" paginationData2"),t("span",{class:"token punctuation"},","),a(" tablePageChange2"),t("span",{class:"token punctuation"},","),a(" publicTable2"),t("span",{class:"token punctuation"},","),a(" getSelectData2 "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("script")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"}),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("style")]),t("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),$=t("h3",{id:"\u591A\u9009\u6846\u7981\u6B62\u7F16\u8F91\u56DE\u663E\u6570\u636E",tabindex:"-1"},[a("\u591A\u9009\u6846\u7981\u6B62\u7F16\u8F91\u56DE\u663E\u6570\u636E "),t("a",{class:"header-anchor",href:"#\u591A\u9009\u6846\u7981\u6B62\u7F16\u8F91\u56DE\u663E\u6570\u636E","aria-hidden":"true"},"#")],-1),j=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("getCheckedRows"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-bottom"),t("span",{class:"token punctuation"},":"),a("20px")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),a("\u83B7\u53D6\u52FE\u9009\u6570\u636E"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-public-table")]),a(`
      `),t("span",{class:"token attr-name"},"ref"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("publicTable3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableHeadTitles"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("attrList3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":tableData"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("dataSource3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":isDisplayAction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("true"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":loading"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("loading3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":isNeedSelection"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("true"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":pagination"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("paginationData3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},":configData"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("configData3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@tablePageChange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("tablePageChange3"),t("span",{class:"token punctuation"},'"')]),a(`
      `),t("span",{class:"token attr-name"},"@handle-selection-change"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("getSelectData3"),t("span",{class:"token punctuation"},'"')]),a(`
    `),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#firstName"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("{ editor }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-input")]),a(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("editor.row.firstName"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u6D4B\u8BD52"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-input")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#editor"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("{ editor }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("n-button")]),a(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("text"),t("span",{class:"token punctuation"},'"')]),a(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),a("test3(editor)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),a("\u6D4B\u8BD5"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-button")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("template")]),a(),t("span",{class:"token attr-name"},"#empty"),t("span",{class:"token punctuation"},">")]),a(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("span")]),t("span",{class:"token punctuation"},">")]),a("\u6682\u65E0\u6570\u636E"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("span")]),t("span",{class:"token punctuation"},">")]),a(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("n-public-table")]),t("span",{class:"token punctuation"},">")]),a(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("div")]),t("span",{class:"token punctuation"},">")]),a(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("template")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[a(`
`),t("span",{class:"token keyword"},"import"),a(),t("span",{class:"token punctuation"},"{"),a(" defineComponent"),t("span",{class:"token punctuation"},","),a(" ref "),t("span",{class:"token punctuation"},"}"),a(),t("span",{class:"token keyword"},"from"),a(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),a(`

`),t("span",{class:"token keyword"},"export"),a(),t("span",{class:"token keyword"},"default"),a(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token punctuation"},"{"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" publicTable3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" loading3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"test3"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"editor"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("editor"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" paginationData3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"pageSizes"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(),t("span",{class:"token number"},"48"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`

    `),t("span",{class:"token keyword"},"const"),a(" configData3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"selectRow"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" allData "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark33333'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob33333'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"3"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ssadsa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'fdfd'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ewew'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'rtt'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'ghgh'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'assa'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'oioi'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'mnmn'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" dataSource3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token punctuation"},"["),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Mark33333'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Otto'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/11'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Male'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"{"),a(`
          `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"firstName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Jacob33333'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"lastName"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Thornton'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"gender"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'Female'"),t("span",{class:"token punctuation"},","),a(`
          `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'1990/01/12'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(" attrList3 "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"["),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u540D\u79F0'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'firstName'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"slot"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'firstName'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"resizeable"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u7C7B\u578B'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'lastName'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u521B\u5EFA\u4EBA'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'gender'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"name"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4'"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"prop"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token string"},"'date'"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"tablePageChange3"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[a("a"),t("span",{class:"token punctuation"},","),a(" b")]),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" starPos "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),a("a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"-"),a(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" endPos "),t("span",{class:"token operator"},"="),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage "),t("span",{class:"token operator"},"*"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},";"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" _currentPageData "),t("span",{class:"token operator"},"="),a(" allData"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"slice"),t("span",{class:"token punctuation"},"("),a("starPos"),t("span",{class:"token punctuation"},","),a(" endPos"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
      dataSource3`),t("span",{class:"token punctuation"},"."),a("value "),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"{"),a(`
        `),t("span",{class:"token literal-property property"},"list"),t("span",{class:"token operator"},":"),a(" _currentPageData"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageNum"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("currentPage"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"pageSize"),t("span",{class:"token operator"},":"),a(" a"),t("span",{class:"token punctuation"},"."),a("pageSize"),t("span",{class:"token punctuation"},","),a(`
        `),t("span",{class:"token literal-property property"},"total"),t("span",{class:"token operator"},":"),a(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},","),a(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"getSelectData3"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[a("data"),t("span",{class:"token punctuation"},","),a(" a")]),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("data"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("a"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token keyword"},"const"),a(),t("span",{class:"token function-variable function"},"getCheckedRows"),a(),t("span",{class:"token operator"},"="),a(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),a(),t("span",{class:"token operator"},"=>"),a(),t("span",{class:"token punctuation"},"{"),a(`
      `),t("span",{class:"token keyword"},"let"),a(" data "),t("span",{class:"token operator"},"="),a(" publicTable3"),t("span",{class:"token punctuation"},"."),a("value"),t("span",{class:"token operator"},"?."),t("span",{class:"token function"},"getCheckedRows"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),a("data"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`

    `),t("span",{class:"token keyword"},"return"),a(),t("span",{class:"token punctuation"},"{"),a(`
      dataSource3`),t("span",{class:"token punctuation"},","),a(`
      attrList3`),t("span",{class:"token punctuation"},","),a(`
      test3`),t("span",{class:"token punctuation"},","),a(`
      loading3`),t("span",{class:"token punctuation"},","),a(`
      paginationData3`),t("span",{class:"token punctuation"},","),a(`
      tablePageChange3`),t("span",{class:"token punctuation"},","),a(`
      publicTable3`),t("span",{class:"token punctuation"},","),a(`
      getSelectData3`),t("span",{class:"token punctuation"},","),a(`
      configData3`),t("span",{class:"token punctuation"},","),a(`
      getCheckedRows`),t("span",{class:"token punctuation"},","),a(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),a(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),a(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),a(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("script")]),t("span",{class:"token punctuation"},">")]),a(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),a("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"}),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),a("style")]),t("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),U=z('<h3 id="publictable-\u53C2\u6570" tabindex="-1">publicTable \u53C2\u6570 <a class="header-anchor" href="#publictable-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;"></th></tr></thead><tbody><tr><td style="text-align:left;">tableData</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">table \u6570\u636E,\u6570\u636E\u5F62\u5F0F <code>{list:[],pageNum:&#39;&#39;,pageSize:&#39;&#39;, total:&#39;&#39;} </code></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">striped</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u6591\u9A6C\u7EB9\u95F4\u9694</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">borderType</td><td style="text-align:left;"><code>String</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8868\u683C\u8FB9\u6846\u7C7B\u578B\uFF0C\u9ED8\u8BA4\u884C\u8FB9\u6846\uFF1B<code>bordered: \u5168\u8FB9\u6846\uFF1Bborderless: \u65E0\u8FB9\u6846</code>\u9694</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">isDisplayAction</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u9700\u8981\u64CD\u4F5C\u680F\u9694</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">actionWidth</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">130</td><td style="text-align:left;">\u64CD\u4F5C\u680F\u5BBD\u5EA6\uFF0C\u9ED8\u8BA4 130</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">isNeedSelection</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u9700\u8981\u591A\u9009\u6846\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">tableHeadTitles</td><td style="text-align:left;"><code>Array</code></td><td style="text-align:left;">[]</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u8868\u5934\u4FE1\u606F\uFF0Cslot \u4E3A\u5217\u81EA\u5B9A\u4E49\u63D2\u69FD\u540D\u3002\u683C\u5F0F:<code>[{name: &#39;\u6807\u9898&#39;,prop: &#39;name&#39;,slot: &#39;nameSlot&#39;}] </code></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">pagination</td><td style="text-align:left;"><code>Object</code></td><td style="text-align:left;">{}</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5206\u9875\u5668\u4FE1\u606F\uFF0C\u5185\u90E8\u9ED8\u8BA4\u8BBE\u7F6E\u4E3A <code>{ pageSizes: [12, 24, 48], layout: &#39;total,pager,sizes,jumper&#39;, currentPage: 1, pageSize: 12, maxItems: 5,size: &#39;sm&#39;}</code></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">tableHeight</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">400</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8868\u683C\u9AD8\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">maxHeight</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">null</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8868\u683C\u6700\u5927\u9AD8\u5EA6--\u6D41\u4F53\u9AD8\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">showPagination</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u9875\u7801</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">rowKey</td><td style="text-align:left;"><code>String</code></td><td style="text-align:left;">&#39;id&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u884C\u6570\u636E\u7684\u552F\u4E00\u8868\u793A\u5B57\u6BB5\u540D</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">editDisabled</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7F16\u8F91\u56DE\u663E\u65F6\uFF0C\u7981\u6B62\u7F16\u8F91\u5DF2\u5B58\u5728\u6570\u636E\u666F</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">emptyText</td><td style="text-align:left;"><code>String</code></td><td style="text-align:left;">&#39;\u6682\u65E0\u6570\u636E&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7A7A\u6570\u636E\u6587\u6848</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">loading</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C loading \u72B6\u6001</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">configData</td><td style="text-align:left;"><code>Object</code></td><td style="text-align:left;"><code>{selectRow:[]}</code></td><td style="text-align:left;">\u53EF\u9009\uFF0CconfigData.selectRow(\u6570\u7EC4) \u4E3A\u56DE\u663E\u9700\u8981\u52FE\u9009\u4E2D\u7684\u6570\u636E</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">fixHeader</td><td style="text-align:left;"><code>Boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u56FA\u5B9A\u8868\u5934\u672C</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;"></td><td style="text-align:left;"></td><td style="text-align:left;"></td><td style="text-align:left;"></td><td style="text-align:left;"></td></tr></tbody></table><h3 id="table-\u4E8B\u4EF6" tabindex="-1">Table \u4E8B\u4EF6 <a class="header-anchor" href="#table-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u56DE\u8C03\u53C2\u6570</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;"></td><td style="text-align:left;"></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">cell-click</td><td style="text-align:left;"><code>Function(obj: CellClickArg)</code></td><td style="text-align:left;">\u5355\u5143\u683C\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u5355\u5143\u683C\u4FE1\u606F</td></tr><tr><td style="text-align:left;">row-click</td><td style="text-align:left;"><code>Function(obj: RowClickArg)</code></td><td style="text-align:left;">\u67D0\u4E00\u884C\u88AB\u70B9\u51FB\u65F6\u89E6\u53D1\u8BE5\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u8BE5\u884C\u4FE1\u606F</td></tr><tr><td style="text-align:left;">handle-selection-change</td><td style="text-align:left;"><code>Function( selection, row)</code></td><td style="text-align:left;">\u52FE\u9009\u8868\u683C\u884C\u56DE\u8C03\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u8868\u683C\u6240\u6709\u9009\u4E2D\u884C\u6570\u636E\u548C\u8BE5\u884C\u4FE1\u606F</td></tr><tr><td style="text-align:left;">tablePageChange</td><td style="text-align:left;"><code>Function(data)</code></td><td style="text-align:left;">\u5206\u9875\u5668\u53D8\u5316\u8FD4\u56DE\u7684\u6570\u636E{ currentPage: &#39;&#39;,pageSize: &#39;&#39;}\u3002</td></tr><tr><td style="text-align:left;">headerIconClickFn</td><td style="text-align:left;"><code>Function()</code></td><td style="text-align:left;">\u8868\u683C\u5934\u90E8\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6</td></tr></tbody></table>',4);function W(d,g,p,l,y,N){const h=P("render-demo-0"),f=P("demo"),C=P("render-demo-1"),D=P("render-demo-2");return q(),H("div",null,[L,B(f,{sourceCode:`<template>
  <div>
    <n-public-table
      ref="publicTable1"
      :tableHeadTitles="attrList1"
      :tableData="dataSource1"
      :tableHeight="tableHeight"
      :isDisplayAction="true"
      :loading="loading1"
      :actionWidth="200"
      :pagination="paginationData1"
      @tablePageChange="tablePageChange1"
      @handle-selection-change="getSelectData1"
    >
      <template #editor="{ editor }">
        <div class="edit-box">
          <n-button class="has-right-border" variant="text" @click.prevent="test1(editor)">\u89E3\u7ED1</n-button>
          <n-button class="has-right-border" variant="text" @click.prevent="test1(editor)">\u79FB\u9664</n-button>
          <n-button class="has-right-border" variant="text" @click.prevent="test1(editor)">\u67E5\u770B</n-button>
        </div>
      </template>
    </n-public-table>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const publicTable1 = ref();
    const loading1 = ref(false);
    const test1 = (editor) => {
      console.log(editor);
    };
    const paginationData1 = ref({
      pageSizes: [2, 4, 48],
      pageSize: 2,
    });
    const tableHeight = ref(300);

    const allData = [
      {
        id: 1,
        firstName: 'Mark',
        lastName: 'Otto',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 2,
        firstName: 'Jacob',
        lastName: 'Thornton',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 3,
        firstName: 'ssadsa',
        lastName: 'fdfd',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 4,
        firstName: 'ewew',
        lastName: 'rtt',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 5,
        firstName: 'ghgh',
        lastName: 'assa',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 6,
        firstName: 'oioi',
        lastName: 'mnmn',
        gender: 'Female',
        date: '1990/01/12',
      },
    ];
    const dataSource1 = ref({
      list: [
        {
          id: 1,
          firstName: 'Mark',
          lastName: 'Otto',
          date: '1990/01/11',
          gender: 'Male',
        },
        {
          id: 2,
          firstName: 'Jacob',
          lastName: 'Thornton',
          gender: 'Female',
          date: '1990/01/12',
        },
      ],
      pageNum: 1,
      pageSize: 2,
      total: 6,
    });
    const attrList1 = [
      {
        name: '\u5BF9\u8C61\u540D\u79F0',
        prop: 'firstName',
      },
      {
        name: '\u5BF9\u8C61\u7C7B\u578B',
        prop: 'lastName',
      },
      {
        name: '\u521B\u5EFA\u4EBA',
        prop: 'gender',
      },
      {
        name: '\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4',
        prop: 'date',
      },
    ];
    const tablePageChange1 = (a, b) => {
      loading1.value = true;
      let starPos = (a.currentPage - 1) * a.pageSize;
      let endPos = a.currentPage * a.pageSize;
      let _currentPageData = allData.slice(starPos, endPos);

      dataSource1.value = {
        list: _currentPageData,
        pageNum: a.currentPage,
        pageSize: a.pageSize,
        total: 6,
      };
      loading1.value = false;
    };
    const getSelectData1 = (data) => {
      console.log(data);
    };

    return { dataSource1, attrList1, test1, loading1, paginationData1, tablePageChange1, publicTable1, getSelectData1, tableHeight };
  },
});
<\/script>

<style></style>
`},{highlight:v(()=>[O]),default:v(()=>[B(h)]),_:1}),J,B(f,{sourceCode:`<template>
  <div>
    <n-public-table
      ref="publicTable2"
      :tableHeadTitles="attrList2"
      :tableData="dataSource2"
      :isDisplayAction="true"
      :loading="loading2"
      :isNeedSelection="true"
      :pagination="paginationData2"
      @tablePageChange="tablePageChange2"
      @handle-selection-change="getSelectData2"
    >
      <template #firstName="{ editor }">
        <n-input v-model="editor.row.firstName">\u6D4B\u8BD52</n-input>
      </template>
      <template #editor="{ editor }">
        <n-button type="text" @click="test2(editor)">\u6D4B\u8BD5</n-button>
      </template>
      <template #empty>
        <span>\u6682\u65E0\u6570\u636E</span>
      </template>
    </n-public-table>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const publicTable2 = ref();
    const loading2 = ref(false);
    const test2 = (editor) => {
      console.log(editor);
    };
    const paginationData2 = ref({
      pageSizes: [2, 4, 48],
      pageSize: 2,
    });
    const allData = [
      {
        id: 1,
        firstName: 'Mark',
        lastName: 'Otto',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 2,
        firstName: 'Jacob',
        lastName: 'Thornton',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 3,
        firstName: 'ssadsa',
        lastName: 'fdfd',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 4,
        firstName: 'ewew',
        lastName: 'rtt',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 5,
        firstName: 'ghgh',
        lastName: 'assa',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 6,
        firstName: 'oioi',
        lastName: 'mnmn',
        gender: 'Female',
        date: '1990/01/12',
      },
    ];
    const dataSource2 = ref({
      list: [
        {
          id: 1,
          firstName: 'Mark',
          lastName: 'Otto',
          date: '1990/01/11',
          gender: 'Male',
        },
        {
          id: 2,
          firstName: 'Jacob',
          lastName: 'Thornton',
          gender: 'Female',
          date: '1990/01/12',
        },
      ],
      pageNum: 1,
      pageSize: 2,
      total: 6,
    });
    const attrList2 = [
      {
        name: '\u5BF9\u8C61\u540D\u79F0',
        prop: 'firstName',
        slot: 'firstName',
        resizeable: true,
      },
      {
        name: '\u5BF9\u8C61\u7C7B\u578B',
        prop: 'lastName',
      },
      {
        name: '\u521B\u5EFA\u4EBA',
        prop: 'gender',
      },
      {
        name: '\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4',
        prop: 'date',
      },
    ];
    const tablePageChange2 = (a, b) => {
      let starPos = (a.currentPage - 1) * a.pageSize;
      let endPos = a.currentPage * a.pageSize;
      let _currentPageData = allData.slice(starPos, endPos);
      dataSource2.value = {
        list: _currentPageData,
        pageNum: a.currentPage,
        pageSize: a.pageSize,
        total: 6,
      };
    };
    const getSelectData2 = (data) => {
      console.log(data);
    };

    return { dataSource2, attrList2, test2, loading2, paginationData2, tablePageChange2, publicTable2, getSelectData2 };
  },
});
<\/script>

<style></style>
`},{highlight:v(()=>[R]),default:v(()=>[B(C)]),_:1}),$,B(f,{sourceCode:`<template>
  <div>
    <n-button type="text" @click="getCheckedRows" style="margin-bottom:20px">\u83B7\u53D6\u52FE\u9009\u6570\u636E</n-button>
    <n-public-table
      ref="publicTable3"
      :tableHeadTitles="attrList3"
      :tableData="dataSource3"
      :isDisplayAction="true"
      :loading="loading3"
      :isNeedSelection="true"
      :pagination="paginationData3"
      :configData="configData3"
      @tablePageChange="tablePageChange3"
      @handle-selection-change="getSelectData3"
    >
      <template #firstName="{ editor }">
        <n-input v-model="editor.row.firstName">\u6D4B\u8BD52</n-input>
      </template>
      <template #editor="{ editor }">
        <n-button type="text" @click="test3(editor)">\u6D4B\u8BD5</n-button>
      </template>
      <template #empty>
        <span>\u6682\u65E0\u6570\u636E</span>
      </template>
    </n-public-table>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const publicTable3 = ref();
    const loading3 = ref(false);
    const test3 = (editor) => {
      console.log(editor);
    };
    const paginationData3 = ref({
      pageSizes: [2, 4, 48],
      pageSize: 2,
    });

    const configData3 = ref({
      selectRow: [
        {
          id: 1,
          firstName: 'Mark',
          lastName: 'Otto',
          date: '1990/01/11',
          gender: 'Male',
        },
        {
          id: 5,
          firstName: 'Mark',
          lastName: 'Otto',
          date: '1990/01/11',
          gender: 'Male',
        },
      ],
    });
    const allData = [
      {
        id: 1,
        firstName: 'Mark33333',
        lastName: 'Otto',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 2,
        firstName: 'Jacob33333',
        lastName: 'Thornton',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 3,
        firstName: 'ssadsa',
        lastName: 'fdfd',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 4,
        firstName: 'ewew',
        lastName: 'rtt',
        gender: 'Female',
        date: '1990/01/12',
      },
      {
        id: 5,
        firstName: 'ghgh',
        lastName: 'assa',
        date: '1990/01/11',
        gender: 'Male',
      },
      {
        id: 6,
        firstName: 'oioi',
        lastName: 'mnmn',
        gender: 'Female',
        date: '1990/01/12',
      },
    ];
    const dataSource3 = ref({
      list: [
        {
          id: 1,
          firstName: 'Mark33333',
          lastName: 'Otto',
          date: '1990/01/11',
          gender: 'Male',
        },
        {
          id: 2,
          firstName: 'Jacob33333',
          lastName: 'Thornton',
          gender: 'Female',
          date: '1990/01/12',
        },
      ],
      pageNum: 1,
      pageSize: 2,
      total: 6,
    });
    const attrList3 = [
      {
        name: '\u5BF9\u8C61\u540D\u79F0',
        prop: 'firstName',
        slot: 'firstName',
        resizeable: true,
      },
      {
        name: '\u5BF9\u8C61\u7C7B\u578B',
        prop: 'lastName',
      },
      {
        name: '\u521B\u5EFA\u4EBA',
        prop: 'gender',
      },
      {
        name: '\u5BF9\u8C61\u521B\u5EFA\u65F6\u95F4',
        prop: 'date',
      },
    ];
    const tablePageChange3 = (a, b) => {
      let starPos = (a.currentPage - 1) * a.pageSize;
      let endPos = a.currentPage * a.pageSize;
      let _currentPageData = allData.slice(starPos, endPos);
      dataSource3.value = {
        list: _currentPageData,
        pageNum: a.currentPage,
        pageSize: a.pageSize,
        total: 6,
      };
    };
    const getSelectData3 = (data, a) => {
      console.log(data);
      console.log(a);
    };
    const getCheckedRows = () => {
      let data = publicTable3.value?.getCheckedRows();
      console.log(data);
    };

    return {
      dataSource3,
      attrList3,
      test3,
      loading3,
      paginationData3,
      tablePageChange3,
      publicTable3,
      getSelectData3,
      configData3,
      getCheckedRows,
    };
  },
});
<\/script>

<style></style>
`},{highlight:v(()=>[j]),default:v(()=>[B(D)]),_:1}),U])}var Y=M(V,[["render",W]]);export{X as __pageData,Y as default};
