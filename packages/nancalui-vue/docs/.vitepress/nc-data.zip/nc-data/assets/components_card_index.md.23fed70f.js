import{V as f}from"./framework.1c17ccd8.js";import{_ as A}from"./plugin-vue_export-helper.21dcd24c.js";import{f as _,G as D,H as q,b as m,a6 as h,V as b,I as n,k as a}from"./framework.1f85532f.js";import"./framework.40290dff.js";const V={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:c,createVNode:s,createTextVNode:e,createElementVNode:t,withCtx:o,openBlock:k,createElementBlock:l}=f,p=t("span",null,"nancalui",-1),r={class:"card-block"},d=t("span",null,"12",-1),u={class:"card-block"},g=t("span",null,"8",-1),v={class:"card-block"},y=t("span",null,"8",-1);function F(C,w){const E=c("n-avatar"),i=c("n-icon"),B=c("n-card");return k(),l("div",null,[s(B,{class:"card-demo-basic"},{avatar:o(()=>[s(E,{name:"nancalui"})]),title:o(()=>[e(" nancalui Course ")]),subtitle:o(()=>[s(i,{name:"company-member"}),p]),content:o(()=>[e(" nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are basedon... ")]),actions:o(()=>[t("div",r,[s(i,{name:"like"}),d]),t("div",u,[s(i,{name:"star-o"}),g]),t("div",v,[s(i,{name:"message"}),y])]),_:1})])}return{render:F,...{}}}(),"render-demo-1":function(){const{createTextVNode:c,resolveComponent:s,withCtx:e,createVNode:t,openBlock:o,createElementBlock:k}=f;function l(r,d){const u=s("n-card"),g=s("n-col"),v=s("n-row");return o(),k("div",null,[t(v,null,{default:e(()=>[t(g,{span:8},{default:e(()=>[t(u,{shadow:"always",style:{width:"250px"}},{content:e(()=>[c(" always ")]),_:1})]),_:1}),t(g,{span:8},{default:e(()=>[t(u,{style:{width:"250px"}},{content:e(()=>[c(" hover ")]),_:1})]),_:1}),t(g,{span:8},{default:e(()=>[t(u,{shadow:"never",style:{width:"250px"}},{content:e(()=>[c(" never ")]),_:1})]),_:1})]),_:1})])}return{render:l,...{}}}(),"render-demo-2":function(){const{resolveComponent:c,createVNode:s,createTextVNode:e,createElementVNode:t,withCtx:o,openBlock:k,createElementBlock:l}=f,p=t("span",null,"nancalui",-1),r={class:"card-block"},d=t("span",null,"12",-1),u={class:"card-block"},g=t("span",null,"8",-1),v={class:"card-block"},y=t("span",null,"8",-1);function F(C,w){const E=c("n-avatar"),i=c("n-icon"),B=c("n-card");return k(),l("div",null,[s(B,{class:"card-demo-use-img",src:"https://devui.design/components/assets/image1.png"},{avatar:o(()=>[s(E,{name:"nancalui"})]),title:o(()=>[e(" nancalui Course ")]),subtitle:o(()=>[s(i,{name:"company-member"}),p]),content:o(()=>[e(" nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are basedon... ")]),actions:o(()=>[t("div",r,[s(i,{name:"like"}),d]),t("div",u,[s(i,{name:"star-o"}),g]),t("div",v,[s(i,{name:"message"}),y])]),_:1},8,["src"])])}return{render:F,...{}}}(),"render-demo-3":function(){const{resolveComponent:c,createVNode:s,createElementVNode:e,createTextVNode:t,withCtx:o,openBlock:k,createElementBlock:l}=f,p={class:"custom-avatar"},r=e("div",{class:"icon-star-o custom-star-action"},null,-1),d=e("div",{class:"action-text"},"Updated at Otc 15 16:20",-1);function u(v,y){const F=c("n-avatar"),x=c("n-icon"),C=c("n-card");return k(),l("div",null,[s(C,{class:"card-demo-custom-area",align:"spaceBetween"},{title:o(()=>[t(" nancalui Course ")]),actions:o(()=>[d,e("div",null,[s(x,{name:"like"}),s(x,{name:"more-operate"})])]),default:o(()=>[e("div",p,[s(F,{imgSrc:"http://139.9.159.225:34000/nc-data/assets/logo.png",width:48,height:48,isRound:!1}),r])]),_:1})])}return{render:u,...{}}}()}},Q='{"title":"Card \u5361\u7247","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u9634\u5F71\u6548\u679C","slug":"\u9634\u5F71\u6548\u679C"},{"level":3,"title":"\u4F7F\u7528\u56FE\u7247","slug":"\u4F7F\u7528\u56FE\u7247"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u533A\u57DF","slug":"\u81EA\u5B9A\u4E49\u533A\u57DF"},{"level":3,"title":"Card \u53C2\u6570","slug":"card-\u53C2\u6570"},{"level":3,"title":"Card \u63D2\u69FD","slug":"card-\u63D2\u69FD"},{"level":3,"title":"Card \u7C7B\u578B\u5B9A\u4E49","slug":"card-\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/card/index.md","lastUpdated":1672994787081}',N=b('<h1 id="card-\u5361\u7247" tabindex="-1">Card \u5361\u7247 <a class="header-anchor" href="#card-\u5361\u7247" aria-hidden="true">#</a></h1><p>\u901A\u7528\u5361\u7247\u5BB9\u5668\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u57FA\u7840\u5361\u7247\u5BB9\u5668\uFF0C\u5176\u4E2D\u53EF\u5305\u542B\u6587\u5B57\uFF0C\u5217\u8868\uFF0C\u56FE\u7247\uFF0C\u6BB5\u843D\uFF0C\u7528\u4E8E\u6982\u89C8\u5C55\u793A\u65F6\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),T=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-demo-basic"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#avatar"),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-avatar")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("nancalui"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-avatar")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#title"),n("span",{class:"token punctuation"},">")]),a(" nancalui Course "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#subtitle"),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-demo-icon"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("company-member"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("nancalui"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),a(`
      nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are
      basedon...
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#actions"),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("like"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("12"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("star-o"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("8"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("message"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("8"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("style")]),a(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[a(`
`),n("span",{class:"token selector"},".card-demo-basic"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`

  `),n("span",{class:"token selector"},".card-demo-icon"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-demo-icon + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-block"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token selector"},"i"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
    `),n("span",{class:"token selector"},"i + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-container"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 350px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".action-text"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),a(" #8a8e99"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("style")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),z=n("h3",{id:"\u9634\u5F71\u6548\u679C",tabindex:"-1"},[a("\u9634\u5F71\u6548\u679C "),n("a",{class:"header-anchor",href:"#\u9634\u5F71\u6548\u679C","aria-hidden":"true"},"#")],-1),I=n("p",null,"\u4F60\u53EF\u4EE5\u5B9A\u4E49\u4EC0\u4E48\u65F6\u5019\u5C55\u793A\u5361\u7247\u7684\u589E\u5F3A\u9634\u5F71\u6548\u679C\u3002",-1),S=n("p",null,"\u4F7F\u7528 shadow \u5C5E\u6027\u8BBE\u7F6E\u5361\u7247\u589E\u5F3A\u9634\u5F71\u51FA\u73B0\u7684\u65F6\u673A\u3002 \u53EF\u9009\u503C\uFF1A'always'|'hover'|'never'\uFF0C\u9ED8\u8BA4\u662F hover\u3002",-1),U=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-row")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-col")]),a(),n("span",{class:"token attr-name"},":span"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("8"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token attr-name"},"shadow"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("always"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 250px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),a(" always "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-col")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-col")]),a(),n("span",{class:"token attr-name"},":span"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("8"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 250px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),a(" hover "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-col")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-col")]),a(),n("span",{class:"token attr-name"},":span"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("8"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token attr-name"},"shadow"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("never"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 250px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),a(" never "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-col")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-row")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),$=n("h3",{id:"\u4F7F\u7528\u56FE\u7247",tabindex:"-1"},[a("\u4F7F\u7528\u56FE\u7247 "),n("a",{class:"header-anchor",href:"#\u4F7F\u7528\u56FE\u7247","aria-hidden":"true"},"#")],-1),O=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-demo-use-img"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":src"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token punctuation"},"'"),a("https://devui.design/components/assets/image1.png'"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#avatar"),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-avatar")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("nancalui"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-avatar")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#title"),n("span",{class:"token punctuation"},">")]),a(" nancalui Course "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#subtitle"),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-demo-icon"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("company-member"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("nancalui"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#content"),n("span",{class:"token punctuation"},">")]),a(`
      nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are
      basedon...
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#actions"),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("like"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("12"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("star-o"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("8"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-block"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("message"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("8"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("style")]),a(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[a(`
`),n("span",{class:"token selector"},".card-demo-use-img"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`

  `),n("span",{class:"token selector"},".icon"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".icon + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-block"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token selector"},"i"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
    `),n("span",{class:"token selector"},"i + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-container"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 350px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},"img"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"max-width"),n("span",{class:"token punctuation"},":"),a(" none"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".action-text"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),a(" #8a8e99"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("style")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),R=n("h3",{id:"\u81EA\u5B9A\u4E49\u533A\u57DF",tabindex:"-1"},[a("\u81EA\u5B9A\u4E49\u533A\u57DF "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u533A\u57DF","aria-hidden":"true"},"#")],-1),j=n("p",null,"\u901A\u8FC7 align \u53EF\u8BBE\u7F6E\u64CD\u4F5C\u533A\u57DF\u5BF9\u9F50\u65B9\u5F0F\uFF1A\u8D77\u59CB\u5BF9\u9F50\u3001\u5C3E\u90E8\u5BF9\u9F50\u3001\u62C9\u4F38\u5BF9\u9F50\u3002",-1),G=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-card")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("card-demo-custom-area"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":align"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token punctuation"},"'"),a("spaceBetween'"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("custom-avatar"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-avatar")]),a(),n("span",{class:"token attr-name"},"imgSrc"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("http://139.9.159.225:34000/nc-data/assets/logo.png"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("48"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("48"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":isRound"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("false"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-avatar")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("icon-star-o custom-star-action"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-slot:"),a("title")]),n("span",{class:"token punctuation"},">")]),a(" nancalui Course "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-slot:"),a("actions")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("action-text"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("Updated at Otc 15 16:20"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("like"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("more-operate"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-card")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("style")]),a(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[a(`
`),n("span",{class:"token selector"},".card-demo-custom-area"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`

  `),n("span",{class:"token selector"},".icon"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".icon + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-block"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token selector"},"i"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
    `),n("span",{class:"token selector"},"i + span"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"vertical-align"),n("span",{class:"token punctuation"},":"),a(" middle"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".card-container"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 350px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},"img"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"max-width"),n("span",{class:"token punctuation"},":"),a(" none"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".action-text"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),a(" #8a8e99"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token selector"},".custom-avatar"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),a(" flex"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),a(" space-between"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"margin-bottom"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token selector"},".custom-star-action"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 20px"),n("span",{class:"token punctuation"},";"),a(`
      `),n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a(" pointer"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("style")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),H=b(`<h3 id="card-\u53C2\u6570" tabindex="-1">Card \u53C2\u6570 <a class="header-anchor" href="#card-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">src</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u56FE\u7247\u8DEF\u5F84</td><td style="text-align:left;"><a href="#%E4%BD%BF%E7%94%A8%E5%9B%BE%E7%89%87">\u4F7F\u7528\u56FE\u7247</a></td></tr><tr><td style="text-align:left;">align</td><td style="text-align:left;"><a href="#ialigntype">IAlignType</a></td><td style="text-align:left;"><code>&#39;start&#39;</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u64CD\u4F5C\u533A\u57DF\u5BF9\u9F50\u65B9\u5F0F\uFF0C\u5206\u522B\u5BF9\u5E94\u8D77\u59CB\u5BF9\u9F50\uFF0C\u5C3E\u90E8\u5BF9\u9F50\uFF0C\u62C9\u4F38\u5BF9\u9F50</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%8C%BA%E5%9F%9F">\u81EA\u5B9A\u4E49\u533A\u57DF</a></td></tr><tr><td style="text-align:left;">shadow</td><td style="text-align:left;"><a href="#ishadowtype">IShadowType</a></td><td style="text-align:left;"><code>&#39;hover&#39;</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u589E\u5F3A\u9634\u5F71\u663E\u793A\u65F6\u673A</td><td style="text-align:left;"><a href="#%E9%98%B4%E5%BD%B1%E6%95%88%E6%9E%9C">\u9634\u5F71\u6548\u679C</a></td></tr></tbody></table><h3 id="card-\u63D2\u69FD" tabindex="-1">Card \u63D2\u69FD <a class="header-anchor" href="#card-\u63D2\u69FD" aria-hidden="true">#</a></h3><p>\u4E24\u79CD\u65B9\u5F0F\u4F7F\u7528\uFF1A<code>v-slot:title</code> \u6216\u8005\u5177\u540D\u63D2\u69FD<code>#title</code></p><table><thead><tr><th style="text-align:left;">\u540D\u79F0</th><th style="text-align:left;">\u63CF\u8FF0</th></tr></thead><tbody><tr><td style="text-align:left;">avatar</td><td style="text-align:left;">\u5934\u50CF\u533A\u57DF\uFF0C\u7528\u4F5C\u5934\u50CF\u7B49\u56FE\u7247\u5C55\u793A</td></tr><tr><td style="text-align:left;">title</td><td style="text-align:left;">\u5361\u7247\u7684\u4E3B\u8981\u5185\u5BB9\u63CF\u8FF0\uFF0C\u4E00\u822C\u5B9A\u4E49\u4E3A\u5361\u7247\u540D\u79F0</td></tr><tr><td style="text-align:left;">subtitle</td><td style="text-align:left;">\u5BF9\u6807\u9898\u7684\u8865\u5145\uFF0C\u53EF\u5305\u542B\u6807\u7B7E\u7B49\u4FE1\u606F</td></tr><tr><td style="text-align:left;">actions</td><td style="text-align:left;">\u51B3\u7B56\u4F5C\u7528\uFF0C\u53EF\u4EE5\u5305\u542B\u64CD\u4F5C\u6587\u672C\u6216\u8005\u64CD\u4F5C\u56FE\u6807</td></tr></tbody></table><h3 id="card-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">Card \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#card-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="ialigntype" tabindex="-1">IAlignType <a class="header-anchor" href="#ialigntype" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">IAlignType</span> <span class="token operator">=</span> <span class="token string">&#39;start&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;end&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;spaceBetween&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="ishadowtype" tabindex="-1">IShadowType <a class="header-anchor" href="#ishadowtype" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">IShadowType</span> <span class="token operator">=</span> <span class="token string">&#39;always&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;hover&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;never&#39;</span><span class="token punctuation">;</span>
</code></pre></div>`,10);function P(c,s,e,t,o,k){const l=_("render-demo-0"),p=_("demo"),r=_("render-demo-1"),d=_("render-demo-2"),u=_("render-demo-3");return D(),q("div",null,[N,m(p,{sourceCode:`<template>
  <n-card class="card-demo-basic">
    <template #avatar>
      <n-avatar name="nancalui"></n-avatar>
    </template>
    <template #title> nancalui Course </template>
    <template #subtitle class="card-demo-icon"> <n-icon name="company-member"></n-icon><span>nancalui</span> </template>
    <template #content>
      nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are
      basedon...
    </template>
    <template #actions>
      <div class="card-block"><n-icon name="like"></n-icon><span>12</span></div>
      <div class="card-block"><n-icon name="star-o"></n-icon><span>8</span></div>
      <div class="card-block"><n-icon name="message"></n-icon><span>8</span></div>
    </template>
  </n-card>
</template>
<style lang="scss">
.card-demo-basic {
  cursor: pointer;

  .card-demo-icon {
    cursor: pointer;
    font-size: 16px;
    margin-right: 8px;
    vertical-align: middle;
  }
  .card-demo-icon + span {
    vertical-align: middle;
  }
  .card-block {
    margin-right: 16px;
    i {
      cursor: pointer;
      font-size: 16px;
      margin-right: 8px;
      vertical-align: middle;
    }
    i + span {
      vertical-align: middle;
    }
  }
  .card-container {
    width: 350px;
  }
  .action-text {
    color: #8a8e99;
  }
}
</style>
`},{highlight:h(()=>[T]),default:h(()=>[m(l)]),_:1}),z,I,S,m(p,{sourceCode:`<template>
  <n-row>
    <n-col :span="8">
      <n-card shadow="always" style="width: 250px">
        <template #content> always </template>
      </n-card>
    </n-col>
    <n-col :span="8">
      <n-card style="width: 250px">
        <template #content> hover </template>
      </n-card>
    </n-col>
    <n-col :span="8">
      <n-card shadow="never" style="width: 250px">
        <template #content> never </template>
      </n-card>
    </n-col>
  </n-row>
</template>
`},{highlight:h(()=>[U]),default:h(()=>[m(r)]),_:1}),$,m(p,{sourceCode:`<template>
  <n-card class="card-demo-use-img" :src="'https://devui.design/components/assets/image1.png'">
    <template #avatar>
      <n-avatar name="nancalui"></n-avatar>
    </template>
    <template #title> nancalui Course </template>
    <template #subtitle class="card-demo-icon"> <n-icon name="company-member"></n-icon><span>nancalui</span> </template>
    <template #content>
      nancalui is a free open-source and common solution for the front end of enterprise mid- and back-end products. Its design values are
      basedon...
    </template>
    <template #actions>
      <div class="card-block"><n-icon name="like"></n-icon><span>12</span></div>
      <div class="card-block"><n-icon name="star-o"></n-icon><span>8</span></div>
      <div class="card-block"><n-icon name="message"></n-icon><span>8</span></div>
    </template>
  </n-card>
</template>
<style lang="scss">
.card-demo-use-img {
  cursor: pointer;

  .icon {
    cursor: pointer;
    font-size: 16px;
    margin-right: 8px;
    vertical-align: middle;
  }
  .icon + span {
    vertical-align: middle;
  }
  .card-block {
    margin-right: 16px;
    i {
      cursor: pointer;
      font-size: 16px;
      margin-right: 8px;
      vertical-align: middle;
    }
    i + span {
      vertical-align: middle;
    }
  }
  .card-container {
    width: 350px;
  }
  img {
    max-width: none;
  }
  .action-text {
    color: #8a8e99;
  }
}
</style>
`},{highlight:h(()=>[O]),default:h(()=>[m(d)]),_:1}),R,j,m(p,{sourceCode:`<template>
  <n-card class="card-demo-custom-area" :align="'spaceBetween'">
    <div class="custom-avatar">
      <n-avatar imgSrc="http://139.9.159.225:34000/nc-data/assets/logo.png" :width="48" :height="48" :isRound="false"></n-avatar>
      <div class="icon-star-o custom-star-action"></div>
    </div>
    <template v-slot:title> nancalui Course </template>
    <template v-slot:actions>
      <div class="action-text">Updated at Otc 15 16:20</div>
      <div>
        <n-icon name="like"></n-icon>
        <n-icon name="more-operate"></n-icon>
      </div>
    </template>
  </n-card>
</template>
<style lang="scss">
.card-demo-custom-area {
  cursor: pointer;

  .icon {
    cursor: pointer;
    font-size: 16px;
    margin-right: 8px;
    vertical-align: middle;
  }
  .icon + span {
    vertical-align: middle;
  }
  .card-block {
    margin-right: 16px;
    i {
      cursor: pointer;
      font-size: 16px;
      margin-right: 8px;
      vertical-align: middle;
    }
    i + span {
      vertical-align: middle;
    }
  }
  .card-container {
    width: 350px;
  }
  img {
    max-width: none;
  }
  .action-text {
    color: #8a8e99;
  }
  .custom-avatar {
    display: flex;
    justify-content: space-between;
    margin-bottom: 16px;
    .custom-star-action {
      font-size: 20px;
      cursor: pointer;
    }
  }
}
</style>
`},{highlight:h(()=>[G]),default:h(()=>[m(u)]),_:1}),H])}var W=A(V,[["render",P]]);export{Q as __pageData,W as default};
