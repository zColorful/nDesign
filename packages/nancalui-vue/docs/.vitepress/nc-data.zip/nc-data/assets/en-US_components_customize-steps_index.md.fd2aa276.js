import{V as v}from"./framework.1c17ccd8.js";import{_ as B}from"./plugin-vue_export-helper.21dcd24c.js";import{f as x,G as y,H as b,b as f,a6 as r,V as w,I as n,k as s}from"./framework.1f85532f.js";import"./framework.40290dff.js";const h={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:o,createVNode:a,createTextVNode:e,withCtx:u,createElementVNode:p,openBlock:d,createElementBlock:c}=v,l={class:"out-box-steps"},E={class:"box"};function F(t,i){const g=o("n-customize-steps"),k=o("n-button");return d(),c("div",null,[p("div",l,[a(g,{ref:"customizeSteps",stepsData:t.stepsData,nowIndex:t.nowIndex},null,8,["stepsData","nowIndex"]),p("div",E,[a(k,{variant:"solid",color:"primary",onClick:t.goNext},{default:u(()=>[e("\u4E0B\u4E00\u6B65")]),_:1},8,["onClick"]),a(k,{color:"primary",onClick:t.goPrev},{default:u(()=>[e("\u4E0A\u4E00\u6B65")]),_:1},8,["onClick"])])])])}const{defineComponent:_,ref:m}=v,A=_({setup(){const t=m(0),i=m([{label:"\u57FA\u7840\u4FE1\u606F"},{label:"\u5173\u8054\u6570\u636E\u6E90"},{label:"\u6388\u6743\u4EBA\u5458"},{label:"\u6838\u5BF9\u4FE1\u606F"}]);return{nowIndex:t,stepsData:i,goNext:()=>{t.value>=i.value.length-1||t.value++},goPrev:()=>{t.value<=0||t.value--}}}});return{render:F,...A}}()}},S='{"title":"CustomizeSteps \u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"}],"relativePath":"en-US/components/customize-steps/index.md","lastUpdated":1675667989288}',C=w('<h1 id="customizesteps-\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761" tabindex="-1">CustomizeSteps \u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761 <a class="header-anchor" href="#customizesteps-\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761" aria-hidden="true">#</a></h1><p>\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u65B0\u5EFA\u4EFB\u52A1\u5177\u6709\u660E\u786E\u7684\u5148\u540E\u6B65\u9AA4\u6B21\u5E8F\u65F6\u4F7F\u7528\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),D=n("div",null,[n("code",null,"stepsData"),s("\u6B65\u9AA4\u6761\u6587\u672C\u63CF\u8FF0"),n("code",null,"nowIndex"),s("\u5F53\u524D\u6B65\u9AA4\u6761\u8FDB\u5EA6"),n("code",null,"icon"),s("\u5B8C\u6210\u6B65\u51D1\u5C55\u793A\u56FE\u6807\u540D"),n("code",null,"iconClass"),s("\u7ED9\u56FE\u6807\u65B0\u589E\u7C7B\u540D\u3002")],-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("div")]),s(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("out-box-steps"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-customize-steps")]),s(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("customizeSteps"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},":stepsData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("stepsData"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},":nowIndex"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("nowIndex"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token punctuation"},"/>")]),s(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("div")]),s(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("box"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-button")]),s(),n("span",{class:"token attr-name"},"variant"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("solid"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"color"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("primary"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("goNext"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s("\u4E0B\u4E00\u6B65"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-button")]),n("span",{class:"token punctuation"},">")]),s(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-button")]),s(),n("span",{class:"token attr-name"},"color"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("primary"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("goPrev"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s("\u4E0A\u4E00\u6B65"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-button")]),n("span",{class:"token punctuation"},">")]),s(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("div")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("div")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" defineComponent"),n("span",{class:"token punctuation"},","),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" nowIndex "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" stepsData "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),s(`
      `),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u57FA\u7840\u4FE1\u606F'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u5173\u8054\u6570\u636E\u6E90'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u6388\u6743\u4EBA\u5458'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"{"),s(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),s(),n("span",{class:"token string"},"'\u6838\u5BF9\u4FE1\u606F'"),n("span",{class:"token punctuation"},","),s(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(),n("span",{class:"token function-variable function"},"goNext"),s(),n("span",{class:"token operator"},"="),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
      `),n("span",{class:"token keyword"},"if"),s(),n("span",{class:"token punctuation"},"("),s("nowIndex"),n("span",{class:"token punctuation"},"."),s("value "),n("span",{class:"token operator"},">="),s(" stepsData"),n("span",{class:"token punctuation"},"."),s("value"),n("span",{class:"token punctuation"},"."),s("length "),n("span",{class:"token operator"},"-"),s(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token keyword"},"return"),n("span",{class:"token punctuation"},";"),s(`
      nowIndex`),n("span",{class:"token punctuation"},"."),s("value"),n("span",{class:"token operator"},"++"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(),n("span",{class:"token function-variable function"},"goPrev"),s(),n("span",{class:"token operator"},"="),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
      `),n("span",{class:"token keyword"},"if"),s(),n("span",{class:"token punctuation"},"("),s("nowIndex"),n("span",{class:"token punctuation"},"."),s("value "),n("span",{class:"token operator"},"<="),s(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token keyword"},"return"),n("span",{class:"token punctuation"},";"),s(`
      nowIndex`),n("span",{class:"token punctuation"},"."),s("value"),n("span",{class:"token operator"},"--"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      nowIndex`),n("span",{class:"token punctuation"},","),s(`
      stepsData`),n("span",{class:"token punctuation"},","),s(`
      goNext`),n("span",{class:"token punctuation"},","),s(`
      goPrev`),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[s(`
`),n("span",{class:"token selector"},".box"),s(),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),s(" flex"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),s(" flex-end"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token property"},"margin"),n("span",{class:"token punctuation"},":"),s(" 10px"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token selector"},"button"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token property"},"margin-left"),n("span",{class:"token punctuation"},":"),s(" 10px"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),s(`
`),n("span",{class:"token punctuation"},"}"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("style")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1);function N(o,a,e,u,p,d){const c=x("render-demo-0"),l=x("demo");return y(),b("div",null,[C,f(l,{sourceCode:`<template>
  <div class="out-box-steps">
    <n-customize-steps ref="customizeSteps" :stepsData="stepsData" :nowIndex="nowIndex" />
    <div class="box">
      <n-button variant="solid" color="primary" @click="goNext">\u4E0B\u4E00\u6B65</n-button>
      <n-button color="primary" @click="goPrev">\u4E0A\u4E00\u6B65</n-button>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const nowIndex = ref(0);
    const stepsData = ref([
      {
        label: '\u57FA\u7840\u4FE1\u606F',
      },
      {
        label: '\u5173\u8054\u6570\u636E\u6E90',
      },
      {
        label: '\u6388\u6743\u4EBA\u5458',
      },
      {
        label: '\u6838\u5BF9\u4FE1\u606F',
      },
    ]);
    const goNext = () => {
      if (nowIndex.value >= stepsData.value.length - 1) return;
      nowIndex.value++;
    };
    const goPrev = () => {
      if (nowIndex.value <= 0) return;
      nowIndex.value--;
    };
    return {
      nowIndex,
      stepsData,
      goNext,
      goPrev,
    };
  },
});
<\/script>
<style>
.box {
  display: flex;
  justify-content: flex-end;
  margin: 10px;
  button {
    margin-left: 10px;
  }
}
</style>
`},{description:r(()=>[D]),highlight:r(()=>[I]),default:r(()=>[f(c)]),_:1})])}var $=B(h,[["render",N]]);export{S as __pageData,$ as default};
