import{V as g}from"./framework.1c17ccd8.js";import{_ as y}from"./plugin-vue_export-helper.21dcd24c.js";import{f as b,G as v,H as A,b as k,a6 as d,V as _,I as n,k as a}from"./framework.1f85532f.js";import"./framework.40290dff.js";const D={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:e,resolveComponent:c,withCtx:t,createVNode:s,createElementVNode:p,openBlock:r,createElementBlock:l}=g,o=p("a",{href:"/"},"Nancal UI",-1),u=p("span",null,"Breadcrumb",-1);function m(C,f){const h=c("n-breadcrumb-item"),E=c("n-breadcrumb");return r(),l("div",null,[s(E,null,{default:t(()=>[s(h,{to:"{ path: '/' }"},{default:t(()=>[e("Homepage")]),_:1}),s(h,null,{default:t(()=>[o]),_:1}),s(h,null,{default:t(()=>[u]),_:1})]),_:1})])}return{render:m,...{}}}(),"render-demo-1":function(){const{resolveComponent:e,createVNode:c,openBlock:t,createElementBlock:s}=g;function p(u,m){const i=e("n-breadcrumb");return t(),s("div",null,[c(i,{source:u.source},null,8,["source"])])}const{defineComponent:r,reactive:l}=g,o=r({name:"DBreadcrumbDemoSourceConfig",setup(){return{source:l([{title:"Nancal UI",link:"/",linkType:"routerLink",replace:!0},{title:"Breadcrumb",link:"components/breadcrumb/",noNavigation:!0}])}}});return{render:p,...o}}(),"render-demo-2":function(){const{createElementVNode:e,resolveComponent:c,withCtx:t,createVNode:s,openBlock:p,createElementBlock:r}=g,l=e("a",{routerLink:"/components/zh-cn/get-start"},"Nancal UI",-1),o=e("span",null,"Breadcrumb",-1),u=e("span",{style:{color:"red"}},">",-1),m=e("a",{routerLink:"/components/zh-cn/get-start"},"Nancal UI",-1),i=e("span",null,"Breadcrumb",-1);function C(h,E){const F=c("n-breadcrumb-item"),B=c("n-breadcrumb");return p(),r("div",null,[e("div",null,[s(B,{"separator-icon":">"},{default:t(()=>[s(F,null,{default:t(()=>[l]),_:1}),s(F,null,{default:t(()=>[o]),_:1})]),_:1})]),e("div",null,[s(B,null,{separatorIcon:t(()=>[u]),default:t(()=>[s(F,null,{default:t(()=>[m]),_:1}),s(F,null,{default:t(()=>[i]),_:1})]),_:1})])])}return{render:C,...{}}}(),"render-demo-3":function(){const{resolveComponent:e,createVNode:c,openBlock:t,createElementBlock:s}=g;function p(u,m){const i=e("n-breadcrumb");return t(),s("div",null,[c(i,{source:u.source},null,8,["source"])])}const{defineComponent:r,reactive:l}=g,o=r({name:"DBreadcrumbDemoDropdown",setup(){return{source:l([{title:"Homepage",link:"/",linkType:"routerLink",replace:!0},{title:"Nancal UI",link:"/",noNavigation:!0},{title:"breadcrumb",showMenu:!0,link:"/components/breadcrumb/",target:"_blank",children:[{title:"\u57FA\u7840\u9762\u5305\u5C51",link:"/components/breadcrumb/#\u57FA\u7840\u9762\u5305\u5C51"},{title:"\u4F20\u5165source"},{title:"\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51"}]}])}}});return{render:p,...o}}()}},j='{"title":"Breadcrumb \u9762\u5305\u5C51","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u7840\u9762\u5305\u5C51","slug":"\u57FA\u7840\u9762\u5305\u5C51"},{"level":3,"title":"\u4F20\u5165 source","slug":"\u4F20\u5165-source"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51","slug":"\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51"},{"level":3,"title":"\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51","slug":"\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51"},{"level":3,"title":"Breadcrumb \u53C2\u6570","slug":"breadcrumb-\u53C2\u6570"},{"level":3,"title":"BreadcrumbItem \u53C2\u6570","slug":"breadcrumbitem-\u53C2\u6570"},{"level":3,"title":"\u7C7B\u578B\u5B9A\u4E49","slug":"\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/breadcrumb/index.md","lastUpdated":1672994787080}',x=_('<h1 id="breadcrumb-\u9762\u5305\u5C51" tabindex="-1">Breadcrumb \u9762\u5305\u5C51 <a class="header-anchor" href="#breadcrumb-\u9762\u5305\u5C51" aria-hidden="true">#</a></h1><p>\u663E\u793A\u5F53\u524D\u9875\u9762\u5C42\u7EA7\u7684\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><ol><li>\u7528\u6237\u9700\u8981\u4E86\u89E3\u5F53\u524D\u51FA\u4E8E\u4EC0\u4E48\u5C42\u7EA7\u65F6\uFF1B</li><li>\u7528\u6237\u9700\u8981\u5FEB\u901F\u8FD4\u56DE\u4E4B\u524D\u7684\u5C42\u7EA7\u65F6\uFF1B</li><li>\u7528\u6237\u9700\u8981\u5BFC\u822A\u81F3\u4E0E\u6307\u5B9A\u5C42\u7EA7\u76F8\u540C\u7684\u4EFB\u610F\u9875\u9762\u65F6\u3002</li></ol><h3 id="\u57FA\u7840\u9762\u5305\u5C51" tabindex="-1">\u57FA\u7840\u9762\u5305\u5C51 <a class="header-anchor" href="#\u57FA\u7840\u9762\u5305\u5C51" aria-hidden="true">#</a></h3>',5),N=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),a(),n("span",{class:"token attr-name"},"to"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("{ path: '/' }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("Homepage"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("a")]),a(),n("span",{class:"token attr-name"},"href"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("/"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("Nancal UI"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("a")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("Breadcrumb"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),w=n("h3",{id:"\u4F20\u5165-source",tabindex:"-1"},[a("\u4F20\u5165 source "),n("a",{class:"header-anchor",href:"#\u4F20\u5165-source","aria-hidden":"true"},"#")],-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb")]),a(),n("span",{class:"token attr-name"},":source"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("source"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" reactive "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'DBreadcrumbDemoSourceConfig'"),n("span",{class:"token punctuation"},","),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" source "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'Nancal UI'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'/'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"linkType"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'routerLink'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"replace"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'Breadcrumb'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'components/breadcrumb/'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"noNavigation"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      source`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),V=n("h3",{id:"\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51",tabindex:"-1"},[a("\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51 "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51","aria-hidden":"true"},"#")],-1),L=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb")]),a(),n("span",{class:"token attr-name"},"separator-icon"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a(">"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("a")]),a(),n("span",{class:"token attr-name"},"routerLink"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("/components/zh-cn/get-start"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("Nancal UI"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("a")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("Breadcrumb"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-slot:"),a("separatorIcon")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),a(" red")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(">"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("a")]),a(),n("span",{class:"token attr-name"},"routerLink"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("/components/zh-cn/get-start"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("Nancal UI"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("a")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),n("span",{class:"token punctuation"},">")]),a("Breadcrumb"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb-item")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),U=n("h3",{id:"\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51",tabindex:"-1"},[a("\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51 "),n("a",{class:"header-anchor",href:"#\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51","aria-hidden":"true"},"#")],-1),T=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-breadcrumb")]),a(),n("span",{class:"token attr-name"},":source"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("source"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-breadcrumb")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" reactive "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'DBreadcrumbDemoDropdown'"),n("span",{class:"token punctuation"},","),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" source "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'Homepage'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'/'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"linkType"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'routerLink'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"replace"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'Nancal UI'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'/'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token literal-property property"},"noNavigation"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'breadcrumb'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"showMenu"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'/components/breadcrumb/'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"target"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'_blank'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u57FA\u7840\u9762\u5305\u5C51'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"link"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'/components/breadcrumb/#\u57FA\u7840\u9762\u5305\u5C51'"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4F20\u5165source'"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51'"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      source`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),q=_(`<h3 id="breadcrumb-\u53C2\u6570" tabindex="-1">Breadcrumb \u53C2\u6570 <a class="header-anchor" href="#breadcrumb-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">separator-icon</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;/&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u6837\u5F0F</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%88%86%E9%9A%94%E7%AC%A6%E7%9A%84%E9%9D%A2%E5%8C%85%E5%B1%91">\u81EA\u5B9A\u4E49\u5206\u9694\u7B26\u7684\u9762\u5305\u5C51</a></td></tr><tr><td style="text-align:left;">source</td><td style="text-align:left;"><a href="#sourceconfig">SourceConfig[]</a></td><td style="text-align:left;">[]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u9762\u5305\u5C51\u6839\u636E\u914D\u7F6E\u7684 source \u6309\u7167\u9ED8\u8BA4\u6E32\u67D3\u65B9\u5F0F\u663E\u793A</td><td style="text-align:left;"><a href="#%E4%BC%A0%E5%85%A5source">\u4F20\u5165 source</a></td></tr></tbody></table><h3 id="breadcrumbitem-\u53C2\u6570" tabindex="-1">BreadcrumbItem \u53C2\u6570 <a class="header-anchor" href="#breadcrumbitem-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">to</td><td style="text-align:left;"><code>string/object</code></td><td style="text-align:left;">\u2014</td><td style="text-align:left;">\u8DEF\u7531\u8DF3\u8F6C\u5BF9\u8C61\uFF0C\u540C vue-router \u7684 to</td><td style="text-align:left;"><a href="#%E5%9F%BA%E7%A1%80%E9%9D%A2%E5%8C%85%E5%B1%91">\u57FA\u7840\u9762\u5305\u5C51</a></td></tr><tr><td style="text-align:left;">replace</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u5728\u4F7F\u7528 to \u8FDB\u884C\u8DEF\u7531\u8DF3\u8F6C\u65F6\uFF0C\u542F\u7528 replace \u5C06\u4E0D\u4F1A\u5411 history \u6DFB\u52A0\u65B0\u8BB0\u5F55</td><td style="text-align:left;"><a href="#%E5%9F%BA%E7%A1%80%E9%9D%A2%E5%8C%85%E5%B1%91">\u57FA\u7840\u9762\u5305\u5C51</a></td></tr></tbody></table><h3 id="\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">\u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="breadcrumbchildren" tabindex="-1">breadcrumbChildren <a class="header-anchor" href="#breadcrumbchildren" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">export</span> <span class="token keyword">interface</span> <span class="token class-name">breadcrumbChildren</span> <span class="token punctuation">{</span>
  title<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u663E\u793A\u7684\u540D\u79F0</span>
  link<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u8DF3\u8F6C\u7684\u8DEF\u5F84\uFF0C\u53EF\u4E3A\u7EDD\u5BF9\u8DEF\u5F84\u4E0E\u76F8\u5BF9\u8DEF\u5F84\uFF0C\u6CE8\u610F\u9700\u8981\u4E0E\u8DEF\u7531\u7684\u914D\u7F6E\u4E00\u81F4</span>
  target<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u89C4\u5B9A\u5728\u4F55\u5904\u6253\u5F00\u94FE\u63A5\u6587\u6863</span>
<span class="token punctuation">}</span>
</code></pre></div><h4 id="sourceconfig" tabindex="-1">SourceConfig <a class="header-anchor" href="#sourceconfig" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">export</span> <span class="token keyword">interface</span> <span class="token class-name">SourceConfig</span> <span class="token punctuation">{</span>
  title<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u663E\u793A\u7684\u540D\u79F0</span>
  link<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u8DF3\u8F6C\u7684\u8DEF\u5F84</span>
  target<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u89C4\u5B9A\u5728\u4F55\u5904\u6253\u5F00\u94FE\u63A5\u6587\u6863</span>
  noNavigation<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u94FE\u63A5\u662F\u5426\u4E0D\u53EF\u8DF3\u8F6C\uFF0C\u4E00\u822C\u7528\u4E8E\u5F53\u524D\u6240\u5904\u4F4D\u7F6E\u4E0D\u53EF\u8DF3\u8F6C\u7684\u914D\u7F6E</span>
  linkType<span class="token operator">?</span><span class="token operator">:</span> <span class="token string">&#39;hrefLink&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;routerLink&#39;</span><span class="token punctuation">;</span> <span class="token comment">// \u94FE\u63A5\u7C7B\u578B\uFF0C\u9ED8\u8BA4\u4E3A&#39;hrefLink&#39;\u65B9\u5F0F\uFF0C\u53EF\u9009&#39;hrefLink&#39; \u6216 &#39;routerLink&#39;</span>
  replace<span class="token operator">:</span> Boolean<span class="token punctuation">;</span> <span class="token comment">// \u5728\u4F7F\u7528 to \u8FDB\u884C\u8DEF\u7531\u8DF3\u8F6C\u65F6\uFF0C\u542F\u7528 replace \u5C06\u4E0D\u4F1A\u5411 history \u6DFB\u52A0\u65B0\u8BB0\u5F55</span>
  children<span class="token operator">?</span><span class="token operator">:</span> breadcrumbChildren<span class="token punctuation">[</span><span class="token punctuation">]</span><span class="token punctuation">;</span> <span class="token comment">// \u4E0B\u62C9\u6846\u5185\u7684\u5185\u5BB9</span>
  showMenu<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u53EF\u9009\uFF0C\u662F\u5426\u9700\u8981\u663E\u793A\u4E0B\u62C9\u7BAD\u5934\u53CA\u4E0B\u62C9\u5217\u8868\u5185\u5BB9</span>
<span class="token punctuation">}</span>
</code></pre></div>`,9);function H(e,c,t,s,p,r){const l=b("render-demo-0"),o=b("demo"),u=b("render-demo-1"),m=b("render-demo-2"),i=b("render-demo-3");return v(),A("div",null,[x,k(o,{sourceCode:`<template>
  <n-breadcrumb>
    <n-breadcrumb-item to="{ path: '/' }">Homepage</n-breadcrumb-item>
    <n-breadcrumb-item>
      <a href="/">Nancal UI</a>
    </n-breadcrumb-item>
    <n-breadcrumb-item>
      <span>Breadcrumb</span>
    </n-breadcrumb-item>
  </n-breadcrumb>
</template>
`},{highlight:d(()=>[N]),default:d(()=>[k(l)]),_:1}),w,k(o,{sourceCode:`<template>
  <n-breadcrumb :source="source"></n-breadcrumb>
</template>
<script>
import { defineComponent, reactive } from 'vue';

export default defineComponent({
  name: 'DBreadcrumbDemoSourceConfig',
  setup() {
    const source = reactive([
      { title: 'Nancal UI', link: '/', linkType: 'routerLink', replace: true },
      { title: 'Breadcrumb', link: 'components/breadcrumb/', noNavigation: true },
    ]);
    return {
      source,
    };
  },
});
<\/script>
`},{highlight:d(()=>[I]),default:d(()=>[k(u)]),_:1}),V,k(o,{sourceCode:`<template>
  <div>
    <n-breadcrumb separator-icon=">">
      <n-breadcrumb-item>
        <a routerLink="/components/zh-cn/get-start">Nancal UI</a>
      </n-breadcrumb-item>
      <n-breadcrumb-item>
        <span>Breadcrumb</span>
      </n-breadcrumb-item>
    </n-breadcrumb>
  </div>
  <div>
    <n-breadcrumb>
      <template v-slot:separatorIcon>
        <span style="color: red">></span>
      </template>
      <n-breadcrumb-item>
        <a routerLink="/components/zh-cn/get-start">Nancal UI</a>
      </n-breadcrumb-item>
      <n-breadcrumb-item>
        <span>Breadcrumb</span>
      </n-breadcrumb-item>
    </n-breadcrumb>
  </div>
</template>
`},{highlight:d(()=>[L]),default:d(()=>[k(m)]),_:1}),U,k(o,{sourceCode:`<template>
  <n-breadcrumb :source="source"></n-breadcrumb>
</template>
<script>
import { defineComponent, reactive } from 'vue';

export default defineComponent({
  name: 'DBreadcrumbDemoDropdown',
  setup() {
    const source = reactive([
      { title: 'Homepage', link: '/', linkType: 'routerLink', replace: true },
      { title: 'Nancal UI', link: '/', noNavigation: true },
      {
        title: 'breadcrumb',
        showMenu: true,
        link: '/components/breadcrumb/',
        target: '_blank',
        children: [
          {
            title: '\u57FA\u7840\u9762\u5305\u5C51',
            link: '/components/breadcrumb/#\u57FA\u7840\u9762\u5305\u5C51',
          },
          {
            title: '\u4F20\u5165source',
          },
          {
            title: '\u5E26\u4E0B\u62C9\u83DC\u5355\u7684\u9762\u5305\u5C51',
          },
        ],
      },
    ]);
    return {
      source,
    };
  },
});
<\/script>
`},{highlight:d(()=>[T]),default:d(()=>[k(i)]),_:1}),q])}var G=y(D,[["render",H]]);export{j as __pageData,G as default};
