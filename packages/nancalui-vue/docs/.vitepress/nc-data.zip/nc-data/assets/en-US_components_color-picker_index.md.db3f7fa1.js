import{V as g}from"./framework.1c17ccd8.js";import{_ as S}from"./plugin-vue_export-helper.21dcd24c.js";import{f as _,G as B,H as V,b as k,a6 as d,V as C,I as n,k as s}from"./framework.1f85532f.js";import"./framework.40290dff.js";const x={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:u,createVNode:r,openBlock:c,createElementBlock:i}=g;function p(f,a){const l=u("n-color-picker");return c(),i("div",null,[r(l)])}return{render:p,...{}}}(),"render-demo-1":function(){const{toDisplayString:u,createTextVNode:r,resolveComponent:c,withCtx:i,createVNode:p,openBlock:h,createElementBlock:f}=g;function a(t,w){const v=c("n-button"),y=c("n-color-picker");return h(),f("div",null,[p(v,{btnStyle:"common",onClick:t.isShowAlpha},{default:i(()=>[r("test showAlpha Be "+u(t.show),1)]),_:1},8,["onClick"]),p(y,{modelValue:t.color,"onUpdate:modelValue":w[0]||(w[0]=b=>t.color=b),"show-alpha":t.show},null,8,["modelValue","show-alpha"])])}const{defineComponent:l,watch:e,ref:o}=g,m=l({setup(){const t=o(!0);return{color:o("rgba(83, 199, 212, 0.72)"),isShowAlpha:()=>{t.value=!t.value},show:t}}});return{render:a,...m}}(),"render-demo-2":function(){const{resolveComponent:u,createVNode:r,openBlock:c,createElementBlock:i}=g;function p(e,o){const m=u("n-color-picker");return c(),i("div",null,[r(m,{modelValue:e.color,"onUpdate:modelValue":o[0]||(o[0]=t=>e.color=t),mode:"hex"},null,8,["modelValue"])])}const{defineComponent:h,watch:f,ref:a}=g,l=h({setup(){return{color:a("#FF6827A1")}}});return{render:p,...l}}(),"render-demo-3":function(){const{toDisplayString:u,createTextVNode:r,resolveComponent:c,withCtx:i,createVNode:p,openBlock:h,createElementBlock:f}=g;function a(t,w){const v=c("n-button"),y=c("n-color-picker");return h(),f("div",null,[p(v,{btnStyle:"common",onClick:t.isShowAlpha},{default:i(()=>[r("test showAlpha Be "+u(t.show),1)]),_:1},8,["onClick"]),p(y,{"show-history":t.show,modelValue:t.color,"onUpdate:modelValue":w[0]||(w[0]=b=>t.color=b),mode:"hsl"},null,8,["show-history","modelValue"])])}const{defineComponent:l,watch:e,ref:o}=g,m=l({setup(){let t=o(!0);const w=()=>{t.value=!t.value};return{color:o("hsla(353, 1, 0.58, 1)"),isShowAlpha:w,show:t}}});return{render:a,...m}}(),"render-demo-4":function(){const{resolveComponent:u,createVNode:r,openBlock:c,createElementBlock:i}=g;function p(e,o){const m=u("n-color-picker");return c(),i("div",null,[r(m,{swatches:e.colors,modelValue:e.color,"onUpdate:modelValue":o[0]||(o[0]=t=>e.color=t)},null,8,["swatches","modelValue"])])}const{defineComponent:h,watch:f,ref:a}=g,l=h({setup(){const e=["#f44336","#e91e63","#9c27b0","#673ab7","#3f51b5","#2196f3","#03a9f4","#00bcd4","#009688","#4caf50"];return{color:a("rgba(155, 39, 176, 1)"),colors:e}}});return{render:p,...l}}()}},O='{"title":"ColorPicker","description":"","frontmatter":{},"headers":[{"level":3,"title":"When to use","slug":"when-to-use"},{"level":3,"title":"Basic Usage","slug":"basic-usage"},{"level":3,"title":"Color transparency","slug":"color-transparency"},{"level":3,"title":"Color mode","slug":"color-mode"},{"level":3,"title":"Historical color","slug":"historical-color"},{"level":3,"title":"Foundation panel customization","slug":"foundation-panel-customization"},{"level":3,"title":"n-color-picker","slug":"n-color-picker"}],"relativePath":"en-US/components/color-picker/index.md","lastUpdated":1672994787131}',A=C('<h1 id="colorpicker" tabindex="-1">ColorPicker <a class="header-anchor" href="#colorpicker" aria-hidden="true">#</a></h1><h3 id="when-to-use" tabindex="-1">When to use <a class="header-anchor" href="#when-to-use" aria-hidden="true">#</a></h3><p>Allows users to use various interactive methods to select colors</p><h3 id="basic-usage" tabindex="-1">Basic Usage <a class="header-anchor" href="#basic-usage" aria-hidden="true">#</a></h3>',4),N=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1),E=n("h3",{id:"color-transparency",tabindex:"-1"},[s("Color transparency "),n("a",{class:"header-anchor",href:"#color-transparency","aria-hidden":"true"},"#")],-1),q=n("p",null,"Allows users to dynamically adjust the display alpha mode, which is true by default",-1),F=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-button")]),s(),n("span",{class:"token attr-name"},"btnStyle"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("common"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("isShowAlpha"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s("test showAlpha Be {{ show }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-button")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-color-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("color"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},":show-alpha"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("show"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" defineComponent"),n("span",{class:"token punctuation"},","),s(" watch"),n("span",{class:"token punctuation"},","),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" show "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" color "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'rgba(83, 199, 212, 0.72)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(),n("span",{class:"token function-variable function"},"isShowAlpha"),s(),n("span",{class:"token operator"},"="),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
      show`),n("span",{class:"token punctuation"},"."),s("value "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token operator"},"!"),s("show"),n("span",{class:"token punctuation"},"."),s("value"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      color`),n("span",{class:"token punctuation"},","),s(`
      isShowAlpha`),n("span",{class:"token punctuation"},","),s(`
      show`),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1),z=n("h3",{id:"color-mode",tabindex:"-1"},[s("Color mode "),n("a",{class:"header-anchor",href:"#color-mode","aria-hidden":"true"},"#")],-1),U=n("p",null,"Set dynamic output color mode",-1),D=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-color-picker")]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("color"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"mode"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("hex"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" defineComponent"),n("span",{class:"token punctuation"},","),s(" watch"),n("span",{class:"token punctuation"},","),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" color "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'#FF6827A1'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      color`),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1),T=n("h3",{id:"historical-color",tabindex:"-1"},[s("Historical color "),n("a",{class:"header-anchor",href:"#historical-color","aria-hidden":"true"},"#")],-1),j=n("p",null,"Customize whether to display historical colors. By default, it is true",-1),P=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-button")]),s(),n("span",{class:"token attr-name"},"btnStyle"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("common"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("isShowAlpha"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),s("test showAlpha Be {{ show }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-button")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-color-picker")]),s(),n("span",{class:"token attr-name"},":show-history"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("show"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("color"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"mode"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("hsl"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" defineComponent"),n("span",{class:"token punctuation"},","),s(" watch"),n("span",{class:"token punctuation"},","),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token keyword"},"let"),s(" show "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(),n("span",{class:"token function-variable function"},"isShowAlpha"),s(),n("span",{class:"token operator"},"="),s(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token operator"},"=>"),s(),n("span",{class:"token punctuation"},"{"),s(`
      show`),n("span",{class:"token punctuation"},"."),s("value "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token operator"},"!"),s("show"),n("span",{class:"token punctuation"},"."),s("value"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" color "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'hsla(353, 1, 0.58, 1)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      color`),n("span",{class:"token punctuation"},","),s(`
      isShowAlpha`),n("span",{class:"token punctuation"},","),s(`
      show`),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1),$=n("h3",{id:"foundation-panel-customization",tabindex:"-1"},[s("Foundation panel customization "),n("a",{class:"header-anchor",href:"#foundation-panel-customization","aria-hidden":"true"},"#")],-1),H=n("p",null,"Sets a customizable base panel color swatch",-1),W=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("n-color-picker")]),s(),n("span",{class:"token attr-name"},":swatches"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("colors"),n("span",{class:"token punctuation"},'"')]),s(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),s("color"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("n-color-picker")]),n("span",{class:"token punctuation"},">")]),s(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("template")]),n("span",{class:"token punctuation"},">")]),s(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),s("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[s(`
`),n("span",{class:"token keyword"},"import"),s(),n("span",{class:"token punctuation"},"{"),s(" defineComponent"),n("span",{class:"token punctuation"},","),s(" watch"),n("span",{class:"token punctuation"},","),s(" ref "),n("span",{class:"token punctuation"},"}"),s(),n("span",{class:"token keyword"},"from"),s(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),s(`

`),n("span",{class:"token keyword"},"export"),s(),n("span",{class:"token keyword"},"default"),s(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),s(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),s(),n("span",{class:"token punctuation"},"{"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" colors "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'#f44336'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#e91e63'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#9c27b0'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#673ab7'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#3f51b5'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#2196f3'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#03a9f4'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#00bcd4'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#009688'"),n("span",{class:"token punctuation"},","),s(),n("span",{class:"token string"},"'#4caf50'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"const"),s(" color "),n("span",{class:"token operator"},"="),s(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'rgba(155, 39, 176, 1)'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
    `),n("span",{class:"token keyword"},"return"),s(),n("span",{class:"token punctuation"},"{"),s(`
      color`),n("span",{class:"token punctuation"},","),s(`
      colors`),n("span",{class:"token punctuation"},","),s(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),s(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),s(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),s(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),s("script")]),n("span",{class:"token punctuation"},">")]),s(`
`)])])],-1),G=C('<h3 id="n-color-picker" tabindex="-1">n-color-picker <a class="header-anchor" href="#n-color-picker" aria-hidden="true">#</a></h3><p>| parameter | type | default | introduce | Jump Demo | | :----------: | :-------: | :-----: | :---------------------------------------------------: | :-----------------------------------------: | --- | | mode | <code>String</code> | <code>rgb</code> | Toggle color mode | <a href="#color-mode">mode</a> | | | dotSize | <code>Number</code> | <code>15</code> | Palette dot size | | | | swatches | <code>Array</code> | | Predefined sample panels | <a href="#foundation-panel-customization">swatches</a> | | | show-alpha | <code>Boolean</code> | <code>true</code> | Show transparency progress bar | <a href="#color-transparency">Color transparency</a> | | | show-history | <code>Boolean</code> | <code>true</code> | Show historical colors | <a href="#historical-color">show-history</a> | | | v-model | <code>String</code> | | Binding color value support\uFF08hex , rgb , hsl , hsv \uFF09 | | |</p>',2);function I(u,r,c,i,p,h){const f=_("render-demo-0"),a=_("demo"),l=_("render-demo-1"),e=_("render-demo-2"),o=_("render-demo-3"),m=_("render-demo-4");return B(),V("div",null,[A,k(a,{sourceCode:`<template>
  <n-color-picker></n-color-picker>
</template>
`},{highlight:d(()=>[N]),default:d(()=>[k(f)]),_:1}),E,q,k(a,{sourceCode:`<template>
  <n-button btnStyle="common" @click="isShowAlpha">test showAlpha Be {{ show }}</n-button>
  <n-color-picker v-model="color" :show-alpha="show"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const show = ref(true);
    const color = ref('rgba(83, 199, 212, 0.72)');
    const isShowAlpha = () => {
      show.value = !show.value;
    };
    return {
      color,
      isShowAlpha,
      show,
    };
  },
});
<\/script>
`},{highlight:d(()=>[F]),default:d(()=>[k(l)]),_:1}),z,U,k(a,{sourceCode:`<template>
  <n-color-picker v-model="color" mode="hex"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const color = ref('#FF6827A1');
    return {
      color,
    };
  },
});
<\/script>
`},{highlight:d(()=>[D]),default:d(()=>[k(e)]),_:1}),T,j,k(a,{sourceCode:`<template>
  <n-button btnStyle="common" @click="isShowAlpha">test showAlpha Be {{ show }}</n-button>
  <n-color-picker :show-history="show" v-model="color" mode="hsl"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    let show = ref(true);
    const isShowAlpha = () => {
      show.value = !show.value;
    };
    const color = ref('hsla(353, 1, 0.58, 1)');
    return {
      color,
      isShowAlpha,
      show,
    };
  },
});
<\/script>
`},{highlight:d(()=>[P]),default:d(()=>[k(o)]),_:1}),$,H,k(a,{sourceCode:`<template>
  <n-color-picker :swatches="colors" v-model="color"></n-color-picker>
</template>

<script>
import { defineComponent, watch, ref } from 'vue';

export default defineComponent({
  setup() {
    const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50'];
    const color = ref('rgba(155, 39, 176, 1)');
    return {
      color,
      colors,
    };
  },
});
<\/script>
`},{highlight:d(()=>[W]),default:d(()=>[k(m)]),_:1}),G])}var Q=S(x,[["render",I]]);export{O as __pageData,Q as default};
