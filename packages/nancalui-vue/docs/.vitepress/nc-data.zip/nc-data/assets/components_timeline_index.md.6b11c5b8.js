import{V as x}from"./framework.1c17ccd8.js";import{_ as $}from"./plugin-vue_export-helper.21dcd24c.js";import{f as C,G as j,H as M,b as y,a6 as h,V as N,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const U={name:"component-doc",components:{"render-demo-0":function(){const{renderList:u,Fragment:p,openBlock:s,createElementBlock:a,toDisplayString:e,createTextVNode:d,resolveComponent:o,withCtx:l,createBlock:m,createVNode:r,createElementVNode:k}=x;function E(g,v){const A=o("n-radio"),_=o("n-radio-group"),D=o("n-timeline-item"),b=o("n-timeline");return s(),a("div",null,[k("div",null,[r(_,{direction:"row",modelValue:g.choose,"onUpdate:modelValue":v[0]||(v[0]=c=>g.choose=c)},{default:l(()=>[(s(!0),a(p,null,u(g.list,c=>(s(),m(A,{key:c,value:c},{default:l(()=>[d(e(c),1)]),_:2},1032,["value"]))),128))]),_:1},8,["modelValue"]),r(b,{direction:g.choose,center:""},{default:l(()=>[(s(!0),a(p,null,u(g.timeAxisList,(c,w)=>(s(),m(D,{center:"",key:w,time:c.time,"dot-color":c.dotColor},{default:l(()=>[d(e(c.text),1)]),_:2},1032,["time","dot-color"]))),128))]),_:1},8,["direction"])])])}const{defineComponent:B,ref:i}=x,F=B({setup(){const g=i(["vertical","horizontal"]),v=i("vertical");return{timeAxisList:i([{text:"Download",time:"2021-10-1"},{text:"Check",time:"2021-10-2",dotColor:"var(--nancalui-success)"},{text:"Build",time:"2021-10-3",dotColor:"var(--nancalui-danger)"},{text:"Depoy",time:"2021-10-4",dotColor:"var(--nancalui-warning)"},{text:"End",time:"2021-10-5",dotColor:"var(--nancalui-waiting)"}]),list:g,choose:v}}});return{render:E,...F}}(),"render-demo-1":function(){const{renderList:u,Fragment:p,openBlock:s,createElementBlock:a,toDisplayString:e,createElementVNode:d,resolveComponent:o,createVNode:l,createTextVNode:m,withCtx:r,createSlots:k,createBlock:E}=x;function B(v,A){const _=o("n-icon"),D=o("n-timeline-item"),b=o("n-timeline");return s(),a("div",null,[l(b,{direction:"horizontal",center:""},{default:r(()=>[(s(!0),a(p,null,u(v.timeAxisList,(c,w)=>(s(),E(D,{key:w,"dot-color":c.dotColor,"line-style":c.lineStyle,"line-color":c.lineColor},k({time:r(()=>[d("div",null,e(c.time),1)]),default:r(()=>[m(" "+e(c.text),1)]),_:2},[c.dot?{name:"dot",fn:r(()=>[l(_,{name:c.dot},null,8,["name"])]),key:"0"}:void 0]),1032,["dot-color","line-style","line-color"]))),128))]),_:1})])}const{defineComponent:i,ref:F}=x,g=i({setup(){return{timeAxisList:F([{text:"Start",time:"2021-10-1",lineStyle:"solid",dot:"cancel-forbidden"},{text:"Check",time:"2021-10-2",dotColor:"var(--nancalui-success)",lineStyle:"dashed",lineColor:"var(--nancalui-success)",dot:"classroom-approve"},{text:"Debug",time:"2021-10-3",dotColor:"var(--nancalui-info)",lineStyle:"dotted",lineColor:"var(--nancalui-info)",dot:"add-bug"},{text:"Build",time:"2021-10-4",dotColor:"var(--nancalui-warning)",lineStyle:"none",lineColor:"var(--nancalui-warning)",dot:"build-with-tool"},{text:"Display",time:"2021-10-5",dotColor:"var(--nancalui-danger)",dot:"go-chart"}])}}});return{render:B,...g}}(),"render-demo-2":function(){const{renderList:u,Fragment:p,openBlock:s,createElementBlock:a,createCommentVNode:e,toDisplayString:d,createElementVNode:o,createTextVNode:l,resolveComponent:m,withCtx:r,createVNode:k,normalizeStyle:E,createSlots:B,createBlock:i}=x,F={style:{position:"relative"}},g={key:0,style:{"margin-bottom":"4px",position:"relative",left:"4px",width:"2px",height:"40px","background-color":"#e1e1e1"}},v={style:{"padding-bottom":"8px","font-size":"14px","font-weight":"bold"}},A={style:{"padding-bottom":"8px"}},_={style:{"padding-bottom":"8px"}},D={key:1,style:{"margin-top":"4px",position:"relative",left:"4px",width:"2px",height:"40px","background-color":"#e1e1e1"}},b=o("div",{style:{"text-align":"center",width:"36px",height:"36px","border-radius":"18px",border:"2px solid #e1e1e1",background:"white"}},[o("span",{style:{"line-height":"32px"}},"2020")],-1);function c(q,at){const z=m("n-tag"),P=m("n-timeline-item"),I=m("n-timeline");return s(),a("div",null,[k(I,{direction:"horizontal",mode:"alternative"},{default:r(()=>[(s(!0),a(p,null,u(q.timeAxisList,(f,V)=>(s(),i(P,{key:V,"dot-color":f.dotColor,"line-style":"dashed"},B({default:r(L=>[o("div",F,[L.position==="bottom"?(s(),a("div",g)):e("v-if",!0),o("div",{style:E({"border-left":"4px solid","box-shadow":"0 2px 4px 0 rgba(0, 0, 0, 0.1)",padding:"12px 8px",borderColor:f.dotColor,backgroundColor:f.backgroundColor})},[o("div",v,d(f.title),1),o("div",A,"\u53D1\u5E03\u65E5\u671F\uFF1A"+d(f.date),1),o("div",_,[l(" \u7248\u672C\u72B6\u6001\uFF1A "),k(z,{color:f.dotColor},{default:r(()=>[l(d(f.status),1)]),_:2},1032,["color"])])],4),L.position==="top"?(s(),a("div",D)):e("v-if",!0)])]),_:2},[V===0?{name:"extra",fn:r(()=>[b]),key:"0"}:void 0]),1032,["dot-color"]))),128))]),_:1})])}const{defineComponent:w,ref:S}=x,T=w({setup(){return{timeAxisList:S([{text:"hello",dotColor:"var(--nancalui-success)",extraElement:{},title:"\u7B2C\u56DB\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0",date:"2019/11/01",status:"\u5DF2\u53D1\u5E03"},{text:"world",dotColor:"var(--nancalui-danger)",title:"\u7B2C\u4E00\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C2.0",date:"2020/03/01",backgroundColor:"rgba(255, 230, 230, 0.2)",status:"\u672A\u5F00\u59CB"},{text:"nihao",dotColor:"var(--nancalui-warning)",title:"\u7B2C\u4E8C\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0",date:"2020/05/01",status:"\u8FDB\u884C\u4E2D"},{text:"nancalui",dotColor:"var(--nancalui-danger)",title:"\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0",date:"2020/09/01",status:"\u672A\u5F00\u59CB"},{text:"Awesome",dotColor:"var(--nancalui-success)",title:"\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0",date:"2020/11/01",status:"\u5DF2\u53D1\u5E03"}])}}});return{render:c,...T}}(),"render-demo-3":function(){const{createElementVNode:u,createTextVNode:p,resolveComponent:s,withCtx:a,createVNode:e,openBlock:d,createElementBlock:o}=x,l=u("h5",null,[u("p",null,"\u5F53 direction \u4E3A horizontal \u65F6 position \u9ED8\u8BA4 bottom")],-1),m=u("h5",null,[u("p",null,"\u5F53 direction \u4E3A vertical \u65F6 position \u9ED8\u8BA4 right")],-1);function r(E,B){const i=s("n-timeline-item"),F=s("n-timeline");return d(),o("div",null,[l,e(F,{direction:"horizontal",center:""},{default:a(()=>[e(i,{position:"top","dot-color":"chocolate"},{default:a(()=>[p("Download")]),_:1}),e(i,{"dot-color":"var(--nancalui-success)"},{default:a(()=>[p("Check")]),_:1}),e(i,{position:"top","dot-color":"var(--nancalui-danger)"},{default:a(()=>[p("Build")]),_:1}),e(i,{"dot-color":"var(--nancalui-warning)"},{default:a(()=>[p("Depoy")]),_:1}),e(i,{position:"top","dot-color":"var(--nancalui-waiting)"},{default:a(()=>[p("End")]),_:1})]),_:1}),m,e(F,{direction:"vertical"},{default:a(()=>[e(i,{position:"left","dot-color":"chocolate"},{default:a(()=>[p("Download")]),_:1}),e(i,{position:"right","dot-color":"var(--nancalui-success)"},{default:a(()=>[p("Check")]),_:1}),e(i,{position:"left","dot-color":"var(--nancalui-danger)"},{default:a(()=>[p("Build")]),_:1}),e(i,{position:"right","dot-color":"var(--nancalui-warning)"},{default:a(()=>[p("Depoy")]),_:1}),e(i,{position:"left","dot-color":"var(--nancalui-waiting)"},{default:a(()=>[p("End")]),_:1})]),_:1})])}return{render:r,...{}}}(),"render-demo-4":function(){const{createTextVNode:u,resolveComponent:p,withCtx:s,createVNode:a,openBlock:e,createElementBlock:d}=x;function o(m,r){const k=p("n-timeline-item"),E=p("n-timeline");return e(),d("div",null,[a(E,{"time-position":"bottom"},{default:s(()=>[a(k,{time:"2019","time-position":"left"},{default:s(()=>[u("Download")]),_:1}),a(k,{time:"11-2",type:"success"},{default:s(()=>[u("Check")]),_:1}),a(k,{time:"2020",type:"warning","time-position":"left"},{default:s(()=>[u("Build")]),_:1}),a(k,{time:"11-4",type:"error"},{default:s(()=>[u("Depoy")]),_:1}),a(k,{time:"2021",type:"primary","time-position":"left"},{default:s(()=>[u("End")]),_:1})]),_:1})])}return{render:o,...{}}}()}},lt='{"title":"Timeline \u65F6\u95F4\u8F74","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u6837\u5F0F","slug":"\u81EA\u5B9A\u4E49\u6837\u5F0F"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u5185\u5BB9","slug":"\u81EA\u5B9A\u4E49\u5185\u5BB9"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E","slug":"\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E"},{"level":3,"title":"\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E","slug":"\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E"},{"level":3,"title":"Timeline \u53C2\u6570","slug":"timeline-\u53C2\u6570"},{"level":3,"title":"TimelineItem \u53C2\u6570","slug":"timelineitem-\u53C2\u6570"},{"level":3,"title":"TimelineItem \u63D2\u69FD","slug":"timelineitem-\u63D2\u69FD"},{"level":3,"title":"Timeline \u7C7B\u578B\u5B9A\u4E49","slug":"timeline-\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/timeline/index.md","lastUpdated":1685348482054}',G=N('<h1 id="timeline-\u65F6\u95F4\u8F74" tabindex="-1">Timeline \u65F6\u95F4\u8F74 <a class="header-anchor" href="#timeline-\u65F6\u95F4\u8F74" aria-hidden="true">#</a></h1><p>\u65F6\u95F4\u8F74\u5C55\u793A\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u9700\u8981\u5411\u7528\u6237\u5C55\u793A\u65F6\u95F4\u8FDB\u5EA6\u548C\u6BCF\u4E2A\u65F6\u95F4\u70B9\u7684\u4E8B\u4EF6\u72B6\u6001\u65F6\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3><p>\u901A\u8FC7 <code>direction</code> \u5C5E\u6027\u914D\u7F6E\u65F6\u95F4\u7EBF\u6392\u5217\u65B9\u5411\uFF0C\u9ED8\u8BA4\u503C\u4E3A<code>vertical</code>\u3002</p>',6),H=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-radio-group")]),n(),t("span",{class:"token attr-name"},"direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("row"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("choose"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-radio")]),n(),t("span",{class:"token attr-name"},"v-for"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item in list"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":key"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        {{ item }}
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-radio")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-radio-group")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},":direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("choose"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"center"),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"center"),n(),t("span",{class:"token attr-name"},"v-for"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("(item, index) in timeAxisList"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":key"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("index"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.time"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dotColor"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        {{ item.text }}
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" list "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"'vertical'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"'horizontal'"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" choose "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'vertical'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" timeAxisList "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Download'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-1'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Check'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-2'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-success)'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Build'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-3'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-danger)'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Depoy'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-4'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-warning)'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'End'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-5'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-waiting)'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(" timeAxisList"),t("span",{class:"token punctuation"},","),n(" list"),t("span",{class:"token punctuation"},","),n(" choose "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),J=t("h3",{id:"\u81EA\u5B9A\u4E49\u6837\u5F0F",tabindex:"-1"},[n("\u81EA\u5B9A\u4E49\u6837\u5F0F "),t("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u6837\u5F0F","aria-hidden":"true"},"#")],-1),K=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},"direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("horizontal"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"center"),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(`
      `),t("span",{class:"token attr-name"},"v-for"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("(item, index) in timeAxisList"),t("span",{class:"token punctuation"},'"')]),n(`
      `),t("span",{class:"token attr-name"},":key"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("index"),t("span",{class:"token punctuation"},'"')]),n(`
      `),t("span",{class:"token attr-name"},":dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dotColor"),t("span",{class:"token punctuation"},'"')]),n(`
      `),t("span",{class:"token attr-name"},":line-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.lineStyle"),t("span",{class:"token punctuation"},'"')]),n(`
      `),t("span",{class:"token attr-name"},":line-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.lineColor"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#time"),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n("{{ item.time }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#dot"),n(),t("span",{class:"token attr-name"},"v-if"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dot"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},":name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dot"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-icon")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
      {{ item.text }}
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" timeAxisList "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Start'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-1'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineStyle"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'solid'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dot"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'cancel-forbidden'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Check'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-2'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-success)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineStyle"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'dashed'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-success)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dot"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'classroom-approve'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Debug'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-3'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-info)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineStyle"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'dotted'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-info)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dot"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'add-bug'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Build'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-4'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-warning)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineStyle"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'none'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"lineColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-warning)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dot"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'build-with-tool'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Display'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"time"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2021-10-5'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-danger)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dot"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'go-chart'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(" timeAxisList "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),O=t("h3",{id:"\u81EA\u5B9A\u4E49\u5185\u5BB9",tabindex:"-1"},[n("\u81EA\u5B9A\u4E49\u5185\u5BB9 "),t("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u5185\u5BB9","aria-hidden":"true"},"#")],-1),Q=t("p",null,[n("\u53EF\u4EE5\u4F7F\u7528 mode \u4E3A "),t("code",null,"alternative"),n(" \u8BBE\u7F6E\u5185\u5BB9\u4EA4\u66FF\u5C55\u793A")],-1),R=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},"direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("horizontal"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"mode"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("alternative"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"v-for"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("(item, index) in timeAxisList"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":key"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("index"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dotColor"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"line-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("dashed"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#default"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"position"),t("span",{class:"token punctuation"},":"),n(" relative")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(`
            `),t("span",{class:"token attr-name"},"v-if"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data.position === 'bottom'"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-bottom"),t("span",{class:"token punctuation"},":"),n(" 4px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"position"),t("span",{class:"token punctuation"},":"),n(" relative"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"left"),t("span",{class:"token punctuation"},":"),n(" 4px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 2px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n(" 40px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"background-color"),t("span",{class:"token punctuation"},":"),n(" #e1e1e1")]),t("span",{class:"token punctuation"},'"')])]),n(`
          `),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(`
            `),t("span",{class:"token attr-name"},":style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`{
              'border-left': '4px solid',
              'box-shadow': '0 2px 4px 0 rgba(0, 0, 0, 0.1)',
              padding: '12px 8px',
              borderColor: item.dotColor,
              backgroundColor: item.backgroundColor,
            }`),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"padding-bottom"),t("span",{class:"token punctuation"},":"),n(" 8px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"font-size"),t("span",{class:"token punctuation"},":"),n(" 14px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"font-weight"),t("span",{class:"token punctuation"},":"),n(" bold")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n("{{ item.title }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"padding-bottom"),t("span",{class:"token punctuation"},":"),n(" 8px")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n("\u53D1\u5E03\u65E5\u671F\uFF1A{{ item.date }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"padding-bottom"),t("span",{class:"token punctuation"},":"),n(" 8px")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n(`
              \u7248\u672C\u72B6\u6001\uFF1A
              `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-tag")]),n(),t("span",{class:"token attr-name"},":color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("item.dotColor"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("{{ item.status }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-tag")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(`
            `),t("span",{class:"token attr-name"},"v-if"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data.position === 'top'"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-top"),t("span",{class:"token punctuation"},":"),n(" 4px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"position"),t("span",{class:"token punctuation"},":"),n(" relative"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"left"),t("span",{class:"token punctuation"},":"),n(" 4px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 2px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n(" 40px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"background-color"),t("span",{class:"token punctuation"},":"),n(" #e1e1e1")]),t("span",{class:"token punctuation"},'"')])]),n(`
          `),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#extra"),n(),t("span",{class:"token attr-name"},"v-if"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("index === 0"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"text-align"),t("span",{class:"token punctuation"},":"),n(" center"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 36px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n(" 36px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"border-radius"),t("span",{class:"token punctuation"},":"),n(" 18px"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"border"),t("span",{class:"token punctuation"},":"),n(" 2px solid #e1e1e1"),t("span",{class:"token punctuation"},";"),n(),t("span",{class:"token property"},"background"),t("span",{class:"token punctuation"},":"),n(" white")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"line-height"),t("span",{class:"token punctuation"},":"),n(" 32px")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n("2020"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" timeAxisList "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'hello'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-success)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"extraElement"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token punctuation"},"{"),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7B2C\u56DB\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2019/11/01'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"status"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u5DF2\u53D1\u5E03'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'world'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-danger)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7B2C\u4E00\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C2.0'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2020/03/01'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"backgroundColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'rgba(255, 230, 230, 0.2)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"status"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u672A\u5F00\u59CB'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'nihao'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-warning)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7B2C\u4E8C\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2020/05/01'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"status"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u8FDB\u884C\u4E2D'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'nancalui'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-danger)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2020/09/01'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"status"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u672A\u5F00\u59CB'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"text"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'Awesome'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"dotColor"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'var(--nancalui-success)'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"date"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'2020/11/01'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"status"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u5DF2\u53D1\u5E03'"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(" timeAxisList "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),W=t("h3",{id:"\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E",tabindex:"-1"},[n("\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E "),t("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E","aria-hidden":"true"},"#")],-1),X=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("h5")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("p")]),t("span",{class:"token punctuation"},">")]),n("\u5F53 direction \u4E3A horizontal \u65F6 position \u9ED8\u8BA4 bottom"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("p")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("h5")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},"direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("horizontal"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"center"),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("top"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("chocolate"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Download"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-success)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Check"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("top"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-danger)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Build"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-warning)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Depoy"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("top"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-waiting)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("End"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("h5")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("p")]),t("span",{class:"token punctuation"},">")]),n("\u5F53 direction \u4E3A vertical \u65F6 position \u9ED8\u8BA4 right"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("p")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("h5")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},"direction"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("vertical"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("chocolate"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Download"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("right"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-success)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Check"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-danger)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Build"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("right"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-warning)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Depoy"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"dot-color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("var(--nancalui-waiting)"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("End"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),Y=t("h3",{id:"\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E",tabindex:"-1"},[n("\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E "),t("a",{class:"header-anchor",href:"#\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E","aria-hidden":"true"},"#")],-1),Z=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline")]),n(),t("span",{class:"token attr-name"},"time-position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("bottom"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("2019"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"time-position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Download"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("11-2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("success"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Check"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("2020"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("warning"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"time-position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Build"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("11-4"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("error"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Depoy"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-timeline-item")]),n(),t("span",{class:"token attr-name"},"time"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("2021"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"time-position"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("left"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("End"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline-item")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-timeline")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),tt=N(`<h3 id="timeline-\u53C2\u6570" tabindex="-1">Timeline \u53C2\u6570 <a class="header-anchor" href="#timeline-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">direction</td><td style="text-align:left;"><a href="#timelinedirection">TimelineDirection</a></td><td style="text-align:left;"><code>vertical</code></td><td style="text-align:left;">\u8BBE\u7F6E\u65F6\u95F4\u8F74\u65B9\u5411</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">center</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;"><code>false</code></td><td style="text-align:left;">\u5F53\u65B9\u5411\u4E3A<code>horizontal</code>\u65F6\uFF0C\u662F\u5426\u5C06\u5185\u5BB9\u8BBE\u7F6E\u5C45\u4E2D</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">mode</td><td style="text-align:left;"><a href="#mode">Mode</a></td><td style="text-align:left;"><code>normal</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C<code>normal</code>\u6A21\u5F0F\u4E0B\u5185\u5BB9\u6309\u9ED8\u8BA4\u65B9\u5411\u6392\u5E03\uFF0C<br><code>alternative</code>\u6A21\u5F0F\u4E0B\u5185\u5BB9\u4EA4\u66FF\u6392\u5E03</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9">\u81EA\u5B9A\u4E49\u5185\u5BB9</a></td></tr><tr><td style="text-align:left;">time-position</td><td style="text-align:left;"><a href="#timeposition">TimePosition</a></td><td style="text-align:left;"><code>left</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u4EC5\u5F53<code>direction</code> \u4E3A <code>vertical</code> \u65F6\u5B9A\u4E49\u65F6\u95F4\u53C2\u6570\u4F4D\u7F6E<br>(\u5168\u5C40\u8BBE\u7F6E\uFF0C\u5F53\u4E0E<code>mode</code>\u5C5E\u6027\u51B2\u7A81\u65F6\u4EE5<code>mode</code>\u4E3A\u51C6)</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9">\u81EA\u5B9A\u4E49\u5185\u5BB9</a></td></tr></tbody></table><h3 id="timelineitem-\u53C2\u6570" tabindex="-1">TimelineItem \u53C2\u6570 <a class="header-anchor" href="#timelineitem-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">time</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u65F6\u95F4</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">text</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6587\u672C\u5185\u5BB9</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">dot-color</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u81EA\u5B9A\u4E49\u65F6\u95F4\u5708\u989C\u8272</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">line-style</td><td style="text-align:left;"><a href="#linestyle">LineStyle</a></td><td style="text-align:left;"><code>solid</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u7EBF\u6761\u6837\u5F0F\uFF08\u82E5\u6CA1\u6709\u8BBE\u7F6E\uFF0C\u5219\u9ED8\u8BA4\u65F6\u95F4\u8F74\u6700\u540E\u4E00\u4E2A\u5143\u7D20\u4E3A<code>none</code>\uFF09</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%A0%B7%E5%BC%8F">\u81EA\u5B9A\u4E49\u6837\u5F0F</a></td></tr><tr><td style="text-align:left;">line-color</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u7EBF\u6761\u989C\u8272</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%A0%B7%E5%BC%8F">\u81EA\u5B9A\u4E49\u6837\u5F0F</a></td></tr><tr><td style="text-align:left;">position</td><td style="text-align:left;"><a href="#position">Position</a></td><td style="text-align:left;">\u5F53<code>direction</code>\u4E3A<code>vertical</code>\u65F6\u9ED8\u8BA4\uFF1A<code>right</code>\uFF0C<br>\u5F53<code>direction</code>\u4E3A<code>horizontal</code>\u65F6\uFF0C\u9ED8\u8BA4\uFF1A<code>bottom</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u5185\u5BB9\u5B58\u5728\u7684\u4F4D\u7F6E\uFF0C\u82E5\u6709 time \u5219 time \u5904\u5728\u76F8\u53CD\u7684\u4F4D\u7F6E</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9%E4%BD%8D%E7%BD%AE">\u81EA\u5B9A\u4E49\u5185\u5BB9\u4F4D\u7F6E</a></td></tr><tr><td style="text-align:left;">time-position</td><td style="text-align:left;"><a href="#timeposition">TimePosition</a></td><td style="text-align:left;"><code>left</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u4EC5\u5F53<code>direction</code> \u4E3A <code>vertical</code> \u65F6\u5B9A\u4E49\u65F6\u95F4\u53C2\u6570\u4F4D\u7F6E(\u5168\u5C40\u8BBE\u7F6E\uFF0C\u5F53\u4E0E<code>position</code>\u5C5E\u6027\u51B2\u7A81\u65F6\u4EE5<code>position</code>\u4E3A\u51C6)</td><td style="text-align:left;"><a href="#%E8%AE%BE%E7%BD%AE%E6%97%B6%E9%97%B4%E4%BD%8D%E7%BD%AE">\u8BBE\u7F6E\u65F6\u95F4\u4F4D\u7F6E</a></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;"><a href="#type">Type</a></td><td style="text-align:left;"><code>primary</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u65F6\u95F4\u70B9\u7C7B\u578B</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9">\u81EA\u5B9A\u4E49\u5185\u5BB9</a></td></tr></tbody></table><h3 id="timelineitem-\u63D2\u69FD" tabindex="-1">TimelineItem \u63D2\u69FD <a class="header-anchor" href="#timelineitem-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u63CF\u8FF0</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">default</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u5185\u5BB9</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9">\u81EA\u5B9A\u4E49\u5185\u5BB9</a></td></tr><tr><td style="text-align:left;">dot</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u65F6\u95F4\u8F74\u70B9</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%A0%B7%E5%BC%8F">\u81EA\u5B9A\u4E49\u6837\u5F0F</a></td></tr><tr><td style="text-align:left;">time</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u65F6\u95F4</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%A0%B7%E5%BC%8F">\u81EA\u5B9A\u4E49\u6837\u5F0F</a></td></tr><tr><td style="text-align:left;">extra</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u4E24\u4E2A\u65F6\u95F4\u70B9\u95F4\u9644\u52A0\u5143\u7D20</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E5%86%85%E5%AE%B9">\u81EA\u5B9A\u4E49\u5185\u5BB9</a></td></tr></tbody></table><h3 id="timeline-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">Timeline \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#timeline-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="timelinedirection" tabindex="-1">TimelineDirection <a class="header-anchor" href="#timelinedirection" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">TimelineDirection</span> <span class="token operator">=</span> <span class="token string">&#39;vertical&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;horizontal&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="mode" tabindex="-1">Mode <a class="header-anchor" href="#mode" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">Mode</span> <span class="token operator">=</span> <span class="token string">&#39;normal&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;alternative&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="timeposition" tabindex="-1">TimePosition <a class="header-anchor" href="#timeposition" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">TimePosition</span> <span class="token operator">=</span> <span class="token string">&#39;left&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;bottom&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="linestyle" tabindex="-1">LineStyle <a class="header-anchor" href="#linestyle" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">LineStyle</span> <span class="token operator">=</span> <span class="token string">&#39;solid&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;dashed&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;dotted&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;none&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="type" tabindex="-1">Type <a class="header-anchor" href="#type" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">Type</span> <span class="token operator">=</span> <span class="token string">&#39;primary&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;success&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;warning&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;error&#39;</span><span class="token punctuation">;</span>
</code></pre></div><h4 id="position" tabindex="-1">Position <a class="header-anchor" href="#position" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">Position</span> <span class="token operator">=</span> <span class="token string">&#39;top&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;bottom&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;left&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;right&#39;</span><span class="token punctuation">;</span>
</code></pre></div>`,19);function nt(u,p,s,a,e,d){const o=C("render-demo-0"),l=C("demo"),m=C("render-demo-1"),r=C("render-demo-2"),k=C("render-demo-3"),E=C("render-demo-4");return j(),M("div",null,[G,y(l,{sourceCode:`<template>
  <div>
    <n-radio-group direction="row" v-model="choose">
      <n-radio v-for="item in list" :key="item" :value="item">
        {{ item }}
      </n-radio>
    </n-radio-group>
    <n-timeline :direction="choose" center>
      <n-timeline-item center v-for="(item, index) in timeAxisList" :key="index" :time="item.time" :dot-color="item.dotColor">
        {{ item.text }}
      </n-timeline-item>
    </n-timeline>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const list = ref(['vertical', 'horizontal']);
    const choose = ref('vertical');
    const timeAxisList = ref([
      {
        text: 'Download',
        time: '2021-10-1',
      },
      {
        text: 'Check',
        time: '2021-10-2',
        dotColor: 'var(--nancalui-success)',
      },
      {
        text: 'Build',
        time: '2021-10-3',
        dotColor: 'var(--nancalui-danger)',
      },
      {
        text: 'Depoy',
        time: '2021-10-4',
        dotColor: 'var(--nancalui-warning)',
      },
      {
        text: 'End',
        time: '2021-10-5',
        dotColor: 'var(--nancalui-waiting)',
      },
    ]);
    return { timeAxisList, list, choose };
  },
});
<\/script>
`},{highlight:h(()=>[H]),default:h(()=>[y(o)]),_:1}),J,y(l,{sourceCode:`<template>
  <n-timeline direction="horizontal" center>
    <n-timeline-item
      v-for="(item, index) in timeAxisList"
      :key="index"
      :dot-color="item.dotColor"
      :line-style="item.lineStyle"
      :line-color="item.lineColor"
    >
      <template #time>
        <div>{{ item.time }}</div>
      </template>
      <template #dot v-if="item.dot">
        <n-icon :name="item.dot"></n-icon>
      </template>
      {{ item.text }}
    </n-timeline-item>
  </n-timeline>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const timeAxisList = ref([
      {
        text: 'Start',
        time: '2021-10-1',
        lineStyle: 'solid',
        dot: 'cancel-forbidden',
      },
      {
        text: 'Check',
        time: '2021-10-2',
        dotColor: 'var(--nancalui-success)',
        lineStyle: 'dashed',
        lineColor: 'var(--nancalui-success)',
        dot: 'classroom-approve',
      },
      {
        text: 'Debug',
        time: '2021-10-3',
        dotColor: 'var(--nancalui-info)',
        lineStyle: 'dotted',
        lineColor: 'var(--nancalui-info)',
        dot: 'add-bug',
      },
      {
        text: 'Build',
        time: '2021-10-4',
        dotColor: 'var(--nancalui-warning)',
        lineStyle: 'none',
        lineColor: 'var(--nancalui-warning)',
        dot: 'build-with-tool',
      },
      {
        text: 'Display',
        time: '2021-10-5',
        dotColor: 'var(--nancalui-danger)',
        dot: 'go-chart',
      },
    ]);
    return { timeAxisList };
  },
});
<\/script>
`},{highlight:h(()=>[K]),default:h(()=>[y(m)]),_:1}),O,Q,y(l,{sourceCode:`<template>
  <n-timeline direction="horizontal" mode="alternative">
    <n-timeline-item v-for="(item, index) in timeAxisList" :key="index" :dot-color="item.dotColor" line-style="dashed">
      <template #default="data">
        <div style="position: relative">
          <div
            v-if="data.position === 'bottom'"
            style="margin-bottom: 4px; position: relative; left: 4px; width: 2px; height: 40px; background-color: #e1e1e1"
          ></div>
          <div
            :style="{
              'border-left': '4px solid',
              'box-shadow': '0 2px 4px 0 rgba(0, 0, 0, 0.1)',
              padding: '12px 8px',
              borderColor: item.dotColor,
              backgroundColor: item.backgroundColor,
            }"
          >
            <div style="padding-bottom: 8px; font-size: 14px; font-weight: bold">{{ item.title }}</div>
            <div style="padding-bottom: 8px">\u53D1\u5E03\u65E5\u671F\uFF1A{{ item.date }}</div>
            <div style="padding-bottom: 8px">
              \u7248\u672C\u72B6\u6001\uFF1A
              <n-tag :color="item.dotColor">{{ item.status }}</n-tag>
            </div>
          </div>
          <div
            v-if="data.position === 'top'"
            style="margin-top: 4px; position: relative; left: 4px; width: 2px; height: 40px; background-color: #e1e1e1"
          ></div>
        </div>
      </template>
      <template #extra v-if="index === 0">
        <div style="text-align: center; width: 36px; height: 36px; border-radius: 18px; border: 2px solid #e1e1e1; background: white">
          <span style="line-height: 32px">2020</span>
        </div>
      </template>
    </n-timeline-item>
  </n-timeline>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const timeAxisList = ref([
      {
        text: 'hello',
        dotColor: 'var(--nancalui-success)',
        extraElement: {},
        title: '\u7B2C\u56DB\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0',
        date: '2019/11/01',
        status: '\u5DF2\u53D1\u5E03',
      },
      {
        text: 'world',
        dotColor: 'var(--nancalui-danger)',
        title: '\u7B2C\u4E00\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C2.0',
        date: '2020/03/01',
        backgroundColor: 'rgba(255, 230, 230, 0.2)',
        status: '\u672A\u5F00\u59CB',
      },
      {
        text: 'nihao',
        dotColor: 'var(--nancalui-warning)',
        title: '\u7B2C\u4E8C\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0',
        date: '2020/05/01',
        status: '\u8FDB\u884C\u4E2D',
      },
      {
        text: 'nancalui',
        dotColor: 'var(--nancalui-danger)',
        title: '\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0',
        date: '2020/09/01',
        status: '\u672A\u5F00\u59CB',
      },
      {
        text: 'Awesome',
        dotColor: 'var(--nancalui-success)',
        title: '\u7B2C\u4E09\u5B63\u5EA6\u4EA4\u4ED8\u7248\u672C1.0',
        date: '2020/11/01',
        status: '\u5DF2\u53D1\u5E03',
      },
    ]);
    return { timeAxisList };
  },
});
<\/script>
`},{highlight:h(()=>[R]),default:h(()=>[y(r)]),_:1}),W,y(l,{sourceCode:`<template>
  <h5><p>\u5F53 direction \u4E3A horizontal \u65F6 position \u9ED8\u8BA4 bottom</p></h5>
  <n-timeline direction="horizontal" center>
    <n-timeline-item position="top" dot-color="chocolate">Download</n-timeline-item>
    <n-timeline-item dot-color="var(--nancalui-success)">Check</n-timeline-item>
    <n-timeline-item position="top" dot-color="var(--nancalui-danger)">Build</n-timeline-item>
    <n-timeline-item dot-color="var(--nancalui-warning)">Depoy</n-timeline-item>
    <n-timeline-item position="top" dot-color="var(--nancalui-waiting)">End</n-timeline-item>
  </n-timeline>
  <h5><p>\u5F53 direction \u4E3A vertical \u65F6 position \u9ED8\u8BA4 right</p></h5>
  <n-timeline direction="vertical">
    <n-timeline-item position="left" dot-color="chocolate">Download</n-timeline-item>
    <n-timeline-item position="right" dot-color="var(--nancalui-success)">Check</n-timeline-item>
    <n-timeline-item position="left" dot-color="var(--nancalui-danger)">Build</n-timeline-item>
    <n-timeline-item position="right" dot-color="var(--nancalui-warning)">Depoy</n-timeline-item>
    <n-timeline-item position="left" dot-color="var(--nancalui-waiting)">End</n-timeline-item>
  </n-timeline>
</template>
`},{highlight:h(()=>[X]),default:h(()=>[y(k)]),_:1}),Y,y(l,{sourceCode:`<template>
  <n-timeline time-position="bottom">
    <n-timeline-item time="2019" time-position="left">Download</n-timeline-item>
    <n-timeline-item time="11-2" type="success">Check</n-timeline-item>
    <n-timeline-item time="2020" type="warning" time-position="left">Build</n-timeline-item>
    <n-timeline-item time="11-4" type="error">Depoy</n-timeline-item>
    <n-timeline-item time="2021" type="primary" time-position="left">End</n-timeline-item>
  </n-timeline>
</template>
`},{highlight:h(()=>[Z]),default:h(()=>[y(E)]),_:1}),tt])}var ct=$(U,[["render",nt]]);export{lt as __pageData,ct as default};
