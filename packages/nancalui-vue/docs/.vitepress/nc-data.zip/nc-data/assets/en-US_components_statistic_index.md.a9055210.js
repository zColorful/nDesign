import{V as q}from"./framework.1c17ccd8.js";import{_ as C}from"./plugin-vue_export-helper.21dcd24c.js";import{f as h,G as S,H as N,b as k,a6 as d,V as w,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const R={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:e,createVNode:s,withCtx:a,openBlock:o,createElementBlock:u}=q;function i(l,m){const p=e("n-statistic"),c=e("n-col"),r=e("n-row");return o(),u("div",null,[s(r,null,{default:a(()=>[s(c,{span:12},{default:a(()=>[s(p,{title:"Users Sales","group-separator":",",value:5201314})]),_:1}),s(c,{span:12},{default:a(()=>[s(p,{title:"Account Weekly Sales (CNY)","group-separator":".",value:999999})]),_:1})]),_:1})])}return{render:i,...{}}}(),"render-demo-1":function(){const{resolveComponent:e,createVNode:s,withCtx:a,createElementVNode:o,createTextVNode:u,openBlock:i,createElementBlock:g}=q,l=o("span",null,"%",-1);function m(c,r){const _=e("n-statistic"),f=e("n-card"),v=e("n-col"),x=e("n-button"),y=e("n-row");return i(),g("div",null,[s(y,{gutter:16},{default:a(()=>[s(v,{span:12},{default:a(()=>[s(f,null,{default:a(()=>[s(_,{title:"Animation Growth Rate",value:88.265,suffix:"%","value-from":0,start:c.start,"animation-duration":5e3,animation:""},null,8,["start"])]),_:1})]),_:1}),s(v,{span:12},{default:a(()=>[s(f,null,{default:a(()=>[s(_,{title:"Animation Decline Rate",value:"53",precision:3,"value-from":0,start:c.controlStart,animation:""},{suffix:a(()=>[l,s(x,{onClick:r[0]||(r[0]=b=>c.controlStart=!0)},{default:a(()=>[u("Start")]),_:1})]),_:1},8,["start"])]),_:1})]),_:1})]),_:1})])}return{render:m,...{data(){return{start:!0,controlStart:!1}}}}}(),"render-demo-2":function(){const{createElementVNode:e,resolveComponent:s,createVNode:a,withCtx:o,openBlock:u,createElementBlock:i}=q,g=e("span",{style:{marginRight:"10px"}},"Number of articles read",-1),l=e("span",{style:{fontSize:"13px",marginRight:"10px"}},"Compared before yesterday",-1),m=e("span",{style:{marginRight:"10px"}},"Number of article likes",-1),p=e("span",{style:{fontSize:"13px",marginRight:"10px"}},"Compared before yesterday",-1);function c(_,f){const v=s("n-icon"),x=s("n-statistic"),y=s("n-col"),b=s("n-row");return u(),i("div",null,[a(b,{gutter:16},{default:o(()=>[a(y,{span:12},{default:o(()=>[a(x,{value:336969,style:{"margin-right":"50px"},"group-separator":",","value-style":{fontWeight:"bold",fontSize:"30px"},animation:""},{title:o(()=>[g,a(v,{name:"help"})]),extra:o(()=>[l,a(v,{color:"#F56C6C",name:"arrow-down"}),a(x,{style:{display:"inline-block"},"group-separator":",","value-style":{fontSize:"15px",color:"#F56C6C",letterSpacing:"2px"},value:"1399",animation:""})]),_:1})]),_:1}),a(y,{span:12},{default:o(()=>[a(x,{value:5565566,style:{"margin-right":"50px"},"group-separator":",","value-style":{fontWeight:"bold",fontSize:"30px"},animation:"","animation-duration":5e3},{title:o(()=>[m,a(v,{name:"help"})]),extra:o(()=>[p,a(v,{color:"#67C23A",name:"arrow-up"}),a(x,{style:{display:"inline-block"},"value-style":{fontSize:"15px",color:"#67C23A",letterSpacing:"2px"},value:"6669",animation:"","group-separator":",","animation-duration":5e3})]),_:1})]),_:1})]),_:1})])}return{render:c,...{}}}(),"render-demo-3":function(){const{resolveComponent:e,createVNode:s,withCtx:a,openBlock:o,createElementBlock:u}=q;function i(l,m){const p=e("n-icon"),c=e("n-statistic"),r=e("n-card"),_=e("n-col"),f=e("n-row");return o(),u("div",null,[s(f,{gutter:16},{default:a(()=>[s(_,{span:12},{default:a(()=>[s(r,null,{default:a(()=>[s(c,{"value-style":{color:"#fba"},title:"Growth Rate",value:68.28,precision:3,suffix:"%"},{prefix:a(()=>[s(p,{name:"experice-new"})]),_:1})]),_:1})]),_:1}),s(_,{span:12},{default:a(()=>[s(r,null,{default:a(()=>[s(c,{"value-style":{color:"#abf"},title:"Decline Rate",value:38.3,suffix:"%"},{prefix:a(()=>[s(p,{name:"bold"})]),_:1})]),_:1})]),_:1})]),_:1})])}return{render:i,...{}}}()}},J='{"title":"Statistic","description":"","frontmatter":{},"headers":[{"level":3,"title":"When to use","slug":"when-to-use"},{"level":3,"title":"Basic Usage","slug":"basic-usage"},{"level":3,"title":"Numerical animation","slug":"numerical-animation"},{"level":3,"title":"Use of slots","slug":"use-of-slots"},{"level":3,"title":"Use in card","slug":"use-in-card"},{"level":3,"title":"n-statistic","slug":"n-statistic"}],"relativePath":"en-US/components/statistic/index.md","lastUpdated":1672994787142}',E=w('<h1 id="statistic" tabindex="-1">Statistic <a class="header-anchor" href="#statistic" aria-hidden="true">#</a></h1><h3 id="when-to-use" tabindex="-1">When to use <a class="header-anchor" href="#when-to-use" aria-hidden="true">#</a></h3><p>Used when it is necessary to display statistical data with description</p><h3 id="basic-usage" tabindex="-1">Basic Usage <a class="header-anchor" href="#basic-usage" aria-hidden="true">#</a></h3>',4),V=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-row")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Users Sales"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(","),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5201314"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Account Weekly Sales (CNY)"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("."),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("999999"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-row")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),B=t("h3",{id:"numerical-animation",tabindex:"-1"},[n("Numerical animation "),t("a",{class:"header-anchor",href:"#numerical-animation","aria-hidden":"true"},"#")],-1),z=t("p",null,"We can start numerical animation by setting the animation attribute. You can start the animation when the page loads, or you can control it manually",-1),A=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-row")]),n(),t("span",{class:"token attr-name"},":gutter"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("16"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(`
          `),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Animation Growth Rate"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("88.265"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},"suffix"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("%"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},":value-from"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("0"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},":start"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("start"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},":animation-duration"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5000"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token attr-name"},"animation"),n(`
        `),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Animation Decline Rate"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("53"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":precision"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value-from"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("0"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":start"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("controlStart"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"animation"),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#suffix"),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),t("span",{class:"token punctuation"},">")]),n("%"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("controlStart = true"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Start"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-row")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"data"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token literal-property property"},"start"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token literal-property property"},"controlStart"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),U=t("h3",{id:"use-of-slots",tabindex:"-1"},[n("Use of slots "),t("a",{class:"header-anchor",href:"#use-of-slots","aria-hidden":"true"},"#")],-1),W=t("p",null,"Prefix slot, suffix slot, extra slot",-1),D=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-row")]),n(),t("span",{class:"token attr-name"},":gutter"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("16"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(`
        `),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("336969"),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-right"),t("span",{class:"token punctuation"},":"),n(" 50px")]),t("span",{class:"token punctuation"},'"')])]),n(`
        `),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(","),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontWeight: 'bold', fontSize: '30px' }"),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token attr-name"},"animation"),n(`
      `),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#title"),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),n(),t("span",{class:"token attr-name"},":style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ marginRight: '10px' }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Number of articles read"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("help"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#extra"),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),n(),t("span",{class:"token attr-name"},":style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontSize: '13px', marginRight: '10px' }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Compared before yesterday"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("#F56C6C"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("arrow-down"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(`
            `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" inline-block"),t("span",{class:"token punctuation"},";")]),t("span",{class:"token punctuation"},'"')])]),n(`
            `),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(","),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontSize: '15px', color: '#F56C6C', letterSpacing: '2px' }"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},"value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("1399"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},"animation"),n(`
          `),t("span",{class:"token punctuation"},"/>")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(`
        `),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5565566"),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-right"),t("span",{class:"token punctuation"},":"),n(" 50px")]),t("span",{class:"token punctuation"},'"')])]),n(`
        `),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(","),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontWeight: 'bold', fontSize: '30px' }"),t("span",{class:"token punctuation"},'"')]),n(`
        `),t("span",{class:"token attr-name"},"animation"),n(`
        `),t("span",{class:"token attr-name"},":animation-duration"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5000"),t("span",{class:"token punctuation"},'"')]),n(`
      `),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#title"),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),n(),t("span",{class:"token attr-name"},":style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ marginRight: '10px' }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Number of article likes"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("help"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#extra"),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),n(),t("span",{class:"token attr-name"},":style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontSize: '13px', marginRight: '10px' }"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Compared before yesterday"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("#67C23A"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("arrow-up"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(`
            `),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" inline-block"),t("span",{class:"token punctuation"},";")]),t("span",{class:"token punctuation"},'"')])]),n(`
            `),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ fontSize: '15px', color: '#67C23A', letterSpacing: '2px' }"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},"value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("6669"),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},"animation"),n(`
            `),t("span",{class:"token attr-name"},"group-separator"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(","),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token attr-name"},":animation-duration"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5000"),t("span",{class:"token punctuation"},'"')]),n(`
          `),t("span",{class:"token punctuation"},"/>")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-row")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),G=t("h3",{id:"use-in-card",tabindex:"-1"},[n("Use in card "),t("a",{class:"header-anchor",href:"#use-in-card","aria-hidden":"true"},"#")],-1),F=t("p",null,"Display statistics in cards.",-1),T=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-row")]),n(),t("span",{class:"token attr-name"},":gutter"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("16"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ color: '#fba' }"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Growth Rate"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("68.28"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":precision"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"suffix"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("%"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#prefix"),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("experice-new"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-col")]),n(),t("span",{class:"token attr-name"},":span"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("12"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-statistic")]),n(),t("span",{class:"token attr-name"},":value-style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("{ color: '#abf' }"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("Decline Rate"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":value"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("38.3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"suffix"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("%"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#prefix"),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-icon")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("bold"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-statistic")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-card")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-col")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-row")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),$=w('<h3 id="n-statistic" tabindex="-1">n-statistic <a class="header-anchor" href="#n-statistic" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">parameter</th><th style="text-align:center;">type</th><th style="text-align:center;">default</th><th style="text-align:center;">introduce</th></tr></thead><tbody><tr><td style="text-align:center;">title</td><td style="text-align:center;"><code>string | v-slot</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Title of value</td></tr><tr><td style="text-align:center;">extra</td><td style="text-align:center;"><code>string | v-slot</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Extra content</td></tr><tr><td style="text-align:center;">value</td><td style="text-align:center;"><code>number | string</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Value content</td></tr><tr><td style="text-align:center;">group-separator</td><td style="text-align:center;"><code>string</code></td><td style="text-align:center;">,</td><td style="text-align:center;">Set group-separator</td></tr><tr><td style="text-align:center;">precision</td><td style="text-align:center;"><code>number</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Set numeric precision</td></tr><tr><td style="text-align:center;">suffix</td><td style="text-align:center;"><code>string | v-slot</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Sets the suffix of the value</td></tr><tr><td style="text-align:center;">prefix</td><td style="text-align:center;"><code>string | v-slot</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Sets the prefix of the value</td></tr><tr><td style="text-align:center;">content-style</td><td style="text-align:center;"><code>style</code></td><td style="text-align:center;">-</td><td style="text-align:center;">Content style</td></tr><tr><td style="text-align:center;">animation-duration</td><td style="text-align:center;"><code>number</code></td><td style="text-align:center;">2000</td><td style="text-align:center;">Animation duration</td></tr><tr><td style="text-align:center;">value-from</td><td style="text-align:center;"><code>number</code></td><td style="text-align:center;">0</td><td style="text-align:center;">Animation initial value</td></tr><tr><td style="text-align:center;">animation</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;">false</td><td style="text-align:center;">Turn on animation</td></tr><tr><td style="text-align:center;">start</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;">false</td><td style="text-align:center;">Start animation</td></tr></tbody></table>',2);function Y(e,s,a,o,u,i){const g=h("render-demo-0"),l=h("demo"),m=h("render-demo-1"),p=h("render-demo-2"),c=h("render-demo-3");return S(),N("div",null,[E,k(l,{sourceCode:`<template>
  <n-row>
    <n-col :span="12">
      <n-statistic title="Users Sales" group-separator="," :value="5201314"> </n-statistic>
    </n-col>
    <n-col :span="12">
      <n-statistic title="Account Weekly Sales (CNY)" group-separator="." :value="999999"> </n-statistic>
    </n-col>
  </n-row>
</template>
`},{highlight:d(()=>[V]),default:d(()=>[k(g)]),_:1}),B,z,k(l,{sourceCode:`<template>
  <n-row :gutter="16">
    <n-col :span="12">
      <n-card>
        <n-statistic
          title="Animation Growth Rate"
          :value="88.265"
          suffix="%"
          :value-from="0"
          :start="start"
          :animation-duration="5000"
          animation
        ></n-statistic>
      </n-card>
    </n-col>
    <n-col :span="12">
      <n-card>
        <n-statistic title="Animation Decline Rate" value="53" :precision="3" :value-from="0" :start="controlStart" animation>
          <template #suffix>
            <span>%</span>
            <n-button @click="controlStart = true">Start</n-button>
          </template>
        </n-statistic>
      </n-card>
    </n-col>
  </n-row>
</template>
<script>
export default {
  data() {
    return {
      start: true,
      controlStart: false,
    };
  },
};
<\/script>
`},{highlight:d(()=>[A]),default:d(()=>[k(m)]),_:1}),U,W,k(l,{sourceCode:`<template>
  <n-row :gutter="16">
    <n-col :span="12">
      <n-statistic
        :value="336969"
        style="margin-right: 50px"
        group-separator=","
        :value-style="{ fontWeight: 'bold', fontSize: '30px' }"
        animation
      >
        <template #title>
          <span :style="{ marginRight: '10px' }">Number of articles read</span>
          <n-icon name="help" />
        </template>
        <template #extra>
          <span :style="{ fontSize: '13px', marginRight: '10px' }">Compared before yesterday</span>
          <n-icon color="#F56C6C" name="arrow-down" />
          <n-statistic
            style="display: inline-block;"
            group-separator=","
            :value-style="{ fontSize: '15px', color: '#F56C6C', letterSpacing: '2px' }"
            value="1399"
            animation
          />
        </template>
      </n-statistic>
    </n-col>
    <n-col :span="12">
      <n-statistic
        :value="5565566"
        style="margin-right: 50px"
        group-separator=","
        :value-style="{ fontWeight: 'bold', fontSize: '30px' }"
        animation
        :animation-duration="5000"
      >
        <template #title>
          <span :style="{ marginRight: '10px' }">Number of article likes</span>
          <n-icon name="help" />
        </template>
        <template #extra>
          <span :style="{ fontSize: '13px', marginRight: '10px' }">Compared before yesterday</span>
          <n-icon color="#67C23A" name="arrow-up" />
          <n-statistic
            style="display: inline-block;"
            :value-style="{ fontSize: '15px', color: '#67C23A', letterSpacing: '2px' }"
            value="6669"
            animation
            group-separator=","
            :animation-duration="5000"
          />
        </template>
      </n-statistic>
    </n-col>
  </n-row>
</template>
`},{highlight:d(()=>[D]),default:d(()=>[k(p)]),_:1}),G,F,k(l,{sourceCode:`<template>
  <n-row :gutter="16">
    <n-col :span="12">
      <n-card>
        <n-statistic :value-style="{ color: '#fba' }" title="Growth Rate" :value="68.28" :precision="3" suffix="%">
          <template #prefix>
            <n-icon name="experice-new" />
          </template>
        </n-statistic>
      </n-card>
    </n-col>
    <n-col :span="12">
      <n-card>
        <n-statistic :value-style="{ color: '#abf' }" title="Decline Rate" :value="38.3" suffix="%">
          <template #prefix>
            <n-icon name="bold" />
          </template>
        </n-statistic>
      </n-card>
    </n-col>
  </n-row>
</template>
`},{highlight:d(()=>[T]),default:d(()=>[k(c)]),_:1}),$])}var K=C(R,[["render",Y]]);export{J as __pageData,K as default};
