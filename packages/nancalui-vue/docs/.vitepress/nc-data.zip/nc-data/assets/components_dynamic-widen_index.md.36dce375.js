import{V as k}from"./framework.1c17ccd8.js";import{_ as D}from"./plugin-vue_export-helper.21dcd24c.js";import{f as r,G as w,H as E,b as d,a6 as u,V as x,I as n,k as a}from"./framework.1f85532f.js";import"./framework.40290dff.js";const B={name:"component-doc",components:{"render-demo-0":function(){const{createElementVNode:t,resolveComponent:e,createVNode:o,withCtx:s,openBlock:l,createElementBlock:i}=k,c={class:"container-main"},p=t("div",null,"1111",-1),m={style:{display:"flex","justify-content":"center","align-items":"center",width:"100%",height:"100%"}},g={style:{cursor:"pointer"}},h=t("div",null,"22222",-1);function _(b,W){const F=e("n-icon"),f=e("NCdynamicWiden");return l(),i("div",null,[t("div",c,[o(f,{pwdith:220,hwidth:15},{left:s(()=>[p]),hwContent:s(({handleDiaplay:y})=>[t("div",m,[t("div",g,[o(F,{name:"like",onClick:y},null,8,["onClick"])])])]),right:s(()=>[h]),_:1})])])}const{defineComponent:v}=k,C=v({setup(){return{}}});return{render:_,...C}}()}},I='{"title":"NCdynamicWiden \u62D6\u62FD\u5DE6\u53F3\u5E03\u5C40","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"}],"relativePath":"components/dynamic-widen/index.md","lastUpdated":1684218049389}',N=x('<h1 id="ncdynamicwiden-\u62D6\u62FD\u5DE6\u53F3\u5E03\u5C40" tabindex="-1">NCdynamicWiden \u62D6\u62FD\u5DE6\u53F3\u5E03\u5C40 <a class="header-anchor" href="#ncdynamicwiden-\u62D6\u62FD\u5DE6\u53F3\u5E03\u5C40" aria-hidden="true">#</a></h1><p>\u62D6\u62FD\u5DE6\u53F3\u5E03\u5C40</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5BF9\u62D6\u62FD\u5BBD\u9AD8\u7EC4\u4EF6\u8FDB\u884C\u7684\u7B80\u5355\u5C01\u88C5\uFF0C\u5F53\u9875\u9762\u53EA\u9700\u8981\u5DE6\u53F3\u7B80\u5355\u62D6\u62FD\u65F6\u4F7F\u7528</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),A=n("div",null,[n("code",null,"pwdith"),a("\u5DE6\u8FB9\u9ED8\u8BA4\u7684\u5BBD\u5EA6\uFF0C"),n("code",null,"hwidth"),a("\u62D6\u62FD\u5143\u7D20\u672C\u8EAB\u7684\u5BBD\u6216\u8005\u9AD8\u5EA6\uFF0C"),n("code",null,"bgcolor"),a("\u62D6\u62FD\u5143\u7D20\u80CC\u666F\uFF0C"),n("code",null,"borderColor"),a("\u62D6\u62FD\u5143\u7D20\u8FB9\u6846\u989C\u8272")],-1),V=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("container-main"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("NCdynamicWiden")]),a(),n("span",{class:"token attr-name"},":pwdith"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("220"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":hwidth"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("15"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#left"),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),n("span",{class:"token punctuation"},">")]),a("1111"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#hwContent"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("{ handleDiaplay }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),a(" flex"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),a(" center"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),a(" center"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a("100%"),n("span",{class:"token punctuation"},";"),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),a("100%")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(`
          `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),a(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"cursor"),n("span",{class:"token punctuation"},":"),a("pointer")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),a(`
            `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-icon")]),a(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("like"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("handleDiaplay"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-icon")]),n("span",{class:"token punctuation"},">")]),a(`
          `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-slot:"),a("right")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("div")]),n("span",{class:"token punctuation"},">")]),a("22222"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("NCdynamicWiden")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("div")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("style")]),a(),n("span",{class:"token attr-name"},"scoped"),a(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[a(`
`),n("span",{class:"token selector"},".container"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token selector"},"&-main"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 100%"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),a(" 300px"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),a(" #ffffff"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("style")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1);function q(t,e,o,s,l,i){const c=r("render-demo-0"),p=r("demo");return w(),E("div",null,[N,d(p,{sourceCode:`<template>
  <div class="container-main">
    <NCdynamicWiden :pwdith="220" :hwidth="15">
      <template #left>
        <div>1111</div>
      </template>
      <template #hwContent="{ handleDiaplay }">
        <div style="display: flex;justify-content: center;align-items: center;width:100%;height:100%">
          <div style="cursor:pointer">
            <n-icon name="like" @click="handleDiaplay"></n-icon>
          </div>
        </div>
      </template>
      <template v-slot:right>
        <div>22222</div>
      </template>
    </NCdynamicWiden>
  </div>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    return {};
  },
});
<\/script>
<style scoped lang="scss">
.container {
  &-main {
    width: 100%;
    height: 300px;
    background: #ffffff;
  }
}
</style>
`},{description:u(()=>[A]),highlight:u(()=>[V]),default:u(()=>[d(c)]),_:1})])}var P=D(B,[["render",q]]);export{I as __pageData,P as default};
