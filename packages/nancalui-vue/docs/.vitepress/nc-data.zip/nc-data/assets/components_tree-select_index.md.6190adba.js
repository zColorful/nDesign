import{V as y}from"./framework.1c17ccd8.js";import{_ as I}from"./plugin-vue_export-helper.21dcd24c.js";import{f as v,G as x,H as T,b as E,a6 as m,I as n,k as a,V as q}from"./framework.1f85532f.js";import"./framework.40290dff.js";const V={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:c,resolveComponent:r,withCtx:k,createVNode:u,openBlock:i,createElementBlock:d}=y;function p(e,b){const h=r("n-button"),A=r("n-tree-select");return i(),d("div",null,[u(h,{onClick:e.clearSelect},{default:k(()=>[c("\u624B\u52A8\u6E05\u9664")]),_:1},8,["onClick"]),u(A,{modelValue:e.value,"onUpdate:modelValue":b[0]||(b[0]=f=>e.value=f),treeData:e.data,prop:e.prop,placeholder:"\u6811\u5F62\u9009\u62E9\u6846",onValueChange:e.valueChange,size:"sm"},null,8,["modelValue","treeData","prop","onValueChange"])])}const{defineComponent:o,onMounted:s,ref:t}=y,l=o({setup(){const e=t("1"),b=t({label:"name",children:"childArr"}),h=()=>{e.value=""},A=t([{name:"\u4E00\u7EA7 1",value:"1",childArr:[{name:"\u4E8C\u7EA7 1-1",value:"1-1",disabled:!0,childArr:[{name:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{name:"\u4E00\u7EA7 2",value:"2",childArr:[{name:"\u4E8C\u7EA7 2-1",value:"2-1",childArr:[{name:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{name:"\u4E8C\u7EA7 2-2",value:"2-2",childArr:[{name:"\u4E09\u7EA7 2-2-1",value:"2-2-1"}]}]},{name:"\u4E00\u7EA7 3",value:"3",childArr:[{name:"\u4E8C\u7EA7 3-1",value:"3-1",childArr:[{name:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{name:"\u4E8C\u7EA7 3-2",value:"3-2",childArr:[{name:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]);function f(F){console.log("data",F),console.log("value",e)}return s(()=>{setTimeout(function(){A.value[0].name="\u6539\u53D8\u6570\u636E"},5e3)}),{data:A,value:e,prop:b,valueChange:f,clearSelect:h}}});return{render:p,...l}}(),"render-demo-1":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,disabled:!0},null,8,["modelValue","treeData"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p("");return{data:p([{label:"\u4E00\u7EA7 1",value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",children:[{label:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",children:[{label:"\u4E8C\u7EA7 2-1",value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1"},{label:"\u4E09\u7EA7 2-2-2",value:"2-2-2",disabled:!0}]}]},{label:"\u4E00\u7EA7 3",value:"3",children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]),value:s}}});return{render:i,...o}}(),"render-demo-2":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,allowClear:!0},null,8,["modelValue","treeData"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p("");return{data:p([{label:"\u4E00\u7EA7 1",value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",children:[{label:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",children:[{label:"\u4E8C\u7EA7 2-1",value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1"},{label:"\u4E09\u7EA7 2-2-2",value:"2-2-2"}]}]},{label:"\u4E00\u7EA7 3",value:"3",children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]),value:s}}});return{render:i,...o}}(),"render-demo-3":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,multiple:!0,allowClear:!0,enableLabelization:!0,onValueChange:s.valueChange},null,8,["modelValue","treeData","onValueChange"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p(["1","2"]),t=p([{label:"\u4E00\u7EA7 1",value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",children:[{label:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",children:[{label:"\u4E8C\u7EA7 2-1",value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1"},{label:"\u4E09\u7EA7 2-2-2",value:"2-2-2"}]}]},{label:"\u4E00\u7EA7 3",value:"3",children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]);function l(e){console.log("data",e),console.log("value",s)}return{data:t,value:s,valueChange:l}}});return{render:i,...o}}(),"render-demo-4":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,filter:"",multiple:!0,allowClear:!0,enableLabelization:!0,onValueChange:s.valueChange},null,8,["modelValue","treeData","onValueChange"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p([]),t=p([{label:"\u4E00\u7EA7 1",value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",children:[{label:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",children:[{label:"\u4E8C\u7EA7 2-1",value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1"},{label:"\u4E09\u7EA7 2-2-2",value:"2-2-2"}]}]},{label:"\u4E00\u7EA7 3",value:"3",children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]);function l(e){console.log("data",e),console.log("value",s)}return{data:t,value:s,valueChange:l}}});return{render:i,...o}}(),"render-demo-5":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,leafOnly:!0},null,8,["modelValue","treeData"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p("");return{data:p([{label:"\u4E00\u7EA7 1",value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",children:[{label:"\u4E09\u7EA7 1-1-1",value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",children:[{label:"\u4E8C\u7EA7 2-1",value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1"}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1"},{label:"\u4E09\u7EA7 2-2-2",value:"2-2-2"}]}]},{label:"\u4E00\u7EA7 3",value:"3",children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1"}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1"}]}]}]),value:s}}});return{render:i,...o}}(),"render-demo-6":function(){const{createElementVNode:c,normalizeStyle:r,openBlock:k,createElementBlock:u,toDisplayString:i,normalizeClass:d,resolveComponent:p,withCtx:o,createVNode:s}=y,t=["onClick"],e=[c("path",{d:"M204.58705 951.162088 204.58705 72.836889 819.41295 511.998977Z",fill:"#8a8e99"},null,-1)];function b(C,_){const w=p("n-tree-select");return k(),u("div",null,[s(w,{modelValue:C.node.value,"onUpdate:modelValue":_[0]||(_[0]=g=>C.node.value=g),treeData:C.data},{icon:o(({nodeData:g,toggleNode:B})=>[c("span",{onClick:D=>{D.stopPropagation(),B(g)}},[(k(),u("svg",{style:r({transform:g.expanded?"rotate(90deg)":"",marginLeft:"-2.5px",marginRight:"14.5px",cursor:"pointer"}),viewBox:"0 0 1024 1024",width:"12",height:"12"},e,4))],8,t)]),default:o(({item:g})=>{var B;return[c("span",{class:d(["tree-select-demo-icon",[(B=g==null?void 0:g.data)==null?void 0:B.type]])},i(g.label),3)]}),_:1},8,["modelValue","treeData"])])}const{defineComponent:h,ref:A,reactive:f}=y,F=h({setup(){const C=f({value:""});return{data:A([{label:"\u4E00\u7EA7 1",data:{type:"ppt"},value:"1",children:[{label:"\u4E8C\u7EA7 1-1",value:"1-1",data:{type:"doc"},children:[{label:"\u4E09\u7EA7 1-1-1",data:{type:"ppt"},value:"1-1-1"}]}]},{label:"\u4E00\u7EA7 2",value:"2",data:{type:"doc"},children:[{label:"\u4E8C\u7EA7 2-1",data:{type:"ppt"},value:"2-1",children:[{label:"\u4E09\u7EA7 2-1-1",value:"2-1-1",data:{type:"xls"}}]},{label:"\u4E8C\u7EA7 2-2",value:"2-2",data:{type:"pdf"},children:[{label:"\u4E09\u7EA7 2-2-1",value:"2-2-1",data:{type:"xls"}}]}]},{label:"\u4E00\u7EA7 3",value:"3",data:{type:"pdf"},children:[{label:"\u4E8C\u7EA7 3-1",value:"3-1",data:{type:"mix"},children:[{label:"\u4E09\u7EA7 3-1-1",value:"3-1-1",data:{type:"doc"}}]},{label:"\u4E8C\u7EA7 3-2",value:"3-2",data:{type:"doc"},children:[{label:"\u4E09\u7EA7 3-2-1",value:"3-2-1",data:{type:"xls"}}]}]}]),node:C}}});return{render:b,...F}}(),"render-demo-7":function(){const{resolveComponent:c,createVNode:r,openBlock:k,createElementBlock:u}=y;function i(s,t){const l=c("n-tree-select");return k(),u("div",null,[r(l,{modelValue:s.value,"onUpdate:modelValue":t[0]||(t[0]=e=>s.value=e),treeData:s.data,prop:s.treeProps,multiple:!0,enableLabelization:""},null,8,["modelValue","treeData","prop"])])}const{defineComponent:d,ref:p}=y,o=d({setup(){const s=p([213,341,311]),t=p({label:"name",children:"children",value:"id"});return{data:p([{id:213,standardModelId:324,code:"DEPT0000000101",name:"\u6D4B\u8BD5\u90E8\u95E81",remark:null,createTime:"2022-12-29 13:37:39",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"9b9086a1-ce55-4b26-9173-499415854ac1",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[{id:341,standardModelId:999999999,code:null,name:"3453",remark:null,createTime:"2023-04-26 17:13:31",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"4766ef76-18a2-4957-b8b3-bd3cff933940",quoteObjectId:null,customProperties:null,parentFrontId:"9b9086a1-ce55-4b26-9173-499415854ac1",createByName:"admin",children:[]}]},{id:311,standardModelId:999999999,code:null,name:"\u90E8\u95E8111aaa",remark:null,createTime:"2023-02-01 16:55:56",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"61bceb1d-1eb6-41ec-ab2d-8754a67379ba",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[]},{id:307,standardModelId:999999999,code:null,name:"\u90E8\u95E8222",remark:null,createTime:"2023-02-01 16:50:02",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"7594c5fe-5f4e-4692-a11f-9b97743fac34",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[]},{id:221,standardModelId:401,code:"DEPT0000000111",name:"b1",remark:null,createTime:"2023-01-05 14:40:53",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"7afdff47-b043-4d1b-96ef-182c9fb8d79e",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[]},{id:309,standardModelId:999999999,code:null,name:"\u90E8\u95E8220aaa",remark:null,createTime:"2023-02-01 16:51:52",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"ab83b814-8e87-4a9f-aa37-8c089017cade",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[]},{id:306,standardModelId:999999999,code:null,name:"\u90E8\u95E8444",remark:null,createTime:"2023-02-01 15:29:25",createBy:null,updateTime:null,updateBy:null,deleted:null,frontId:"75178c3f-b2aa-48c2-820e-d31d3f7c3282",quoteObjectId:null,customProperties:null,parentFrontId:null,createByName:"admin",children:[]}]),value:s,treeProps:t}}});return{render:i,...o}}()}},en='{"title":"TreeSelect \u6811\u5F62\u9009\u62E9\u6846","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u7981\u7528","slug":"\u7981\u7528"},{"level":3,"title":"\u53EF\u6E05\u7A7A","slug":"\u53EF\u6E05\u7A7A"},{"level":3,"title":"\u591A\u9009","slug":"\u591A\u9009"},{"level":3,"title":"\u53EF\u7B5B\u9009","slug":"\u53EF\u7B5B\u9009"},{"level":3,"title":"\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009","slug":"\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u56FE\u6807","slug":"\u81EA\u5B9A\u4E49\u56FE\u6807"},{"level":3,"title":"\u6807\u7B7E\u5316","slug":"\u6807\u7B7E\u5316"},{"level":3,"title":"TreeSelect \u53C2\u6570","slug":"treeselect-\u53C2\u6570"},{"level":3,"title":"TreeSelect \u4E8B\u4EF6","slug":"treeselect-\u4E8B\u4EF6"},{"level":3,"title":"\u63A5\u53E3 & \u7C7B\u578B\u5B9A\u4E49","slug":"\u63A5\u53E3-\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/tree-select/index.md","lastUpdated":1686539785744}',N=n("h1",{id:"treeselect-\u6811\u5F62\u9009\u62E9\u6846",tabindex:"-1"},[a("TreeSelect \u6811\u5F62\u9009\u62E9\u6846 "),n("a",{class:"header-anchor",href:"#treeselect-\u6811\u5F62\u9009\u62E9\u6846","aria-hidden":"true"},"#")],-1),P=n("p",null,"\u4E00\u79CD\u4ECE\u5217\u8868\u4E2D\u9009\u62E9\u5D4C\u5957\u7ED3\u6784\u6570\u636E\u7684\u7EC4\u4EF6\u3002",-1),j=n("h3",{id:"\u57FA\u672C\u7528\u6CD5",tabindex:"-1"},[a("\u57FA\u672C\u7528\u6CD5 "),n("a",{class:"header-anchor",href:"#\u57FA\u672C\u7528\u6CD5","aria-hidden":"true"},"#")],-1),M=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-button")]),a(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("clearSelect"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("\u624B\u52A8\u6E05\u9664"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-button")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(`
    `),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":prop"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("prop"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"placeholder"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("\u6811\u5F62\u9009\u62E9\u6846"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"@valueChange"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("valueChange"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"size"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("sm"),n("span",{class:"token punctuation"},'"')]),a(`
  `),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" onMounted"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" prop "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'childArr'"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"const"),a(),n("span",{class:"token function-variable function"},"clearSelect"),a(),n("span",{class:"token operator"},"="),a(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token operator"},"=>"),a(),n("span",{class:"token punctuation"},"{"),a(`
      value`),n("span",{class:"token punctuation"},"."),a("value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"disabled"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"childArr"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"function"),a(),n("span",{class:"token function"},"valueChange"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"data"),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'data'"),n("span",{class:"token punctuation"},","),a(" data"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'value'"),n("span",{class:"token punctuation"},","),a(" value"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`

    `),n("span",{class:"token comment"},`/*
      \u6D4B\u8BD5\u76D1\u542CtreeData\u6539\u53D8\uFF0C\u89E3\u51B3\u6709value\u4E4B\u540E\u624D\u6709treeData\u7684\u56DE\u663E\u95EE\u9898
    */`),a(`
    `),n("span",{class:"token function"},"onMounted"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token operator"},"=>"),a(),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token function"},"setTimeout"),n("span",{class:"token punctuation"},"("),n("span",{class:"token keyword"},"function"),a(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
        data`),n("span",{class:"token punctuation"},"."),a("value"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),a("name "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token string"},"'\u6539\u53D8\u6570\u636E'"),n("span",{class:"token punctuation"},";"),a(`
        `),n("span",{class:"token comment"},"// console.log(dataArr, 'dataArr');"),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token number"},"5000"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
      prop`),n("span",{class:"token punctuation"},","),a(`
      valueChange`),n("span",{class:"token punctuation"},","),a(`
      clearSelect`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),O=n("h3",{id:"\u7981\u7528",tabindex:"-1"},[a("\u7981\u7528 "),n("a",{class:"header-anchor",href:"#\u7981\u7528","aria-hidden":"true"},"#")],-1),S=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":disabled"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"disabled"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),z=n("h3",{id:"\u53EF\u6E05\u7A7A",tabindex:"-1"},[a("\u53EF\u6E05\u7A7A "),n("a",{class:"header-anchor",href:"#\u53EF\u6E05\u7A7A","aria-hidden":"true"},"#")],-1),L=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":allowClear"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-2'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),U=n("h3",{id:"\u591A\u9009",tabindex:"-1"},[a("\u591A\u9009 "),n("a",{class:"header-anchor",href:"#\u591A\u9009","aria-hidden":"true"},"#")],-1),$=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(`
    `),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":multiple"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":allowClear"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":enableLabelization"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"@valueChange"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("valueChange"),n("span",{class:"token punctuation"},'"')]),a(`
  `),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-2'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"function"),a(),n("span",{class:"token function"},"valueChange"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"data"),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'data'"),n("span",{class:"token punctuation"},","),a(" data"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'value'"),n("span",{class:"token punctuation"},","),a(" value"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
      valueChange`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),R=n("h3",{id:"\u53EF\u7B5B\u9009",tabindex:"-1"},[a("\u53EF\u7B5B\u9009 "),n("a",{class:"header-anchor",href:"#\u53EF\u7B5B\u9009","aria-hidden":"true"},"#")],-1),Z=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(`
    `),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"filter"),a(`
    `),n("span",{class:"token attr-name"},":multiple"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":allowClear"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},":enableLabelization"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(`
    `),n("span",{class:"token attr-name"},"@valueChange"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("valueChange"),n("span",{class:"token punctuation"},'"')]),a(`
  `),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-2'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"function"),a(),n("span",{class:"token function"},"valueChange"),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"data"),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'data'"),n("span",{class:"token punctuation"},","),a(" data"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'value'"),n("span",{class:"token punctuation"},","),a(" value"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token punctuation"},"}"),a(`
    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
      valueChange`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),W=n("h3",{id:"\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009",tabindex:"-1"},[a("\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009 "),n("a",{class:"header-anchor",href:"#\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009","aria-hidden":"true"},"#")],-1),X=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":leafOnly"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-2'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-2'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),G=n("h3",{id:"\u81EA\u5B9A\u4E49\u56FE\u6807",tabindex:"-1"},[a("\u81EA\u5B9A\u4E49\u56FE\u6807 "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u56FE\u6807","aria-hidden":"true"},"#")],-1),H=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("node.value"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#icon"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("{ nodeData, toggleNode }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),a(`
        `),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a(`
          (event) => {
            event.stopPropagation();
            toggleNode(nodeData);
          }
        `),n("span",{class:"token punctuation"},'"')]),a(`
      `),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("svg")]),a(`
          `),n("span",{class:"token attr-name"},":style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("{ transform: nodeData.expanded ? 'rotate(90deg)' : '', marginLeft: '-2.5px', marginRight: '14.5px', cursor: 'pointer' }"),n("span",{class:"token punctuation"},'"')]),a(`
          `),n("span",{class:"token attr-name"},"viewBox"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("0 0 1024 1024"),n("span",{class:"token punctuation"},'"')]),a(`
          `),n("span",{class:"token attr-name"},"width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("12"),n("span",{class:"token punctuation"},'"')]),a(`
          `),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("12"),n("span",{class:"token punctuation"},'"')]),a(`
        `),n("span",{class:"token punctuation"},">")]),a(`
          `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("path")]),a(),n("span",{class:"token attr-name"},"d"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("M204.58705 951.162088 204.58705 72.836889 819.41295 511.998977Z"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},"fill"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("#8a8e99"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("path")]),n("span",{class:"token punctuation"},">")]),a(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("svg")]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),a(),n("span",{class:"token attr-name"},"#default"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("{ item }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("span")]),a(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("tree-select-demo-icon"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("[item?.data?.type]"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),a("{{ item.label }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("span")]),n("span",{class:"token punctuation"},">")]),a(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref"),n("span",{class:"token punctuation"},","),a(" reactive "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" node "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"''"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'ppt'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'doc'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 1-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'ppt'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'1-1-1'"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'doc'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'ppt'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'xls'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'pdf'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'xls'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E00\u7EA7 3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'pdf'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'mix'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-1-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'doc'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E8C\u7EA7 3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'doc'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
              `),n("span",{class:"token punctuation"},"{"),a(`
                `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u4E09\u7EA7 3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3-2-1'"),n("span",{class:"token punctuation"},","),a(`
                `),n("span",{class:"token literal-property property"},"data"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"{"),a(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'xls'"),a(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
              `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      node`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[a(`
`),n("span",{class:"token selector"},".tree-select-demo-icon::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),a(" 16px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"font-style"),n("span",{class:"token punctuation"},":"),a(" italic"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"font-size"),n("span",{class:"token punctuation"},":"),a(" 12px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),a(" 14px"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),a(" inline-block"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),a(" center"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),a(" #fff"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border-radius"),n("span",{class:"token punctuation"},":"),a(" 2px"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`

`),n("span",{class:"token selector"},".tree-select-demo-icon.doc::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"content"),n("span",{class:"token punctuation"},":"),a(),n("span",{class:"token string"},"'W'"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),a(" #295396"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),a(" 1px #224488 solid"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`

`),n("span",{class:"token selector"},".tree-select-demo-icon.pdf::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"content"),n("span",{class:"token punctuation"},":"),a(),n("span",{class:"token string"},"'A'"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),a(" #da0a0a"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),a(" 1px #dd0000 solid"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`

`),n("span",{class:"token selector"},".tree-select-demo-icon.xls::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"content"),n("span",{class:"token punctuation"},":"),a(),n("span",{class:"token string"},"'X'"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),a(" #207044"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),a(" 1px #18683c solid"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`

`),n("span",{class:"token selector"},".tree-select-demo-icon.ppt::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"content"),n("span",{class:"token punctuation"},":"),a(),n("span",{class:"token string"},"'P'"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),a(" #d14424"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),a(" 1px #dd4422 solid"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`

`),n("span",{class:"token selector"},".tree-select-demo-icon.mix::before"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"content"),n("span",{class:"token punctuation"},":"),a(),n("span",{class:"token string"},"'?'"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"font-style"),n("span",{class:"token punctuation"},":"),a(" normal"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),a(" #aaaaaa"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token property"},"border"),n("span",{class:"token punctuation"},":"),a(" 1px #999999 solid"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`),n("span",{class:"token selector"},".tree-select-demo-icon-next"),a(),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token property"},"margin-left"),n("span",{class:"token punctuation"},":"),a(" 8px"),n("span",{class:"token punctuation"},";"),a(`
`),n("span",{class:"token punctuation"},"}"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("style")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),J=n("h3",{id:"\u6807\u7B7E\u5316",tabindex:"-1"},[a("\u6807\u7B7E\u5316 "),n("a",{class:"header-anchor",href:"#\u6807\u7B7E\u5316","aria-hidden":"true"},"#")],-1),K=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("n-tree-select")]),a(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("value"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":treeData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("data"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":prop"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("treeProps"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},":multiple"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),a("true"),n("span",{class:"token punctuation"},'"')]),a(),n("span",{class:"token attr-name"},"enableLabelization"),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("n-tree-select")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("template")]),n("span",{class:"token punctuation"},">")]),a(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),a("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[a(`
`),n("span",{class:"token keyword"},"import"),a(),n("span",{class:"token punctuation"},"{"),a(" defineComponent"),n("span",{class:"token punctuation"},","),a(" ref "),n("span",{class:"token punctuation"},"}"),a(),n("span",{class:"token keyword"},"from"),a(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),a(`

`),n("span",{class:"token keyword"},"export"),a(),n("span",{class:"token keyword"},"default"),a(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),a(),n("span",{class:"token punctuation"},"{"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" value "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"213"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token number"},"341"),n("span",{class:"token punctuation"},","),a(),n("span",{class:"token number"},"311"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" treeProps "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),a(`
      `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'children'"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'id'"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
    `),n("span",{class:"token keyword"},"const"),a(" data "),n("span",{class:"token operator"},"="),a(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"213"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"324"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'DEPT0000000101'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u6D4B\u8BD5\u90E8\u95E81'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2022-12-29 13:37:39'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'9b9086a1-ce55-4b26-9173-499415854ac1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),a(`
          `),n("span",{class:"token punctuation"},"{"),a(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"341"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"999999999"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'3453'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-04-26 17:13:31'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'4766ef76-18a2-4957-b8b3-bd3cff933940'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'9b9086a1-ce55-4b26-9173-499415854ac1'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
            `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"311"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"999999999"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u90E8\u95E8111aaa'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-02-01 16:55:56'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'61bceb1d-1eb6-41ec-ab2d-8754a67379ba'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"307"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"999999999"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u90E8\u95E8222'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-02-01 16:50:02'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'7594c5fe-5f4e-4692-a11f-9b97743fac34'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"221"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"401"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'DEPT0000000111'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'b1'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-01-05 14:40:53'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'7afdff47-b043-4d1b-96ef-182c9fb8d79e'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"309"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"999999999"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u90E8\u95E8220aaa'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-02-01 16:51:52'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'ab83b814-8e87-4a9f-aa37-8c089017cade'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"{"),a(`
        `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"306"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"standardModelId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token number"},"999999999"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"code"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'\u90E8\u95E8444'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"remark"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'2023-02-01 15:29:25'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateTime"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"updateBy"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"deleted"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"frontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'75178c3f-b2aa-48c2-820e-d31d3f7c3282'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"quoteObjectId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"customProperties"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"parentFrontId"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"createByName"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token string"},"'admin'"),n("span",{class:"token punctuation"},","),a(`
        `),n("span",{class:"token literal-property property"},"children"),n("span",{class:"token operator"},":"),a(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),a(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`

    `),n("span",{class:"token keyword"},"return"),a(),n("span",{class:"token punctuation"},"{"),a(`
      data`),n("span",{class:"token punctuation"},","),a(`
      value`),n("span",{class:"token punctuation"},","),a(`
      treeProps`),n("span",{class:"token punctuation"},","),a(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),a(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),a(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),a(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),a("script")]),n("span",{class:"token punctuation"},">")]),a(`
`)])])],-1),Q=q(`<h3 id="treeselect-\u53C2\u6570" tabindex="-1">TreeSelect \u53C2\u6570 <a class="header-anchor" href="#treeselect-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th>\u53C2\u6570</th><th>\u7C7B\u578B</th><th>\u9ED8\u8BA4</th><th>\u8BF4\u660E</th><th>\u8DF3\u8F6C</th></tr></thead><tbody><tr><td>v-model</td><td>String, Number, Array</td><td></td><td>\u5FC5\u9009</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>treeData</td><td>TreeData</td><td></td><td>\u5FC5\u9009\uFF0C\u6811\u5F62\u9009\u62E9\u6846\u7684\u5185\u5BB9</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>prop</td><td>TreeProps</td><td></td><td>\u53EF\u9009\uFF0C\u914D\u7F6E\u5185\u5BB9\u5982\u4E0B</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>placeholder</td><td>string</td><td>&#39;\u8BF7\u9009\u62E9&#39;</td><td>\u53EF\u9009\uFF0C\u4FEE\u6539\u8F93\u5165\u6846\u7684\u9ED8\u8BA4\u663E\u793A\u5185\u5BB9</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>disabled</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u7981\u6B62\u7528\u6237\u4F7F\u7528</td><td><a href="#%E7%A6%81%E7%94%A8">\u7981\u7528</a></td></tr><tr><td>allowClear</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u53EF\u4EE5\u6E05\u7A7A\u8F93\u5165\u6846\u5185\u5BB9</td><td><a href="#%E5%8F%AF%E6%B8%85%E7%A9%BA">\u53EF\u6E05\u7A7A</a></td></tr><tr><td>multiple</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u53EF\u9009\u62E9\u591A\u4E2A\u9879</td><td><a href="#%E5%A4%9A%E9%80%89">\u591A\u9009</a></td></tr><tr><td>filter</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u53EF\u7B5B\u9009</td><td><a href="#%E5%8F%AF%E7%AD%9B%E9%80%89">\u7B5B\u9009</a></td></tr><tr><td>leafOnly</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u4EC5\u53EF\u9009\u62E9\u53F6\u5B50\u8282\u70B9</td><td><a href="#%E4%BB%85%E5%8F%B6%E5%AD%90%E8%8A%82%E7%82%B9%E5%8F%AF%E9%80%89">\u4EC5\u53F6\u5B50\u8282\u70B9\u53EF\u9009</a></td></tr><tr><td>enableLabelization</td><td>boolean</td><td>false</td><td>\u53EF\u9009\uFF0C\u503C\u4E3A true \u65F6\u4EC5\u53EF\u9009\u62E9\u53F6\u5B50\u8282\u70B9</td><td><a href="#%E6%A0%87%E7%AD%BE%E5%8C%96">\u6807\u7B7E\u5316</a></td></tr></tbody></table><h3 id="treeselect-\u4E8B\u4EF6" tabindex="-1">TreeSelect \u4E8B\u4EF6 <a class="header-anchor" href="#treeselect-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th>\u4E8B\u4EF6\u540D</th><th>\u8BF4\u660E</th><th>\u53C2\u6570</th><th>\u8DF3\u8F6C</th></tr></thead><tbody><tr><td>valueChange</td><td>\u5F53\u9009\u4E2D\u7684\u503C\u53D1\u751F\u53D8\u5316\u65F6\u89E6\u53D1</td><td>\u5171\u4E24\u4E2A\u53C2\u6570\uFF0C\u4F9D\u6B21\u4E3A\uFF1A\u5F53\u524D\u8282\u70B9\u7684\u6570\u636E\uFF0C\u5F53\u524D\u8282\u70B9\u7684 Node \u5BF9\u8C61</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table><h3 id="\u63A5\u53E3-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">\u63A5\u53E3 &amp; \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#\u63A5\u53E3-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><div class="language-ts"><pre><code><span class="token keyword">interface</span> <span class="token class-name">TreeItem</span> <span class="token punctuation">{</span>
  id<span class="token operator">:</span> <span class="token builtin">number</span> <span class="token operator">|</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  label<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  parent<span class="token operator">?</span><span class="token operator">:</span> TreeItem<span class="token punctuation">;</span>
  children<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">Array</span><span class="token operator">&lt;</span>TreeItem<span class="token operator">&gt;</span><span class="token punctuation">;</span>
  level<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">number</span><span class="token punctuation">;</span>
  loading<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span>
  expanded<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span>
  checked<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span>
  halfchecked<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span>
  disabled<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span>

  <span class="token punctuation">[</span>prop<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">]</span><span class="token operator">:</span> <span class="token builtin">any</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token keyword">type</span> <span class="token class-name">TreeData</span> <span class="token operator">=</span> <span class="token builtin">Array</span><span class="token operator">&lt;</span>TreeItem<span class="token operator">&gt;</span><span class="token punctuation">;</span>
</code></pre></div><div class="language-ts"><pre><code><span class="token keyword">interface</span> <span class="token class-name">TreeProps</span> <span class="token punctuation">{</span>
  label<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  value<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">any</span><span class="token punctuation">;</span>
  disabled<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span> <span class="token operator">|</span> <span class="token builtin">Function</span><span class="token punctuation">;</span>
  <span class="token keyword">class</span><span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span> <span class="token operator">|</span> <span class="token builtin">Function</span><span class="token punctuation">;</span>
  children<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token keyword">type</span> <span class="token class-name">prop</span> <span class="token operator">=</span> Object<span class="token operator">&lt;</span>TreeProps<span class="token operator">&gt;</span><span class="token punctuation">;</span>
</code></pre></div>`,7);function Y(c,r,k,u,i,d){const p=v("render-demo-0"),o=v("demo"),s=v("render-demo-1"),t=v("render-demo-2"),l=v("render-demo-3"),e=v("render-demo-4"),b=v("render-demo-5"),h=v("render-demo-6"),A=v("render-demo-7");return x(),T("div",null,[N,P,j,E(o,{sourceCode:`<template>
  <n-button @click="clearSelect">\u624B\u52A8\u6E05\u9664</n-button>
  <n-tree-select
    v-model="value"
    :treeData="data"
    :prop="prop"
    placeholder="\u6811\u5F62\u9009\u62E9\u6846"
    @valueChange="valueChange"
    size="sm"
  ></n-tree-select>
</template>
<script>
import { defineComponent, onMounted, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref('1');
    const prop = ref({
      label: 'name',
      children: 'childArr',
    });

    const clearSelect = () => {
      value.value = '';
    };

    const data = ref([
      {
        name: '\u4E00\u7EA7 1',
        value: '1',
        childArr: [
          {
            name: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            disabled: true,
            childArr: [
              {
                name: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        name: '\u4E00\u7EA7 2',
        value: '2',
        childArr: [
          {
            name: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            childArr: [
              {
                name: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            name: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            childArr: [
              {
                name: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
            ],
          },
        ],
      },
      {
        name: '\u4E00\u7EA7 3',
        value: '3',
        childArr: [
          {
            name: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            childArr: [
              {
                name: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            name: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            childArr: [
              {
                name: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);
    function valueChange(data) {
      console.log('data', data);
      console.log('value', value);
    }

    /*
      \u6D4B\u8BD5\u76D1\u542CtreeData\u6539\u53D8\uFF0C\u89E3\u51B3\u6709value\u4E4B\u540E\u624D\u6709treeData\u7684\u56DE\u663E\u95EE\u9898
    */
    onMounted(() => {
      setTimeout(function () {
        data.value[0].name = '\u6539\u53D8\u6570\u636E';
        // console.log(dataArr, 'dataArr');
      }, 5000);
    });
    return {
      data,
      value,
      prop,
      valueChange,
      clearSelect,
    };
  },
});
<\/script>
`},{highlight:m(()=>[M]),default:m(()=>[E(p)]),_:1}),O,E(o,{sourceCode:`<template>
  <n-tree-select v-model="value" :treeData="data" :disabled="true"></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref('');
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
              {
                label: '\u4E09\u7EA7 2-2-2',
                value: '2-2-2',
                disabled: true,
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);

    return {
      data,
      value,
    };
  },
});
<\/script>
`},{highlight:m(()=>[S]),default:m(()=>[E(s)]),_:1}),z,E(o,{sourceCode:`<template>
  <n-tree-select v-model="value" :treeData="data" :allowClear="true"></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref('');
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
              {
                label: '\u4E09\u7EA7 2-2-2',
                value: '2-2-2',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);

    return {
      data,
      value,
    };
  },
});
<\/script>
`},{highlight:m(()=>[L]),default:m(()=>[E(t)]),_:1}),U,E(o,{sourceCode:`<template>
  <n-tree-select
    v-model="value"
    :treeData="data"
    :multiple="true"
    :allowClear="true"
    :enableLabelization="true"
    @valueChange="valueChange"
  ></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref(['1', '2']);
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
              {
                label: '\u4E09\u7EA7 2-2-2',
                value: '2-2-2',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);
    function valueChange(data) {
      console.log('data', data);
      console.log('value', value);
    }
    return {
      data,
      value,
      valueChange,
    };
  },
});
<\/script>
`},{highlight:m(()=>[$]),default:m(()=>[E(l)]),_:1}),R,E(o,{sourceCode:`<template>
  <n-tree-select
    v-model="value"
    :treeData="data"
    filter
    :multiple="true"
    :allowClear="true"
    :enableLabelization="true"
    @valueChange="valueChange"
  ></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref([]);
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
              {
                label: '\u4E09\u7EA7 2-2-2',
                value: '2-2-2',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);
    function valueChange(data) {
      console.log('data', data);
      console.log('value', value);
    }
    return {
      data,
      value,
      valueChange,
    };
  },
});
<\/script>
`},{highlight:m(()=>[Z]),default:m(()=>[E(e)]),_:1}),W,E(o,{sourceCode:`<template>
  <n-tree-select v-model="value" :treeData="data" :leafOnly="true"></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref('');
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
              },
              {
                label: '\u4E09\u7EA7 2-2-2',
                value: '2-2-2',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
              },
            ],
          },
        ],
      },
    ]);

    return {
      data,
      value,
    };
  },
});
<\/script>
`},{highlight:m(()=>[X]),default:m(()=>[E(b)]),_:1}),G,E(o,{sourceCode:`<template>
  <n-tree-select v-model="node.value" :treeData="data">
    <template #icon="{ nodeData, toggleNode }">
      <span
        @click="
          (event) => {
            event.stopPropagation();
            toggleNode(nodeData);
          }
        "
      >
        <svg
          :style="{ transform: nodeData.expanded ? 'rotate(90deg)' : '', marginLeft: '-2.5px', marginRight: '14.5px', cursor: 'pointer' }"
          viewBox="0 0 1024 1024"
          width="12"
          height="12"
        >
          <path d="M204.58705 951.162088 204.58705 72.836889 819.41295 511.998977Z" fill="#8a8e99"></path>
        </svg>
      </span>
    </template>
    <template #default="{ item }">
      <span class="tree-select-demo-icon" :class="[item?.data?.type]">{{ item.label }}</span>
    </template>
  </n-tree-select>
</template>
<script>
import { defineComponent, ref, reactive } from 'vue';

export default defineComponent({
  setup() {
    const node = reactive({ value: '' });
    const data = ref([
      {
        label: '\u4E00\u7EA7 1',
        data: { type: 'ppt' },
        value: '1',
        children: [
          {
            label: '\u4E8C\u7EA7 1-1',
            value: '1-1',
            data: { type: 'doc' },
            children: [
              {
                label: '\u4E09\u7EA7 1-1-1',
                data: { type: 'ppt' },
                value: '1-1-1',
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 2',
        value: '2',
        data: { type: 'doc' },
        children: [
          {
            label: '\u4E8C\u7EA7 2-1',
            data: { type: 'ppt' },
            value: '2-1',
            children: [
              {
                label: '\u4E09\u7EA7 2-1-1',
                value: '2-1-1',
                data: { type: 'xls' },
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 2-2',
            value: '2-2',
            data: { type: 'pdf' },
            children: [
              {
                label: '\u4E09\u7EA7 2-2-1',
                value: '2-2-1',
                data: { type: 'xls' },
              },
            ],
          },
        ],
      },
      {
        label: '\u4E00\u7EA7 3',
        value: '3',
        data: { type: 'pdf' },
        children: [
          {
            label: '\u4E8C\u7EA7 3-1',
            value: '3-1',
            data: { type: 'mix' },
            children: [
              {
                label: '\u4E09\u7EA7 3-1-1',
                value: '3-1-1',
                data: { type: 'doc' },
              },
            ],
          },
          {
            label: '\u4E8C\u7EA7 3-2',
            value: '3-2',
            data: { type: 'doc' },
            children: [
              {
                label: '\u4E09\u7EA7 3-2-1',
                value: '3-2-1',
                data: { type: 'xls' },
              },
            ],
          },
        ],
      },
    ]);

    return {
      data,
      node,
    };
  },
});
<\/script>
<style>
.tree-select-demo-icon::before {
  width: 16px;
  height: 16px;
  font-style: italic;
  font-size: 12px;
  line-height: 14px;
  display: inline-block;
  text-align: center;
  color: #fff;
  border-radius: 2px;
}

.tree-select-demo-icon.doc::before {
  content: 'W';
  background-color: #295396;
  border: 1px #224488 solid;
}

.tree-select-demo-icon.pdf::before {
  content: 'A';
  background-color: #da0a0a;
  border: 1px #dd0000 solid;
}

.tree-select-demo-icon.xls::before {
  content: 'X';
  background-color: #207044;
  border: 1px #18683c solid;
}

.tree-select-demo-icon.ppt::before {
  content: 'P';
  background-color: #d14424;
  border: 1px #dd4422 solid;
}

.tree-select-demo-icon.mix::before {
  content: '?';
  font-style: normal;
  background-color: #aaaaaa;
  border: 1px #999999 solid;
}
.tree-select-demo-icon-next {
  margin-left: 8px;
}
</style>
`},{highlight:m(()=>[H]),default:m(()=>[E(h)]),_:1}),J,E(o,{sourceCode:`<template>
  <n-tree-select v-model="value" :treeData="data" :prop="treeProps" :multiple="true" enableLabelization></n-tree-select>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const value = ref([213, 341, 311]);
    const treeProps = ref({
      label: 'name',
      children: 'children',
      value: 'id',
    });
    const data = ref([
      {
        id: 213,
        standardModelId: 324,
        code: 'DEPT0000000101',
        name: '\u6D4B\u8BD5\u90E8\u95E81',
        remark: null,
        createTime: '2022-12-29 13:37:39',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: '9b9086a1-ce55-4b26-9173-499415854ac1',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [
          {
            id: 341,
            standardModelId: 999999999,
            code: null,
            name: '3453',
            remark: null,
            createTime: '2023-04-26 17:13:31',
            createBy: null,
            updateTime: null,
            updateBy: null,
            deleted: null,
            frontId: '4766ef76-18a2-4957-b8b3-bd3cff933940',
            quoteObjectId: null,
            customProperties: null,
            parentFrontId: '9b9086a1-ce55-4b26-9173-499415854ac1',
            createByName: 'admin',
            children: [],
          },
        ],
      },
      {
        id: 311,
        standardModelId: 999999999,
        code: null,
        name: '\u90E8\u95E8111aaa',
        remark: null,
        createTime: '2023-02-01 16:55:56',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: '61bceb1d-1eb6-41ec-ab2d-8754a67379ba',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [],
      },
      {
        id: 307,
        standardModelId: 999999999,
        code: null,
        name: '\u90E8\u95E8222',
        remark: null,
        createTime: '2023-02-01 16:50:02',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: '7594c5fe-5f4e-4692-a11f-9b97743fac34',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [],
      },
      {
        id: 221,
        standardModelId: 401,
        code: 'DEPT0000000111',
        name: 'b1',
        remark: null,
        createTime: '2023-01-05 14:40:53',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: '7afdff47-b043-4d1b-96ef-182c9fb8d79e',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [],
      },
      {
        id: 309,
        standardModelId: 999999999,
        code: null,
        name: '\u90E8\u95E8220aaa',
        remark: null,
        createTime: '2023-02-01 16:51:52',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: 'ab83b814-8e87-4a9f-aa37-8c089017cade',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [],
      },
      {
        id: 306,
        standardModelId: 999999999,
        code: null,
        name: '\u90E8\u95E8444',
        remark: null,
        createTime: '2023-02-01 15:29:25',
        createBy: null,
        updateTime: null,
        updateBy: null,
        deleted: null,
        frontId: '75178c3f-b2aa-48c2-820e-d31d3f7c3282',
        quoteObjectId: null,
        customProperties: null,
        parentFrontId: null,
        createByName: 'admin',
        children: [],
      },
    ]);

    return {
      data,
      value,
      treeProps,
    };
  },
});
<\/script>
`},{highlight:m(()=>[K]),default:m(()=>[E(A)]),_:1}),Q])}var on=I(V,[["render",Y]]);export{en as __pageData,on as default};
