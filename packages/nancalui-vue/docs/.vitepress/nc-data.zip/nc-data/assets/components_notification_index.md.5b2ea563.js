import{V as f}from"./framework.1c17ccd8.js";import{_ as v}from"./plugin-vue_export-helper.21dcd24c.js";import{f as m,G as D,H as _,b as h,a6 as o,V as g,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const y={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(s,a){const u=p("n-button");return d(),F("div",null,[i(u,{onClick:a[0]||(a[0]=C=>s.showService())},{default:l(()=>[c("\u57FA\u672C\u7528\u6CD5")]),_:1})])}const{defineComponent:e}=f,k=e({setup(){function s(){this.$notificationService.open({content:"\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9"})}return{showService:s}}});return{render:r,...k}}(),"render-demo-1":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(s,a){const u=p("n-button");return d(),F("div",null,[i(u,{onClick:a[0]||(a[0]=C=>s.showService())},{default:l(()=>[c("\u6D88\u606F\u6807\u9898")]),_:1})])}const{defineComponent:e}=f,k=e({setup(){function s(){this.$notificationService.open({title:"\u6D88\u606F\u6807\u9898",content:"\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9"})}return{showService:s}}});return{render:r,...k}}(),"render-demo-2":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(s,a){const u=p("n-button");return d(),F("div",null,[i(u,{onClick:a[0]||(a[0]=C=>s.showService())},{default:l(()=>[c("\u6D88\u606F\u7C7B\u578B")]),_:1})])}const{defineComponent:e}=f,k=e({setup(){function s(){this.$notificationService.open({title:"\u6D88\u606F\u6807\u9898",content:"\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9",type:"success"})}return{showService:s}}});return{render:r,...k}}(),"render-demo-3":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(s,a){const u=p("n-button");return d(),F("div",null,[i(u,{onClick:a[0]||(a[0]=C=>s.showService())},{default:l(()=>[c("\u8D85\u65F6\u65F6\u95F4")]),_:1})])}const{defineComponent:e}=f,k=e({setup(){function s(){this.$notificationService.open({title:"\u6D88\u606F\u6807\u9898",content:"\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9",duration:1e3})}return{showService:s}}});return{render:r,...k}}(),"render-demo-4":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(s,a){const u=p("n-button");return d(),F("div",null,[i(u,{onClick:a[0]||(a[0]=C=>s.showService())},{default:l(()=>[c("\u5173\u95ED\u56DE\u8C03")]),_:1})])}const{defineComponent:e}=f,k=e({setup(){function s(){this.$notificationService.open({title:"\u6D88\u606F\u6807\u9898",content:"\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9",onClose:()=>{console.log("notification closed")}})}return{showService:s}}});return{render:r,...k}}(),"render-demo-5":function(){const{createTextVNode:c,resolveComponent:p,withCtx:l,createVNode:i,openBlock:d,createElementBlock:F}=f;function r(a,u){const C=p("n-button"),E=p("n-notification");return d(),F("div",null,[i(C,{onClick:a.showComponent},{default:l(()=>[c("\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528")]),_:1},8,["onClick"]),i(E,{modelValue:a.show,"onUpdate:modelValue":u[0]||(u[0]=B=>a.show=B),title:"\u6807\u9898",type:"info"},{default:l(()=>[c("\u901A\u77E5\u63D0\u793A\u5185\u5BB9")]),_:1},8,["modelValue"])])}const{defineComponent:e,ref:k}=f,s=e({setup(){const a=k(!1);return{show:a,showComponent:()=>{a.value=!0}}}});return{render:r,...s}}()}},W='{"title":"Notification \u5168\u5C40\u901A\u77E5","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u6D88\u606F\u6807\u9898","slug":"\u6D88\u606F\u6807\u9898"},{"level":3,"title":"\u6D88\u606F\u7C7B\u578B","slug":"\u6D88\u606F\u7C7B\u578B"},{"level":3,"title":"\u8D85\u65F6\u65F6\u95F4","slug":"\u8D85\u65F6\u65F6\u95F4"},{"level":3,"title":"\u5173\u95ED\u56DE\u8C03","slug":"\u5173\u95ED\u56DE\u8C03"},{"level":3,"title":"\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528","slug":"\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528"},{"level":3,"title":"Service \u4F7F\u7528","slug":"service-\u4F7F\u7528"},{"level":3,"title":"Notification \u53C2\u6570","slug":"notification-\u53C2\u6570"},{"level":3,"title":"Notification \u63D2\u69FD","slug":"notification-\u63D2\u69FD"},{"level":3,"title":"\u7C7B\u578B\u5B9A\u4E49","slug":"\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/notification/index.md","lastUpdated":1672994787101}',w=g('<h1 id="notification-\u5168\u5C40\u901A\u77E5" tabindex="-1">Notification \u5168\u5C40\u901A\u77E5 <a class="header-anchor" href="#notification-\u5168\u5C40\u901A\u77E5" aria-hidden="true">#</a></h1><p>\u5168\u5C40\u4FE1\u606F\u63D0\u793A\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u9700\u8981\u5411\u7528\u6237\u5168\u5C40\u5C55\u793A\u63D0\u793A\u4FE1\u606F\u65F6\u4F7F\u7528\uFF0C\u663E\u793A\u6570\u79D2\u540E\u6D88\u5931\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),x=n("div",null,"\u63A8\u8350\u4F7F\u7528\u670D\u52A1\u65B9\u5F0F\u8C03\u7528\uFF0C\u9ED8\u8BA4\u60C5\u51B5\u53EA\u5C55\u793A\u6D88\u606F\u5185\u5BB9\u548C\u5173\u95ED\u6309\u94AE\u3002",-1),A=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click.native"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showService()"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u57FA\u672C\u7528\u6CD5"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"showService"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"this"),n("span",{class:"token punctuation"},"."),t("$notificationService"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"open"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" showService "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),b=n("h3",{id:"\u6D88\u606F\u6807\u9898",tabindex:"-1"},[t("\u6D88\u606F\u6807\u9898 "),n("a",{class:"header-anchor",href:"#\u6D88\u606F\u6807\u9898","aria-hidden":"true"},"#")],-1),S=n("div",null,[t("\u901A\u8FC7"),n("code",null,"title"),t("\u53C2\u6570\u8BBE\u7F6E\u6D88\u606F\u6807\u9898\uFF0C\u9ED8\u8BA4\u4E3A\u7A7A\uFF0C\u4E0D\u663E\u793A\u6807\u9898\u3002")],-1),N=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click.native"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showService()"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6D88\u606F\u6807\u9898"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"showService"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"this"),n("span",{class:"token punctuation"},"."),t("$notificationService"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"open"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6D88\u606F\u6807\u9898'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" showService "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),V=n("h3",{id:"\u6D88\u606F\u7C7B\u578B",tabindex:"-1"},[t("\u6D88\u606F\u7C7B\u578B "),n("a",{class:"header-anchor",href:"#\u6D88\u606F\u7C7B\u578B","aria-hidden":"true"},"#")],-1),$=n("div",null,[t("\u901A\u8FC7"),n("code",null,"type"),t("\u53C2\u6570\u8BBE\u7F6E\u6D88\u606F\u7C7B\u578B\uFF0C\u76EE\u524D\u652F\u6301"),n("code",null,"normal"),t("\u3001"),n("code",null,"info"),t("\u3001"),n("code",null,"success"),t("\u3001"),n("code",null,"warning"),t("\u3001"),n("code",null,"danger"),t("\u4E94\u79CD\u7C7B\u578B\uFF0C\u9ED8\u8BA4"),n("code",null,"normal"),t("\u7C7B\u578B\uFF0C\u4E0D\u663E\u793A\u7C7B\u578B\u56FE\u6807\u3002")],-1),T=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click.native"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showService()"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6D88\u606F\u7C7B\u578B"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"showService"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"this"),n("span",{class:"token punctuation"},"."),t("$notificationService"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"open"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6D88\u606F\u6807\u9898'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'success'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" showService "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),q=n("h3",{id:"\u8D85\u65F6\u65F6\u95F4",tabindex:"-1"},[t("\u8D85\u65F6\u65F6\u95F4 "),n("a",{class:"header-anchor",href:"#\u8D85\u65F6\u65F6\u95F4","aria-hidden":"true"},"#")],-1),j=n("div",null,[t("\u901A\u8FC7"),n("code",null,"duration"),t("\u53C2\u6570\u8BBE\u7F6E\u8D85\u65F6\u65F6\u95F4\uFF0C\u5355\u4F4D"),n("code",null,"ms"),t("\uFF0C\u9ED8\u8BA4"),n("code",null,"3000 ms"),t("\u540E\u81EA\u52A8\u5173\u95ED\uFF0C\u8BBE\u7F6E\u4E3A"),n("code",null,"0"),t("\u5219\u4E0D\u4F1A\u81EA\u52A8\u5173\u95ED\u3002")],-1),U=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click.native"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showService()"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u8D85\u65F6\u65F6\u95F4"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"showService"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"this"),n("span",{class:"token punctuation"},"."),t("$notificationService"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"open"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6D88\u606F\u6807\u9898'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"duration"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1000"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" showService "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),G=n("h3",{id:"\u5173\u95ED\u56DE\u8C03",tabindex:"-1"},[t("\u5173\u95ED\u56DE\u8C03 "),n("a",{class:"header-anchor",href:"#\u5173\u95ED\u56DE\u8C03","aria-hidden":"true"},"#")],-1),H=n("div",null,[t("\u901A\u8FC7"),n("code",null,"onClose"),t("\u53C2\u6570\u8BBE\u7F6E\u6D88\u606F\u5173\u95ED\u65F6\u7684\u56DE\u8C03\u3002")],-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click.native"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showService()"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u5173\u95ED\u56DE\u8C03"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"showService"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"this"),n("span",{class:"token punctuation"},"."),t("$notificationService"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"open"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6D88\u606F\u6807\u9898'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"content"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token function-variable function"},"onClose"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
          console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'notification closed'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" showService "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),P=n("h3",{id:"\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528",tabindex:"-1"},[t("\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528 "),n("a",{class:"header-anchor",href:"#\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528","aria-hidden":"true"},"#")],-1),z=n("div",null,[t("\u9664\u670D\u52A1\u65B9\u5F0F\u5916\uFF0C\u8FD8\u63D0\u4F9B\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528\uFF0C\u7EC4\u4EF6\u65B9\u5F0F\u7684\u9ED8\u8BA4\u63D2\u69FD\u4E0E\u670D\u52A1\u65B9\u5F0F\u7684"),n("code",null,"content"),t("\u53C2\u6570\u4F5C\u7528\u4E00\u81F4\uFF0C\u5176\u4ED6\u53C2\u6570\u4E0E\u670D\u52A1\u65B9\u5F0F\u4FDD\u6301\u540C\u540D\u3002")],-1),J=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("showComponent"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-notification")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("show"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"title"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("\u6807\u9898"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"type"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("info"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u901A\u77E5\u63D0\u793A\u5185\u5BB9"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-notification")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" show "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"showComponent"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      show`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" show"),n("span",{class:"token punctuation"},","),t(" showComponent "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),K=g(`<h3 id="service-\u4F7F\u7528" tabindex="-1">Service \u4F7F\u7528 <a class="header-anchor" href="#service-\u4F7F\u7528" aria-hidden="true">#</a></h3><div class="language-typescript"><pre><code><span class="token comment">// \u65B9\u5F0F1\uFF0C\u5C40\u90E8\u5F15\u5165 NotificationService</span>
<span class="token keyword">import</span> <span class="token punctuation">{</span> NotificationService <span class="token punctuation">}</span> <span class="token keyword">from</span> <span class="token string">&#39;@nancalui/vue-nancalui/notification&#39;</span><span class="token punctuation">;</span>
NotificationService<span class="token punctuation">.</span><span class="token function">open</span><span class="token punctuation">(</span><span class="token punctuation">{</span> xxx <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>

<span class="token comment">// \u65B9\u5F0F2\uFF0C\u5168\u5C40\u5C5E\u6027</span>
<span class="token keyword">this</span><span class="token punctuation">.</span>$notificationService<span class="token punctuation">.</span><span class="token function">open</span><span class="token punctuation">(</span><span class="token punctuation">{</span> xxx <span class="token punctuation">}</span><span class="token punctuation">)</span><span class="token punctuation">;</span>
</code></pre></div><h3 id="notification-\u53C2\u6570" tabindex="-1">Notification \u53C2\u6570 <a class="header-anchor" href="#notification-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">&#39;false&#39;</td><td style="text-align:left;">\u7EC4\u4EF6\u8C03\u7528\u5FC5\u9009\uFF0C\u63A7\u5236\u662F\u5426\u663E\u793A</td><td style="text-align:left;"><a href="#%E7%BB%84%E4%BB%B6%E6%96%B9%E5%BC%8F%E8%B0%83%E7%94%A8">\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528</a></td></tr><tr><td style="text-align:left;">content</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u6D88\u606F\u5185\u5BB9</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">title</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u6D88\u606F\u6807\u9898</td><td style="text-align:left;"><a href="#%E6%B6%88%E6%81%AF%E6%A0%87%E9%A2%98">\u6D88\u606F\u6807\u9898</a></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;"><code>NotificationType</code></td><td style="text-align:left;">&#39;normal&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u6D88\u606F\u7C7B\u578B</td><td style="text-align:left;"><a href="#%E6%B6%88%E6%81%AF%E7%B1%BB%E5%9E%8B">\u6D88\u606F\u7C7B\u578B</a></td></tr><tr><td style="text-align:left;">duration</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">&#39;3000&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u8D85\u65F6\u65F6\u95F4</td><td style="text-align:left;"><a href="#%E8%B6%85%E6%97%B6%E6%97%B6%E9%97%B4">\u8D85\u65F6\u65F6\u95F4</a></td></tr><tr><td style="text-align:left;">on-close</td><td style="text-align:left;"><code>() =&gt; void</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u6D88\u606F\u5173\u95ED\u65F6\u7684\u56DE\u8C03</td><td style="text-align:left;"><a href="#%E5%85%B3%E9%97%AD%E5%9B%9E%E8%B0%83">\u5173\u95ED\u56DE\u8C03</a></td></tr></tbody></table><h3 id="notification-\u63D2\u69FD" tabindex="-1">Notification \u63D2\u69FD <a class="header-anchor" href="#notification-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u63D2\u69FD\u540D</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">default</td><td style="text-align:left;">\u9ED8\u8BA4\u63D2\u69FD\uFF0C\u7EC4\u4EF6\u65B9\u5F0F\u4F7F\u7528\u65F6\u6709\u6548</td></tr></tbody></table><h3 id="\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">\u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="notificationtype" tabindex="-1">NotificationType <a class="header-anchor" href="#notificationtype" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">NotificationType</span> <span class="token operator">=</span> <span class="token string">&#39;normal&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;success&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;error&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;warning&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;info&#39;</span><span class="token punctuation">;</span>
</code></pre></div>`,9);function L(c,p,l,i,d,F){const r=m("render-demo-0"),e=m("demo"),k=m("render-demo-1"),s=m("render-demo-2"),a=m("render-demo-3"),u=m("render-demo-4"),C=m("render-demo-5");return D(),_("div",null,[w,h(e,{sourceCode:`<template>
  <n-button @click.native="showService()">\u57FA\u672C\u7528\u6CD5</n-button>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function showService() {
      this.$notificationService.open({
        content: '\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9',
      });
    }

    return { showService };
  },
});
<\/script>
`},{description:o(()=>[x]),highlight:o(()=>[A]),default:o(()=>[h(r)]),_:1}),b,h(e,{sourceCode:`<template>
  <n-button @click.native="showService()">\u6D88\u606F\u6807\u9898</n-button>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function showService() {
      this.$notificationService.open({
        title: '\u6D88\u606F\u6807\u9898',
        content: '\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9',
      });
    }

    return { showService };
  },
});
<\/script>
`},{description:o(()=>[S]),highlight:o(()=>[N]),default:o(()=>[h(k)]),_:1}),V,h(e,{sourceCode:`<template>
  <n-button @click.native="showService()">\u6D88\u606F\u7C7B\u578B</n-button>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function showService() {
      this.$notificationService.open({
        title: '\u6D88\u606F\u6807\u9898',
        content: '\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9',
        type: 'success',
      });
    }

    return { showService };
  },
});
<\/script>
`},{description:o(()=>[$]),highlight:o(()=>[T]),default:o(()=>[h(s)]),_:1}),q,h(e,{sourceCode:`<template>
  <n-button @click.native="showService()">\u8D85\u65F6\u65F6\u95F4</n-button>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function showService() {
      this.$notificationService.open({
        title: '\u6D88\u606F\u6807\u9898',
        content: '\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9',
        duration: 1000,
      });
    }

    return { showService };
  },
});
<\/script>
`},{description:o(()=>[j]),highlight:o(()=>[U]),default:o(()=>[h(a)]),_:1}),G,h(e,{sourceCode:`<template>
  <n-button @click.native="showService()">\u5173\u95ED\u56DE\u8C03</n-button>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function showService() {
      this.$notificationService.open({
        title: '\u6D88\u606F\u6807\u9898',
        content: '\u901A\u77E5\u6846\u6D88\u606F\u5185\u5BB9',
        onClose: () => {
          console.log('notification closed');
        },
      });
    }

    return { showService };
  },
});
<\/script>
`},{description:o(()=>[H]),highlight:o(()=>[I]),default:o(()=>[h(u)]),_:1}),P,h(e,{sourceCode:`<template>
  <n-button @click="showComponent">\u7EC4\u4EF6\u65B9\u5F0F\u8C03\u7528</n-button>
  <n-notification v-model="show" title="\u6807\u9898" type="info">\u901A\u77E5\u63D0\u793A\u5185\u5BB9</n-notification>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const show = ref(false);
    const showComponent = () => {
      show.value = true;
    };

    return { show, showComponent };
  },
});
<\/script>
`},{description:o(()=>[z]),highlight:o(()=>[J]),default:o(()=>[h(C)]),_:1}),K])}var X=v(y,[["render",L]]);export{W as __pageData,X as default};
