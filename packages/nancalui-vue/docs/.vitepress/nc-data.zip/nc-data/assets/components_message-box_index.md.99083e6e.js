import{V as k}from"./framework.1c17ccd8.js";import{_ as h}from"./plugin-vue_export-helper.21dcd24c.js";import{f as d,G as C,H as y,b as g,a6 as F,V as B,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const v={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:o,resolveComponent:c,withCtx:p,createVNode:l,createElementVNode:i,openBlock:r,createElementBlock:a}=k,e={class:"demo-spacing"};function m(u,s){const f=c("n-button");return r(),a("div",null,[i("div",e,[l(f,{variant:"text",onClick:s[0]||(s[0]=w=>u.open("warning"))},{default:p(()=>[o("Click to open the Message Box")]),_:1})])])}const{defineComponent:E}=k,x=E({setup(){function u(s){this.$MessageBoxService.open({title:"\u662F\u5426\u786E\u8BA4\u5220\u9664\u8BE5\u76EE\u5F55",content:"\u5220\u9664\u540E\u8BE5\u5206\u7C7B\u5C06\u4E0D\u53EF\u6062\u590D",width:"430px",save:()=>{this.$message({type:s,message:"\u60A8\u70B9\u51FB\u4E86\u786E\u8BA4\uFF01"})},cancel:()=>{this.$message({type:s,message:"\u60A8\u70B9\u51FB\u4E86\u53D6\u6D88\uFF01"})}})}return{open:u}}});return{render:m,...x}}()}},S='{"title":"MessageBox \u4E8C\u6B21\u786E\u8BA4\u5F39\u7A97","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u4F55\u65F6\u4F7F\u7528","slug":"\u4F55\u65F6\u4F7F\u7528"},{"level":3,"title":"\u57FA\u7840\u7528\u6CD5","slug":"\u57FA\u7840\u7528\u6CD5"},{"level":3,"title":"message-box \u53C2\u6570","slug":"message-box-\u53C2\u6570"}],"relativePath":"components/message-box/index.md","lastUpdated":1676259085488}',_=B('<h1 id="messagebox-\u4E8C\u6B21\u786E\u8BA4\u5F39\u7A97" tabindex="-1">MessageBox \u4E8C\u6B21\u786E\u8BA4\u5F39\u7A97 <a class="header-anchor" href="#messagebox-\u4E8C\u6B21\u786E\u8BA4\u5F39\u7A97" aria-hidden="true">#</a></h1><p>\u5E38\u7528\u4E8E\u5371\u9669\u64CD\u4F5C\u540E\u7684\u53CD\u9988\u63D0\u793A\uFF0C\u7528\u4F5C\u4E8C\u6B21\u786E\u8BA4\u5F39\u7A97</p><h3 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h3><p>\u7528\u6237\u4E00\u4E9B\u5220\u9664\uFF0C\u4FDD\u5B58\u7B49\u4E0D\u53EF\u9006\u7684\u5371\u9669\u64CD\u4F5C\u60C5\u51B5\u4E0B\u4F7F\u7528</p><h3 id="\u57FA\u7840\u7528\u6CD5" tabindex="-1">\u57FA\u7840\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u7840\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),D=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("demo-spacing"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("open('warning')"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Click to open the Message Box"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"function"),n(),t("span",{class:"token function"},"open"),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"type"),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token keyword"},"this"),t("span",{class:"token punctuation"},"."),n("$MessageBoxService"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"open"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"title"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u662F\u5426\u786E\u8BA4\u5220\u9664\u8BE5\u76EE\u5F55'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"content"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u5220\u9664\u540E\u8BE5\u5206\u7C7B\u5C06\u4E0D\u53EF\u6062\u590D'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"width"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'430px'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token function-variable function"},"save"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
          `),t("span",{class:"token keyword"},"this"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"$message"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
            type`),t("span",{class:"token punctuation"},","),n(`
            `),t("span",{class:"token literal-property property"},"message"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u60A8\u70B9\u51FB\u4E86\u786E\u8BA4\uFF01'"),t("span",{class:"token punctuation"},","),n(`
          `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token function-variable function"},"cancel"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
          `),t("span",{class:"token keyword"},"this"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"$message"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
            type`),t("span",{class:"token punctuation"},","),n(`
            `),t("span",{class:"token literal-property property"},"message"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u60A8\u70B9\u51FB\u4E86\u53D6\u6D88\uFF01'"),t("span",{class:"token punctuation"},","),n(`
          `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
        `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(" open "),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),A=B('<h3 id="message-box-\u53C2\u6570" tabindex="-1">message-box \u53C2\u6570 <a class="header-anchor" href="#message-box-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">title</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u8BBE\u7F6E\u5F39\u7A97\u6807\u9898</td></tr><tr><td style="text-align:left;">content</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u8BBE\u7F6E\u63D0\u793A\u5185\u5BB9</td></tr><tr><td style="text-align:left;">width</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;430px&#39;</td><td style="text-align:left;">\u8BBE\u7F6E\u5F39\u7A97\u5BBD\u5EA6</td></tr><tr><td style="text-align:left;">cancel</td><td style="text-align:left;">() =&gt; void</td><td style="text-align:left;"></td><td style="text-align:left;">\u70B9\u51FB\u53D6\u6D88\u64CD\u4F5C\u56DE\u8C03</td></tr><tr><td style="text-align:left;">save</td><td style="text-align:left;">() =&gt; void</td><td style="text-align:left;"></td><td style="text-align:left;">\u70B9\u51FB\u786E\u8BA4\u64CD\u4F5C\u56DE\u8C03</td></tr></tbody></table>',2);function b(o,c,p,l,i,r){const a=d("render-demo-0"),e=d("demo");return C(),y("div",null,[_,g(e,{sourceCode:`<template>
  <div class="demo-spacing">
    <n-button variant="text" @click="open('warning')">Click to open the Message Box</n-button>
  </div>
</template>
<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    function open(type) {
      this.$MessageBoxService.open({
        title: '\u662F\u5426\u786E\u8BA4\u5220\u9664\u8BE5\u76EE\u5F55',
        content: '\u5220\u9664\u540E\u8BE5\u5206\u7C7B\u5C06\u4E0D\u53EF\u6062\u590D',
        width: '430px',
        save: () => {
          this.$message({
            type,
            message: '\u60A8\u70B9\u51FB\u4E86\u786E\u8BA4\uFF01',
          });
        },
        cancel: () => {
          this.$message({
            type,
            message: '\u60A8\u70B9\u51FB\u4E86\u53D6\u6D88\uFF01',
          });
        },
      });
    }
    return { open };
  },
});
<\/script>
`},{highlight:F(()=>[D]),default:F(()=>[g(a)]),_:1}),A])}var q=h(v,[["render",b]]);export{S as __pageData,q as default};
