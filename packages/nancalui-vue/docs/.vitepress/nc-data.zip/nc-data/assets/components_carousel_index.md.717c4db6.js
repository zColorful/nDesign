import{V as F}from"./framework.1c17ccd8.js";import{_ as q}from"./plugin-vue_export-helper.21dcd24c.js";import{f as v,G as N,H as V,b as y,a6 as C,V as w,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const T={name:"component-doc",components:{"render-demo-0":function(){const{renderList:f,Fragment:E,openBlock:s,createElementBlock:u,toDisplayString:h,createTextVNode:r,resolveComponent:e,withCtx:a,createBlock:d,createVNode:c}=F;function g(p,B){const l=e("n-carousel-item"),k=e("n-carousel");return s(),u("div",null,[c(k,{height:"200px"},{default:a(()=>[(s(!0),u(E,null,f(p.items,i=>(s(),d(l,{class:"n-carousel-item",key:i},{default:a(()=>[r(h(i),1)]),_:2},1024))),128))]),_:1})])}const{defineComponent:m,ref:_}=F,x=m({setup(){return{items:_(["page 1","page 2","page 3","page 4"])}}});return{render:g,...x}}(),"render-demo-1":function(){const{renderList:f,Fragment:E,openBlock:s,createElementBlock:u,toDisplayString:h,createTextVNode:r,resolveComponent:e,withCtx:a,createBlock:d,createVNode:c}=F;function g(p,B){const l=e("n-carousel-item"),k=e("n-carousel");return s(),u("div",null,[c(k,{height:"200px","transition-speed":5e3},{default:a(()=>[(s(!0),u(E,null,f(p.items,i=>(s(),d(l,{class:"n-demo-carousel-item",key:i},{default:a(()=>[r(h(i),1)]),_:2},1024))),128))]),_:1})])}const{defineComponent:m,ref:_}=F,x=m({setup(){return{items:_(["page 1","page 2","page 3","page 4"])}}});return{render:g,...x}}(),"render-demo-2":function(){const{renderList:f,Fragment:E,openBlock:s,createElementBlock:u,toDisplayString:h,createTextVNode:r,resolveComponent:e,withCtx:a,createBlock:d,createVNode:c}=F;function g(p,B){const l=e("n-carousel-item"),k=e("n-carousel");return s(),u("div",null,[c(k,{height:"200px",arrowTrigger:"always","dot-trigger":"hover"},{default:a(()=>[(s(!0),u(E,null,f(p.items,i=>(s(),d(l,{class:"n-carousel-item",key:i},{default:a(()=>[r(h(i),1)]),_:2},1024))),128))]),_:1})])}const{defineComponent:m,ref:_}=F,x=m({setup(){return{items:_(["page 1","page 2","page 3","page 4"])}}});return{render:g,...x}}(),"render-demo-3":function(){const{renderList:f,Fragment:E,openBlock:s,createElementBlock:u,toDisplayString:h,createTextVNode:r,resolveComponent:e,withCtx:a,createBlock:d,createVNode:c}=F;function g(p,B){const l=e("n-carousel-item"),k=e("n-carousel");return s(),u("div",null,[c(k,{height:"200px",autoplay:"","autoplay-speed":3e3},{default:a(()=>[(s(!0),u(E,null,f(p.items,i=>(s(),d(l,{class:"n-carousel-item",key:i},{default:a(()=>[r(h(i),1)]),_:2},1024))),128))]),_:1})])}const{defineComponent:m,ref:_}=F,x=m({setup(){return{items:_(["page 1","page 2","page 3","page 4"])}}});return{render:g,...x}}(),"render-demo-4":function(){const{renderList:f,Fragment:E,openBlock:s,createElementBlock:u,toDisplayString:h,createTextVNode:r,resolveComponent:e,withCtx:a,createBlock:d,createVNode:c,createElementVNode:g}=F,m={class:"carousel-demo-operate"};function _(l,k){const i=e("n-carousel-item"),b=e("n-carousel"),D=e("n-button");return s(),u("div",null,[c(b,{ref:"carousel",height:"200px",arrowTrigger:"never"},{default:a(()=>[(s(!0),u(E,null,f(l.items,o=>(s(),d(i,{class:"n-carousel-item",key:o},{default:a(()=>[r(h(o),1)]),_:2},1024))),128))]),_:1},512),g("div",m,[c(D,{onClick:l.onPrev},{default:a(()=>[r("\u4E0A\u4E00\u5F20")]),_:1},8,["onClick"]),c(D,{onClick:l.onNext},{default:a(()=>[r("\u4E0B\u4E00\u5F20")]),_:1},8,["onClick"]),c(D,{onClick:l.onGoFirst},{default:a(()=>[r("\u7B2C\u4E00\u5F20")]),_:1},8,["onClick"])])])}const{defineComponent:x,ref:p}=F,B=x({setup(){const l=p(["page 1","page 2","page 3","page 4"]),k=p();return{items:l,carousel:k,onPrev:()=>{var o,A;(A=(o=k.value)==null?void 0:o.prev)==null||A.call(o)},onNext:()=>{var o,A;(A=(o=k.value)==null?void 0:o.next)==null||A.call(o)},onGoFirst:()=>{var o,A;(A=(o=k.value)==null?void 0:o.goto)==null||A.call(o,0)}}}});return{render:_,...B}}()}},X='{"title":"Carousel \u8D70\u9A6C\u706F","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u8FC7\u6E21\u65F6\u95F4","slug":"\u8FC7\u6E21\u65F6\u95F4"},{"level":3,"title":"\u6307\u793A\u5668&\u5207\u6362\u7BAD\u5934","slug":"\u6307\u793A\u5668-\u5207\u6362\u7BAD\u5934"},{"level":3,"title":"\u81EA\u52A8\u8F6E\u64AD","slug":"\u81EA\u52A8\u8F6E\u64AD"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u64CD\u4F5C","slug":"\u81EA\u5B9A\u4E49\u64CD\u4F5C"},{"level":3,"title":"Carousel \u53C2\u6570","slug":"carousel-\u53C2\u6570"},{"level":3,"title":"Carousel \u4E8B\u4EF6","slug":"carousel-\u4E8B\u4EF6"},{"level":3,"title":"Carousel \u65B9\u6CD5","slug":"carousel-\u65B9\u6CD5"}],"relativePath":"components/carousel/index.md","lastUpdated":1672994787083}',S=w('<h1 id="carousel-\u8D70\u9A6C\u706F" tabindex="-1">Carousel \u8D70\u9A6C\u706F <a class="header-anchor" href="#carousel-\u8D70\u9A6C\u706F" aria-hidden="true">#</a></h1><p>\u4E00\u7EC4\u8F6E\u64AD\u7684\u533A\u57DF\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><ol><li>\u7528\u4E8E\u5C55\u793A\u56FE\u7247\u6216\u8005\u5361\u7247\u3002</li></ol><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),G=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel")]),t(),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("200px"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel-item")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("n-carousel-item"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-for"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item in items"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ item }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" items "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'page 1'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 2'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 4'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      items`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".n-carousel-item"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),t(" 200px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--nancalui-global-bg"),n("span",{class:"token punctuation"},","),t(" #f3f6f8"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),L=n("h3",{id:"\u8FC7\u6E21\u65F6\u95F4",tabindex:"-1"},[t("\u8FC7\u6E21\u65F6\u95F4 "),n("a",{class:"header-anchor",href:"#\u8FC7\u6E21\u65F6\u95F4","aria-hidden":"true"},"#")],-1),P=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel")]),t(),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("200px"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":transition-speed"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("5000"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel-item")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("n-demo-carousel-item"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-for"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item in items"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ item }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" items "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'page 1'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 2'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 4'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      items`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".n-demo-carousel-item"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),t(" 200px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--nancalui-global-bg"),n("span",{class:"token punctuation"},","),t(" #f3f6f8"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),j=n("h3",{id:"\u6307\u793A\u5668-\u5207\u6362\u7BAD\u5934",tabindex:"-1"},[t("\u6307\u793A\u5668&\u5207\u6362\u7BAD\u5934 "),n("a",{class:"header-anchor",href:"#\u6307\u793A\u5668-\u5207\u6362\u7BAD\u5934","aria-hidden":"true"},"#")],-1),$=n("p",null,"arrowTrigger \u8BBE\u4E3A always \u53EF\u4EE5\u4F7F\u7BAD\u5934\u6C38\u4E45\u663E\u793A\uFF0CdotTrigger \u8BBE\u4E3A hover \u53EF\u4EE5\u4F7F hover \u5230\u70B9\u4E0A\u5C31\u5207\u6362\u3002",-1),H=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel")]),t(),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("200px"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"arrowTrigger"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("always"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"dot-trigger"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hover"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel-item")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("n-carousel-item"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-for"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item in items"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ item }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" items "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'page 1'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 2'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 4'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      items`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".n-carousel-item"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),t(" 200px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--nancalui-global-bg"),n("span",{class:"token punctuation"},","),t(" #f3f6f8"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),I=n("h3",{id:"\u81EA\u52A8\u8F6E\u64AD",tabindex:"-1"},[t("\u81EA\u52A8\u8F6E\u64AD "),n("a",{class:"header-anchor",href:"#\u81EA\u52A8\u8F6E\u64AD","aria-hidden":"true"},"#")],-1),U=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel")]),t(),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("200px"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"autoplay"),t(),n("span",{class:"token attr-name"},":autoplay-speed"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("3000"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel-item")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("n-carousel-item"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-for"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item in items"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ item }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" items "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'page 1'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 2'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 4'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      items`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".n-carousel-item"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),t(" 200px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(),n("span",{class:"token function"},"var"),n("span",{class:"token punctuation"},"("),t("--nancalui-global-bg"),n("span",{class:"token punctuation"},","),t(" #f3f6f8"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),z=n("h3",{id:"\u81EA\u5B9A\u4E49\u64CD\u4F5C",tabindex:"-1"},[t("\u81EA\u5B9A\u4E49\u64CD\u4F5C "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u64CD\u4F5C","aria-hidden":"true"},"#")],-1),J=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel")]),t(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("carousel"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("200px"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"arrowTrigger"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("never"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-carousel-item")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("n-carousel-item"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"v-for"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item in items"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("item"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ item }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-carousel")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("carousel-demo-operate"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onPrev"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u4E0A\u4E00\u5F20"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onNext"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u4E0B\u4E00\u5F20"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onGoFirst"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u7B2C\u4E00\u5F20"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" items "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'page 1'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 2'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 3'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'page 4'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" carousel "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onPrev"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      carousel`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"?."),t("prev"),n("span",{class:"token operator"},"?."),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onNext"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      carousel`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"?."),t("next"),n("span",{class:"token operator"},"?."),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onGoFirst"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      carousel`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"?."),t("goto"),n("span",{class:"token operator"},"?."),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      items`),n("span",{class:"token punctuation"},","),t(`
      carousel`),n("span",{class:"token punctuation"},","),t(`
      onPrev`),n("span",{class:"token punctuation"},","),t(`
      onNext`),n("span",{class:"token punctuation"},","),t(`
      onGoFirst`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".carousel-demo-operate"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"margin-top"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token selector"},".carousel-demo-operate .nancalui-btn-host"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"margin-right"),n("span",{class:"token punctuation"},":"),t(" 20px"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),K=w('<h3 id="carousel-\u53C2\u6570" tabindex="-1">Carousel \u53C2\u6570 <a class="header-anchor" href="#carousel-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u63CF\u8FF0</th><th>\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">arrow-trigger</td><td style="text-align:left;"><code>&#39;hover&#39;|&#39;never&#39;|&#39;always&#39;</code></td><td style="text-align:left;">&#39;hover&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6307\u5B9A\u5207\u6362\u7BAD\u5934\u663E\u793A\u65B9\u5F0F</td><td><a href="#%E6%8C%87%E7%A4%BA%E5%99%A8-%E5%88%87%E6%8D%A2%E7%AE%AD%E5%A4%B4">\u6307\u793A\u5668&amp;\u5207\u6362\u7BAD\u5934</a></td></tr><tr><td style="text-align:left;">autoplay</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u81EA\u52A8\u8F6E\u64AD</td><td><a href="#%E8%87%AA%E5%8A%A8%E8%BD%AE%E6%92%AD">\u81EA\u52A8\u8F6E\u64AD</a></td></tr><tr><td style="text-align:left;">autoplay-speed</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">3000</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u914D\u5408<code>autoplay</code>\u4F7F\u7528\uFF0C\u81EA\u52A8\u8F6E\u64AD\u901F\u5EA6\uFF0C\u5355\u4F4D ms</td><td><a href="#%E8%87%AA%E5%8A%A8%E8%BD%AE%E6%92%AD">\u81EA\u52A8\u8F6E\u64AD</a></td></tr><tr><td style="text-align:left;">height</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;100%&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F6E\u64AD\u5BB9\u5668\u9AD8\u5EA6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">show-dots</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u9762\u677F\u6307\u793A\u5668</td><td><a href="#%E8%87%AA%E5%8A%A8%E8%BD%AE%E6%92%AD">\u81EA\u52A8\u8F6E\u64AD</a></td></tr><tr><td style="text-align:left;">dot-position</td><td style="text-align:left;"><code>&#39;top&#39;|&#39;bottom&#39;</code></td><td style="text-align:left;">&#39;bottom&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u9762\u677F\u6307\u793A\u5668\u4F4D\u7F6E</td><td><a href="#%E6%8C%87%E7%A4%BA%E5%99%A8-%E5%88%87%E6%8D%A2%E7%AE%AD%E5%A4%B4">\u6307\u793A\u5668&amp;\u5207\u6362\u7BAD\u5934</a></td></tr><tr><td style="text-align:left;">dot-trigger</td><td style="text-align:left;"><code>&#39;click&#39;|&#39;hover&#39;</code></td><td style="text-align:left;">&#39;click&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6307\u793A\u5668\u89E6\u53D1\u8F6E\u64AD\u65B9\u5F0F</td><td><a href="#%E6%8C%87%E7%A4%BA%E5%99%A8-%E5%88%87%E6%8D%A2%E7%AE%AD%E5%A4%B4">\u6307\u793A\u5668&amp;\u5207\u6362\u7BAD\u5934</a></td></tr><tr><td style="text-align:left;">active-index</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">0</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u521D\u59CB\u5316\u6FC0\u6D3B\u5361\u7247\u7D22\u5F15\uFF0C\u4ECE 0 \u5F00\u59CB\uFF0C\u652F\u6301<code>[(active-index)]</code>\u53CC\u5411\u7ED1\u5B9A</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">transition-speed</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">500</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5207\u6362\u5230\u4E0B\u4E00\u5F20\u6240\u7528\u7684\u65F6\u95F4\uFF0C\u5355\u4F4D ms</td><td><a href="#%E8%BF%87%E6%B8%A1%E6%97%B6%E9%97%B4">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table><h3 id="carousel-\u4E8B\u4EF6" tabindex="-1">Carousel \u4E8B\u4EF6 <a class="header-anchor" href="#carousel-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u63CF\u8FF0</th><th>\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">active-index-change</td><td style="text-align:left;"><code>EventEmitter&lt;number&gt;</code></td><td style="text-align:left;">\u5361\u7247\u5207\u6362\u65F6\uFF0C\u8FD4\u56DE\u5F53\u524D\u5361\u7247\u7684\u7D22\u5F15\uFF0C\u4ECE 0 \u5F00\u59CB</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table><h3 id="carousel-\u65B9\u6CD5" tabindex="-1">Carousel \u65B9\u6CD5 <a class="header-anchor" href="#carousel-\u65B9\u6CD5" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u65B9\u6CD5</th><th style="text-align:left;">\u63CF\u8FF0</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">prev()</td><td style="text-align:left;">\u5207\u6362\u5230\u4E0A\u4E00\u5F20\u5361\u7247</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%93%8D%E4%BD%9C">\u81EA\u5B9A\u4E49\u64CD\u4F5C</a></td></tr><tr><td style="text-align:left;">next()</td><td style="text-align:left;">\u5207\u6362\u5230\u4E0B\u4E00\u5F20\u5361\u7247</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%93%8D%E4%BD%9C">\u81EA\u5B9A\u4E49\u64CD\u4F5C</a></td></tr><tr><td style="text-align:left;">goTo(index)</td><td style="text-align:left;">\u5207\u6362\u5230\u6307\u5B9A\u7D22\u5F15\u7684\u5361\u7247\uFF0C\u7D22\u5F15\u4ECE 0 \u5F00\u59CB</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%93%8D%E4%BD%9C">\u81EA\u5B9A\u4E49\u64CD\u4F5C</a></td></tr></tbody></table>',6);function M(f,E,s,u,h,r){const e=v("render-demo-0"),a=v("demo"),d=v("render-demo-1"),c=v("render-demo-2"),g=v("render-demo-3"),m=v("render-demo-4");return N(),V("div",null,[S,y(a,{sourceCode:`<template>
  <n-carousel height="200px">
    <n-carousel-item class="n-carousel-item" v-for="item in items" :key="item">{{ item }}</n-carousel-item>
  </n-carousel>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const items = ref<string[]>(['page 1', 'page 2', 'page 3', 'page 4']);
    return {
      items,
    };
  },
});
<\/script>
<style>
.n-carousel-item {
  text-align: center;
  line-height: 200px;
  background: var(--nancalui-global-bg, #f3f6f8);
}
</style>
`},{highlight:C(()=>[G]),default:C(()=>[y(e)]),_:1}),L,y(a,{sourceCode:`<template>
  <n-carousel height="200px" :transition-speed="5000">
    <n-carousel-item class="n-demo-carousel-item" v-for="item in items" :key="item">{{ item }}</n-carousel-item>
  </n-carousel>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const items = ref<string[]>(['page 1', 'page 2', 'page 3', 'page 4']);
    return {
      items,
    };
  },
});
<\/script>
<style>
.n-demo-carousel-item {
  text-align: center;
  line-height: 200px;
  background: var(--nancalui-global-bg, #f3f6f8);
}
</style>
`},{highlight:C(()=>[P]),default:C(()=>[y(d)]),_:1}),j,$,y(a,{sourceCode:`<template>
  <n-carousel height="200px" arrowTrigger="always" dot-trigger="hover">
    <n-carousel-item class="n-carousel-item" v-for="item in items" :key="item">{{ item }}</n-carousel-item>
  </n-carousel>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const items = ref<string[]>(['page 1', 'page 2', 'page 3', 'page 4']);
    return {
      items,
    };
  },
});
<\/script>
<style>
.n-carousel-item {
  text-align: center;
  line-height: 200px;
  background: var(--nancalui-global-bg, #f3f6f8);
}
</style>
`},{highlight:C(()=>[H]),default:C(()=>[y(c)]),_:1}),I,y(a,{sourceCode:`<template>
  <n-carousel height="200px" autoplay :autoplay-speed="3000">
    <n-carousel-item class="n-carousel-item" v-for="item in items" :key="item">{{ item }}</n-carousel-item>
  </n-carousel>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const items = ref<string[]>(['page 1', 'page 2', 'page 3', 'page 4']);
    return {
      items,
    };
  },
});
<\/script>
<style>
.n-carousel-item {
  text-align: center;
  line-height: 200px;
  background: var(--nancalui-global-bg, #f3f6f8);
}
</style>
`},{highlight:C(()=>[U]),default:C(()=>[y(g)]),_:1}),z,y(a,{sourceCode:`<template>
  <n-carousel ref="carousel" height="200px" arrowTrigger="never">
    <n-carousel-item class="n-carousel-item" v-for="item in items" :key="item">{{ item }}</n-carousel-item>
  </n-carousel>
  <div class="carousel-demo-operate">
    <n-button @click="onPrev">\u4E0A\u4E00\u5F20</n-button>
    <n-button @click="onNext">\u4E0B\u4E00\u5F20</n-button>
    <n-button @click="onGoFirst">\u7B2C\u4E00\u5F20</n-button>
  </div>
</template>
<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const items = ref<string[]>(['page 1', 'page 2', 'page 3', 'page 4']);
    const carousel = ref();
    const onPrev = () => {
      carousel.value?.prev?.();
    };
    const onNext = () => {
      carousel.value?.next?.();
    };
    const onGoFirst = () => {
      carousel.value?.goto?.(0);
    };
    return {
      items,
      carousel,
      onPrev,
      onNext,
      onGoFirst,
    };
  },
});
<\/script>
<style>
.carousel-demo-operate {
  margin-top: 10px;
  display: flex;
  align-items: center;
}
.carousel-demo-operate .nancalui-btn-host {
  margin-right: 20px;
}
</style>
`},{highlight:C(()=>[J]),default:C(()=>[y(m)]),_:1}),K])}var Y=q(T,[["render",M]]);export{X as __pageData,Y as default};
