import{V as f}from"./framework.1c17ccd8.js";import{_ as D}from"./plugin-vue_export-helper.21dcd24c.js";import{f as x,G as U,H as S,b as h,a6 as m,V as w,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const R={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:i,createVNode:e,openBlock:l,createElementBlock:s}=f;function d(y,r){const g=i("n-skeleton");return l(),s("div",null,[e(g,{row:3})])}return{render:d,...{}}}(),"render-demo-1":function(){const{resolveComponent:i,createVNode:e,createTextVNode:l,createElementVNode:s,withCtx:d,openBlock:v,createElementBlock:y}=f,r={class:"skeleton-btn-groups"},g={class:"skeleton-btn"},p={class:"skeleton-btn"},_={class:"skeleton-btn"},A={class:"skeleton-btn"},F={class:"skeleton-btn"},q={class:"skeleton-btn"},V={class:"skeleton-btn"},C=s("div",null,[s("div",null,"row one"),s("div",null,"row two"),s("div",null,"row three"),s("div",null,"row four")],-1);function P(a,o){const u=i("n-switch"),b=i("n-skeleton");return v(),y("div",null,[s("div",r,[s("div",g,[l(" Skeleton\uFF1A "),e(u,{modelValue:a.loading,"onUpdate:modelValue":o[0]||(o[0]=c=>a.loading=c)},null,8,["modelValue"])]),s("div",p,[l(" Animation\uFF1A "),e(u,{modelValue:a.animate,"onUpdate:modelValue":o[1]||(o[1]=c=>a.animate=c)},null,8,["modelValue"])]),s("div",_,[l(" Avatar\uFF1A "),e(u,{modelValue:a.avatar,"onUpdate:modelValue":o[2]||(o[2]=c=>a.avatar=c)},null,8,["modelValue"])]),s("div",A,[l(" Title\uFF1A "),e(u,{modelValue:a.title,"onUpdate:modelValue":o[3]||(o[3]=c=>a.title=c)},null,8,["modelValue"])]),s("div",F,[l(" Paragraph\uFF1A "),e(u,{modelValue:a.paragraph,"onUpdate:modelValue":o[4]||(o[4]=c=>a.paragraph=c)},null,8,["modelValue"])]),s("div",q,[l(" Round Avatar\uFF1A "),e(u,{modelValue:a.roundAvatar,"onUpdate:modelValue":o[5]||(o[5]=c=>a.roundAvatar=c)},null,8,["modelValue"])]),s("div",V,[l(" Round Corners\uFF1A "),e(u,{modelValue:a.round,"onUpdate:modelValue":o[6]||(o[6]=c=>a.round=c)},null,8,["modelValue"])])]),e(b,{row:3,animate:a.animate,avatar:a.avatar,"avatar-shape":a.roundAvatar?"":"square",title:a.title,paragraph:a.paragraph,loading:a.loading,round:a.round},{default:d(()=>[C]),_:1},8,["animate","avatar","avatar-shape","title","paragraph","loading","round"])])}const{defineComponent:T,ref:k}=f,B=T({setup(){const a=k(!0),o=k(!0),u=k(!0),b=k(!0),c=k(!0),N=k(!0),E=k(!1);return{loading:a,animate:o,avatar:u,title:b,paragraph:c,roundAvatar:N,round:E}}});return{render:P,...B}}(),"render-demo-2":function(){const{resolveComponent:i,createVNode:e,createTextVNode:l,openBlock:s,createElementBlock:d}=f;function v(r,g){const p=i("n-skeleton-item");return s(),d("div",null,[e(p,{shape:"avatar",style:{"margin-left":"55px",width:"80px",height:"80px"}}),l(" \xA0 "),e(p,{shape:"image"}),l(" \xA0 "),e(p,{shape:"title"}),l(" \xA0 "),e(p,{shape:"paragraph",row:3,"row-width":["75%","50%"]}),l(" \xA0 "),e(p,{shape:"button"})])}return{render:v,...{}}}()}},X='{"title":"Skeleton","description":"","frontmatter":{},"headers":[{"level":3,"title":"When to Use","slug":"when-to-use"},{"level":3,"title":"Basic Usage","slug":"basic-usage"},{"level":3,"title":"Complex Combination","slug":"complex-combination"},{"level":3,"title":"Fine-grit Mode","slug":"fine-grit-mode"},{"level":3,"title":"n-skeleton Props","slug":"n-skeleton-props"},{"level":3,"title":"n-skeleton__avatar Props","slug":"n-skeleton-avatar-props"},{"level":3,"title":"n-skeleton__title Props","slug":"n-skeleton-title-props"},{"level":3,"title":"n-skeleton__paragraph Props","slug":"n-skeleton-paragraph-props"},{"level":3,"title":"n-skeleton-item Props","slug":"n-skeleton-item-props"},{"level":3,"title":"n-skeleton-item__avatar Props","slug":"n-skeleton-item-avatar-props"}],"relativePath":"en-US/components/skeleton/index.md","lastUpdated":1672994787141}',$=w('<h1 id="skeleton" tabindex="-1">Skeleton <a class="header-anchor" href="#skeleton" aria-hidden="true">#</a></h1><p>It is used to display a set of placeholder graphics during content loading.</p><h3 id="when-to-use" tabindex="-1">When to Use <a class="header-anchor" href="#when-to-use" aria-hidden="true">#</a></h3><p>Set a skeleton in the position where content needs to be loaded, which has better visual effect than Loading in some scenarios.</p><h3 id="basic-usage" tabindex="-1">Basic Usage <a class="header-anchor" href="#basic-usage" aria-hidden="true">#</a></h3><p>Basic placeholder effect.</p>',6),j=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton")]),n(),t("span",{class:"token attr-name"},":row"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),z=t("h3",{id:"complex-combination",tabindex:"-1"},[n("Complex Combination "),t("a",{class:"header-anchor",href:"#complex-combination","aria-hidden":"true"},"#")],-1),I=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn-groups"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Skeleton\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("loading"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Animation\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("animate"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Avatar\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("avatar"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Title\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("title"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Paragraph\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("paragraph"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Round Avatar\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("roundAvatar"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("skeleton-btn"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
      Round Corners\uFF1A
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-switch")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("round"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton")]),n(`
    `),t("span",{class:"token attr-name"},":row"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("3"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":animate"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("animate"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":avatar"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("avatar"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":avatar-shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("roundAvatar ? '' : 'square'"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":title"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("title"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":paragraph"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("paragraph"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":loading"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("loading"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":round"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("round"),t("span",{class:"token punctuation"},'"')]),n(`
  `),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n("row one"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n("row two"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n("row three"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),t("span",{class:"token punctuation"},">")]),n("row four"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-skeleton")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" loading "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" animate "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" avatar "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" title "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" paragraph "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" roundAvatar "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" round "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      loading`),t("span",{class:"token punctuation"},","),n(`
      animate`),t("span",{class:"token punctuation"},","),n(`
      avatar`),t("span",{class:"token punctuation"},","),n(`
      title`),t("span",{class:"token punctuation"},","),n(`
      paragraph`),t("span",{class:"token punctuation"},","),n(`
      roundAvatar`),t("span",{class:"token punctuation"},","),n(`
      round`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},".skeleton-btn-groups"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" flex"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"margin-bottom"),t("span",{class:"token punctuation"},":"),n(" 1rem"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token selector"},".skeleton-btn"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" flex"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"flex-direction"),t("span",{class:"token punctuation"},":"),n(" column"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"justify-content"),t("span",{class:"token punctuation"},":"),n(" space-between"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),M=t("h3",{id:"fine-grit-mode",tabindex:"-1"},[n("Fine-grit Mode "),t("a",{class:"header-anchor",href:"#fine-grit-mode","aria-hidden":"true"},"#")],-1),W=t("p",null,"Provide fine-grained skeleton elements to give developers more flexibility for customization.",-1),L=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton-item")]),n(),t("span",{class:"token attr-name"},":shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token punctuation"},"'"),n("avatar'"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"margin-left"),t("span",{class:"token punctuation"},":"),n("55px"),t("span",{class:"token punctuation"},";"),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n("80px"),t("span",{class:"token punctuation"},";"),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n("80px"),t("span",{class:"token punctuation"},";")]),t("span",{class:"token punctuation"},'"')])]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton-item")]),n(),t("span",{class:"token attr-name"},":shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token punctuation"},"'"),n("image'"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n("   "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton-item")]),n(),t("span",{class:"token attr-name"},":shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token punctuation"},"'"),n("title'"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`  
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton-item")]),n(),t("span",{class:"token attr-name"},":shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token punctuation"},"'"),n("paragraph'"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":row"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":row-width"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("['75%', '50%']"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n("   "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-skeleton-item")]),n(),t("span",{class:"token attr-name"},":shape"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token punctuation"},"'"),n("button'"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),G=w('<h3 id="n-skeleton-props" tabindex="-1">n-skeleton Props <a class="header-anchor" href="#n-skeleton-props" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">loading</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>true</code></td><td style="text-align:left;">Choose whether to display skeleton.Subcomponent content will be shown when Loading is <code>false</code> .</td></tr><tr><td style="text-align:center;">animate</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>true</code></td><td style="text-align:left;">Choose whether to enable animation.</td></tr><tr><td style="text-align:center;">avatar</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>false</code></td><td style="text-align:left;">Choose whether to display the avatar placeholder picture.</td></tr><tr><td style="text-align:center;">title</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>true</code></td><td style="text-align:left;">Choose whether to display a title placeholder picture.</td></tr><tr><td style="text-align:center;">paragraph</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>true</code></td><td style="text-align:left;">Choose whether to display a paragraph placeholder picture.</td></tr><tr><td style="text-align:center;">round</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>false</code></td><td style="text-align:left;">Choose whether to display headings and paragraphs in round corners.</td></tr></tbody></table><h3 id="n-skeleton-avatar-props" tabindex="-1">n-skeleton__avatar Props <a class="header-anchor" href="#n-skeleton-avatar-props" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">avatar-size</td><td style="text-align:center;"><code>number | string</code></td><td style="text-align:center;"><code>40px</code></td><td style="text-align:left;">Size of avatar placeholder picture.</td></tr><tr><td style="text-align:center;">avatar-shape</td><td style="text-align:center;"><code>string</code></td><td style="text-align:center;"><code>round</code></td><td style="text-align:left;">The shape of head placeholder picture with the optional value <code>square</code>.</td></tr></tbody></table><h3 id="n-skeleton-title-props" tabindex="-1">n-skeleton__title Props <a class="header-anchor" href="#n-skeleton-title-props" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">title-width</td><td style="text-align:center;"><code>number | string</code></td><td style="text-align:center;"><code>40%</code></td><td style="text-align:left;">Width of the title placeholder picture.</td></tr></tbody></table><h3 id="n-skeleton-paragraph-props" tabindex="-1">n-skeleton__paragraph Props <a class="header-anchor" href="#n-skeleton-paragraph-props" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">row</td><td style="text-align:center;"><code>number</code></td><td style="text-align:center;"><code>0</code></td><td style="text-align:left;">The number of paragraph placeholder picture lines.</td></tr><tr><td style="text-align:center;">row-width</td><td style="text-align:center;"><code>number | string | (number | string)[]</code></td><td style="text-align:center;"><code>[&quot;100%&quot;]</code></td><td style="text-align:left;">Paragraph placeholder picture widths that can be passed to arrays to set the width of each line.</td></tr></tbody></table><h3 id="n-skeleton-item-props" tabindex="-1">n-skeleton-item Props <a class="header-anchor" href="#n-skeleton-item-props" aria-hidden="true">#</a></h3><p>Fine-grit Mode</p><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">shape</td><td style="text-align:center;"><code>string</code></td><td style="text-align:center;">-</td><td style="text-align:left;">The optional values are <code>avatar</code>,<code>image</code>,<code>title</code>,<code>paragraph</code>,<code>button</code>.</td></tr><tr><td style="text-align:center;">animate</td><td style="text-align:center;"><code>boolean</code></td><td style="text-align:center;"><code>true</code></td><td style="text-align:left;">Choose whether to enable animation.</td></tr></tbody></table><blockquote><p>The Paragraph API is the same as the default mode.</p></blockquote><h3 id="n-skeleton-item-avatar-props" tabindex="-1">n-skeleton-item__avatar Props <a class="header-anchor" href="#n-skeleton-item-avatar-props" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:center;">Parameter</th><th style="text-align:center;">Type</th><th style="text-align:center;">Default</th><th style="text-align:left;">Description</th></tr></thead><tbody><tr><td style="text-align:center;">avatar-shape</td><td style="text-align:center;"><code>string</code></td><td style="text-align:center;"><code>round</code></td><td style="text-align:left;">The shape of placeholder picture with the optional value <code>square</code>.</td></tr></tbody></table>',14);function H(i,e,l,s,d,v){const y=x("render-demo-0"),r=x("demo"),g=x("render-demo-1"),p=x("render-demo-2");return U(),S("div",null,[$,h(r,{sourceCode:`<template>
  <n-skeleton :row="3" />
</template>
`},{highlight:m(()=>[j]),default:m(()=>[h(y)]),_:1}),z,h(r,{sourceCode:`<template>
  <div class="skeleton-btn-groups">
    <div class="skeleton-btn">
      Skeleton\uFF1A
      <n-switch v-model="loading" />
    </div>
    <div class="skeleton-btn">
      Animation\uFF1A
      <n-switch v-model="animate" />
    </div>
    <div class="skeleton-btn">
      Avatar\uFF1A
      <n-switch v-model="avatar" />
    </div>
    <div class="skeleton-btn">
      Title\uFF1A
      <n-switch v-model="title" />
    </div>
    <div class="skeleton-btn">
      Paragraph\uFF1A
      <n-switch v-model="paragraph" />
    </div>
    <div class="skeleton-btn">
      Round Avatar\uFF1A
      <n-switch v-model="roundAvatar" />
    </div>
    <div class="skeleton-btn">
      Round Corners\uFF1A
      <n-switch v-model="round" />
    </div>
  </div>
  <n-skeleton
    :row="3"
    :animate="animate"
    :avatar="avatar"
    :avatar-shape="roundAvatar ? '' : 'square'"
    :title="title"
    :paragraph="paragraph"
    :loading="loading"
    :round="round"
  >
    <div>
      <div>row one</div>
      <div>row two</div>
      <div>row three</div>
      <div>row four</div>
    </div>
  </n-skeleton>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const loading = ref(true);
    const animate = ref(true);
    const avatar = ref(true);
    const title = ref(true);
    const paragraph = ref(true);
    const roundAvatar = ref(true);
    const round = ref(false);

    return {
      loading,
      animate,
      avatar,
      title,
      paragraph,
      roundAvatar,
      round,
    };
  },
});
<\/script>
<style>
.skeleton-btn-groups {
  display: flex;
  margin-bottom: 1rem;
}
.skeleton-btn {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
</style>
`},{highlight:m(()=>[I]),default:m(()=>[h(g)]),_:1}),M,W,h(r,{sourceCode:`<template>
  <n-skeleton-item :shape="'avatar'" style="margin-left:55px;width:80px;height:80px;" />
  \xA0 <n-skeleton-item :shape="'image'" /> \xA0 <n-skeleton-item :shape="'title'" /> \xA0
  <n-skeleton-item :shape="'paragraph'" :row="3" :row-width="['75%', '50%']" /> \xA0 <n-skeleton-item :shape="'button'" />
</template>
`},{highlight:m(()=>[L]),default:m(()=>[h(p)]),_:1}),G])}var Y=D(R,[["render",H]]);export{X as __pageData,Y as default};
