import{V as E}from"./framework.1c17ccd8.js";import{_ as w}from"./plugin-vue_export-helper.21dcd24c.js";import{f as D,G as V,H as q,b,a6 as d,V as y,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const N={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,toDisplayString:a,createElementVNode:i,openBlock:m,createElementBlock:r}=E;function f(s,u){const c=p("n-button"),F=p("n-modal");return m(),r("div",null,[l(c,{onClick:s.handleClick},{default:o(()=>[e("\u6253\u5F00 modal")]),_:1},8,["onClick"]),l(F,{modelValue:s.visible,"onUpdate:modelValue":u[0]||(u[0]=k=>s.visible=k),title:"Start Snapshot Version"},{default:o(()=>[i("div",null,"name: "+a(s.data.name),1),i("div",null,"age: "+a(s.data.age),1),i("div",null,"address: "+a(s.data.address),1)]),_:1},8,["modelValue"])])}const{defineComponent:A,ref:g,reactive:C}=E,v=A({setup(){const s=g(!1),u=C({name:"Tom",age:20,address:"Chengdu"});return{visible:s,data:u,handleClick:()=>{s.value=!0}}}});return{render:f,...v}}(),"render-demo-1":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,createElementVNode:a,openBlock:i,createElementBlock:m}=E,r=a("div",{style:{"margin-top":"5px"}},[e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix "),a("br"),e(" \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 "),a("br"),e(" \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 "),a("br"),e(" \u8FD9\u91CC\u53EF\u4EE5\u8F93\u5165\u5176\u4ED6\u5185\u5BB9 ")],-1);function f(s,u){const c=p("n-button"),F=p("n-modal-footer"),k=p("n-modal");return i(),m("div",null,[l(c,{onClick:s.handleClick},{default:o(()=>[e("\u6253\u5F00 modal")]),_:1},8,["onClick"]),l(k,{modelValue:s.visible,"onUpdate:modelValue":u[1]||(u[1]=B=>s.visible=B),title:"Start Keep Last",bodyClass:"123455","keep-last":!0,bodyMaxHeight:400},{footer:o(()=>[l(F,null,{default:o(()=>[l(c,{onClick:u[0]||(u[0]=B=>s.visible=!1)},{default:o(()=>[e("\u53D6\u6D88")]),_:1})]),_:1})]),default:o(()=>[r]),_:1},8,["modelValue"])])}const{defineComponent:A,ref:g,reactive:C}=E,v=A({setup(){const s=g(!1),u=C({name:"Tom",age:20,address:"Chengdu"});return{visible:s,data:u,handleClick:()=>{s.value=!0}}}});return{render:f,...v}}(),"render-demo-2":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,createElementVNode:a,toDisplayString:i,openBlock:m,createElementBlock:r}=E,f=a("span",null,"Good Title",-1);function A(u,c){const F=p("n-button"),k=p("n-icon"),B=p("n-modal-header"),h=p("n-modal-footer"),x=p("n-modal");return m(),r("div",null,[l(F,{onClick:u.handleClick},{default:o(()=>[e("\u6253\u5F00 modal")]),_:1},8,["onClick"]),l(x,{modelValue:u.visible,"onUpdate:modelValue":c[0]||(c[0]=_=>u.visible=_)},{header:o(()=>[l(B,null,{default:o(()=>[l(k,{name:"like"}),f]),_:1})]),footer:o(()=>[l(h,{style:{"text-align":"right","padding-right":"20px"}},{default:o(()=>[l(F,{onClick:u.hidden},{default:o(()=>[e("\u53D6\u6D88")]),_:1},8,["onClick"]),l(F,{onClick:u.hidden},{default:o(()=>[e("\u786E\u8BA4")]),_:1},8,["onClick"])]),_:1})]),default:o(()=>[a("div",null,"name: "+i(u.data.name),1),a("div",null,"age: "+i(u.data.age),1),a("div",null,"address: "+i(u.data.address),1)]),_:1},8,["modelValue"])])}const{ref:g,defineComponent:C,reactive:v}=E,s=C({setup(){const u=g(!1),c=v({name:"Tom",age:20,address:"Chengdu"});return{visible:u,data:c,handleClick:()=>{u.value=!0},hidden:()=>{u.value=!1}}}});return{render:A,...s}}(),"render-demo-3":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,toDisplayString:a,createElementVNode:i,openBlock:m,createElementBlock:r}=E;function f(s,u){const c=p("n-button"),F=p("n-modal");return m(),r("div",null,[l(c,{class:"mr-1",onClick:u[0]||(u[0]=k=>s.handleClick("success"))},{default:o(()=>[e("success")]),_:1}),l(c,{class:"mr-1",onClick:u[1]||(u[1]=k=>s.handleClick("failed"))},{default:o(()=>[e("failed")]),_:1}),l(c,{class:"mr-1",onClick:u[2]||(u[2]=k=>s.handleClick("warning"))},{default:o(()=>[e("warning")]),_:1}),l(c,{class:"mr-1",onClick:u[3]||(u[3]=k=>s.handleClick("info"))},{default:o(()=>[e("info")]),_:1}),l(F,{modelValue:s.visible,"onUpdate:modelValue":u[4]||(u[4]=k=>s.visible=k),title:"Start Snapshot Version",type:s.type},{default:o(()=>[i("div",null,"name: "+a(s.data.name),1),i("div",null,"age: "+a(s.data.age),1),i("div",null,"address: "+a(s.data.address),1)]),_:1},8,["modelValue","type"])])}const{defineComponent:A,ref:g,reactive:C}=E,v=A({setup(){const s=g(!1),u=g(""),c=C({name:"Tom",age:20,address:"Chengdu"});return{visible:s,data:c,handleClick:k=>{s.value=!0,u.value=k},type:u}}});return{render:f,...v}}(),"render-demo-4":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,toDisplayString:a,createElementVNode:i,openBlock:m,createElementBlock:r}=E;function f(s,u){const c=p("n-button"),F=p("n-modal-footer"),k=p("n-modal");return m(),r("div",null,[l(c,{onClick:s.handleClick},{default:o(()=>[e("\u6253\u5F00 modal")]),_:1},8,["onClick"]),l(k,{modelValue:s.visible,"onUpdate:modelValue":u[0]||(u[0]=B=>s.visible=B),"before-close":s.beforeClose,style:{width:"500px"}},{footer:o(()=>[l(F,{style:{"text-align":"right","padding-right":"20px"}},{default:o(()=>[l(c,{onClick:s.hidden},{default:o(()=>[e("\u53D6\u6D88")]),_:1},8,["onClick"]),l(c,{onClick:s.hidden},{default:o(()=>[e("\u786E\u8BA4")]),_:1},8,["onClick"])]),_:1})]),default:o(()=>[i("div",null,"name: "+a(s.data.name),1),i("div",null,"age: "+a(s.data.age),1),i("div",null,"address: "+a(s.data.address),1)]),_:1},8,["modelValue","before-close"])])}const{ref:A,defineComponent:g,reactive:C}=E,v=g({setup(){const s=A(!1),u=C({name:"Tom",age:20,address:"Chengdu"});return{visible:s,data:u,handleClick:()=>{s.value=!0},hidden:()=>{s.value=!1},beforeClose:B=>{new Promise(h=>{setTimeout(h,1e3)}).then(B)}}}});return{render:f,...v}}(),"render-demo-5":function(){const{createTextVNode:e,resolveComponent:p,withCtx:o,createVNode:l,toDisplayString:a,createElementVNode:i,openBlock:m,createElementBlock:r}=E;function f(s,u){const c=p("n-button"),F=p("n-modal");return m(),r("div",null,[l(c,{onClick:s.handleClick},{default:o(()=>[e("\u6253\u5F00 modal")]),_:1},8,["onClick"]),l(F,{modelValue:s.visible,"onUpdate:modelValue":u[0]||(u[0]=k=>s.visible=k),fullscreen:s.fullscreen,title:"Start Keep Last","keep-last":!0},{default:o(()=>[i("div",null,"name: "+a(s.data.name),1),i("div",null,"age: "+a(s.data.age),1),i("div",null,"address: "+a(s.data.address),1)]),_:1},8,["modelValue","fullscreen"])])}const{defineComponent:A,ref:g,reactive:C}=E,v=A({setup(){const s=g(!1),u=g(!0),c=C({name:"Tom",age:20,address:"Chengdu"});return{visible:s,data:c,handleClick:()=>{s.value=!0},fullscreen:u}}});return{render:f,...v}}()}},sn='{"title":"Modal \u6A21\u6001\u5F39\u7A97","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u7840\u7528\u6CD5","slug":"\u57FA\u7840\u7528\u6CD5"},{"level":3,"title":"\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E","slug":"\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u6807\u9898\u548C\u64CD\u4F5C\u6309\u94AE","slug":"\u81EA\u5B9A\u4E49\u6807\u9898\u548C\u64CD\u4F5C\u6309\u94AE"},{"level":3,"title":"\u4FE1\u606F\u63D0\u793A","slug":"\u4FE1\u606F\u63D0\u793A"},{"level":3,"title":"\u5173\u95ED\u524D\u56DE\u8C03","slug":"\u5173\u95ED\u524D\u56DE\u8C03"},{"level":3,"title":"\u662F\u5426\u4E3A\u5168\u5C4F","slug":"\u662F\u5426\u4E3A\u5168\u5C4F"},{"level":3,"title":"Modal \u53C2\u6570","slug":"modal-\u53C2\u6570"},{"level":3,"title":"Modal \u63D2\u69FD","slug":"modal-\u63D2\u69FD"}],"relativePath":"components/modal/index.md","lastUpdated":1685955067574}',T=y('<h1 id="modal-\u6A21\u6001\u5F39\u7A97" tabindex="-1">Modal \u6A21\u6001\u5F39\u7A97 <a class="header-anchor" href="#modal-\u6A21\u6001\u5F39\u7A97" aria-hidden="true">#</a></h1><p>\u6A21\u6001\u6846\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>1.\u9700\u8981\u7528\u6237\u5904\u7406\u4E8B\u52A1\uFF0C\u53C8\u4E0D\u5E0C\u671B\u8DF3\u8F6C\u9875\u9762\u4EE5\u81F4\u6253\u65AD\u5DE5\u4F5C\u6D41\u7A0B\u65F6\uFF0C\u53EF\u4EE5\u4F7F\u7528 Modal \u5728\u5F53\u524D\u9875\u9762\u6B63\u4E2D\u6253\u5F00\u4E00\u4E2A\u6D6E\u5C42\uFF0C\u627F\u8F7D\u76F8\u5E94\u7684\u64CD\u4F5C\u3002</p><p>2.Modal \u8D77\u5230\u4E0E\u7528\u6237\u8FDB\u884C\u4EA4\u4E92\u7684\u4F5C\u7528\uFF0C\u7528\u6237\u53EF\u4EE5\u5728 Modal \u4E2D\u8F93\u5165\u4FE1\u606F\u3001\u9605\u8BFB\u63D0\u793A\u3001\u8BBE\u7F6E\u9009\u9879\u7B49\u64CD\u4F5C\u3002</p><h3 id="\u57FA\u7840\u7528\u6CD5" tabindex="-1">\u57FA\u7840\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u7840\u7528\u6CD5" aria-hidden="true">#</a></h3>',6),S=n("div",null,[n("code",null,"v-model"),t("\u53CC\u5411\u7ED1\u5B9A\uFF0C\u63A7\u5236 Modal \u662F\u5426\u663E\u793A\uFF1B"),n("code",null,"title"),t("\u53C2\u6570\u8BBE\u7F6E Modal \u6807\u9898\u3002")],-1),M=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6253\u5F00 modal"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"title"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Start Snapshot Version"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("name: {{ data.name }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("age: {{ data.age }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("address: {{ data.address }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),$=n("h3",{id:"\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E",tabindex:"-1"},[t("\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E "),n("a",{class:"header-anchor",href:"#\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E","aria-hidden":"true"},"#")],-1),U=n("div",null,[n("code",null,"keep-last"),t("\u53EF\u4F7F\u5F53\u524D modal \u518D\u6B21\u6253\u5F00\u65F6\u4FDD\u7559\u4E0A\u6B21\u5173\u95ED\u4F4D\u7F6E\u3002")],-1),j=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6253\u5F00 modal"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"title"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Start Keep Last"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"bodyClass"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("123455"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":keep-last"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("true"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":bodyMaxHeight"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"margin-top"),n("span",{class:"token punctuation"},":"),t(" 5px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      \u8FD9\u91CC\u53EF\u4EE5\u8F93\u5165\u5176\u4ED6\u5185\u5BB9
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`

    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#footer"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal-footer")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible = false"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u53D6\u6D88"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal-footer")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),K=n("h3",{id:"\u81EA\u5B9A\u4E49\u6807\u9898\u548C\u64CD\u4F5C\u6309\u94AE",tabindex:"-1"},[t("\u81EA\u5B9A\u4E49\u6807\u9898\u548C\u64CD\u4F5C\u6309\u94AE "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u6807\u9898\u548C\u64CD\u4F5C\u6309\u94AE","aria-hidden":"true"},"#")],-1),L=n("div",null,[n("code",null,"header"),t("\u63D2\u69FD\u53EF\u4EE5\u81EA\u5B9A\u4E49 Modal \u9876\u90E8\u533A\u57DF\uFF0C\u5B50\u7EC4\u4EF6"),n("code",null,"n-modal-header"),t("\u4E3A\u9876\u90E8\u533A\u57DF\u63D0\u4F9B\u4E86\u9ED8\u8BA4\u6837\u5F0F\uFF0C\u81EA\u5B9A\u4E49\u6837\u5F0F\u53EF\u901A\u8FC7\u5728\u5B50\u7EC4\u4EF6\u8BBE\u7F6E"),n("code",null,"style/class"),t("\u5B9E\u73B0\u3002"),n("code",null,"footer"),t("\u63D2\u69FD\u540C\u7406\u3002")],-1),H=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6253\u5F00 modal"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#header"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal-header")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-icon")]),t(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("like"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-icon")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("Good Title"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal-header")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("name: {{ data.name }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("age: {{ data.age }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("address: {{ data.address }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#footer"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal-footer")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" right"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"padding-right"),n("span",{class:"token punctuation"},":"),t(" 20px"),n("span",{class:"token punctuation"},";")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hidden"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u53D6\u6D88"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hidden"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u786E\u8BA4"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal-footer")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"hidden"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick"),n("span",{class:"token punctuation"},","),t(" hidden "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),G=n("h3",{id:"\u4FE1\u606F\u63D0\u793A",tabindex:"-1"},[t("\u4FE1\u606F\u63D0\u793A "),n("a",{class:"header-anchor",href:"#\u4FE1\u606F\u63D0\u793A","aria-hidden":"true"},"#")],-1),P=n("div",null,"\u5404\u79CD\u7C7B\u578B\u7684\u4FE1\u606F\u63D0\u793A\u6846\u3002",-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mr-1"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick('success')"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("success"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mr-1"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick('failed')"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("failed"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mr-1"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick('warning')"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("warning"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mr-1"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick('info')"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("info"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"title"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Start Snapshot Version"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":type"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("type"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("name: {{ data.name }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("age: {{ data.age }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("address: {{ data.address }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" type "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"t"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
      type`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" t"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick"),n("span",{class:"token punctuation"},","),t(" type "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),z=n("h3",{id:"\u5173\u95ED\u524D\u56DE\u8C03",tabindex:"-1"},[t("\u5173\u95ED\u524D\u56DE\u8C03 "),n("a",{class:"header-anchor",href:"#\u5173\u95ED\u524D\u56DE\u8C03","aria-hidden":"true"},"#")],-1),J=n("div",null,[n("code",null,"before-close"),t("\u5728\u7528\u6237\u70B9\u51FB\u5173\u95ED\u6309\u94AE\u6216\u8005\u906E\u7F69\u5C42\u65F6\u4F1A\u88AB\u8C03\u7528\uFF0C\u53EF\u5728\u5B8C\u6210\u67D0\u4E9B\u5F02\u6B65\u64CD\u4F5C\u540E\uFF0C\u901A\u8FC7"),n("code",null,"done"),t("\u53C2\u6570\u5173\u95ED\u3002")],-1),O=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6253\u5F00 modal"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":before-close"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("beforeClose"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 500px"),n("span",{class:"token punctuation"},";")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("name: {{ data.name }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("age: {{ data.age }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("address: {{ data.address }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#footer"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal-footer")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" right"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"padding-right"),n("span",{class:"token punctuation"},":"),t(" 20px"),n("span",{class:"token punctuation"},";")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hidden"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u53D6\u6D88"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("hidden"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u786E\u8BA4"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal-footer")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"hidden"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"beforeClose"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"done"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"new"),t(),n("span",{class:"token class-name"},"Promise"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"resolve"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token function"},"setTimeout"),n("span",{class:"token punctuation"},"("),t("resolve"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"1000"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"then"),n("span",{class:"token punctuation"},"("),t("done"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick"),n("span",{class:"token punctuation"},","),t(" hidden"),n("span",{class:"token punctuation"},","),t(" beforeClose "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),Q=n("h3",{id:"\u662F\u5426\u4E3A\u5168\u5C4F",tabindex:"-1"},[t("\u662F\u5426\u4E3A\u5168\u5C4F "),n("a",{class:"header-anchor",href:"#\u662F\u5426\u4E3A\u5168\u5C4F","aria-hidden":"true"},"#")],-1),R=n("div",null,[n("code",null,"fullscreen"),t("\u53EF\u4F7F\u5F53\u524D modal \u5168\u5C4F\u3002")],-1),W=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("handleClick"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u6253\u5F00 modal"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-modal")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":fullscreen"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("fullscreen"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"title"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Start Keep Last"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":keep-last"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("name: {{ data.name }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("age: {{ data.age }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t("address: {{ data.address }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-modal")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" fullscreen "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"age"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"20"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"address"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Chengdu'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"handleClick"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      visible`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" handleClick"),n("span",{class:"token punctuation"},","),t(" fullscreen "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),X=y('<h3 id="modal-\u53C2\u6570" tabindex="-1">Modal \u53C2\u6570 <a class="header-anchor" href="#modal-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u662F\u5426\u663E\u793A Modal</td><td style="text-align:left;"><a href="#%E5%9F%BA%E7%A1%80%E7%94%A8%E6%B3%95">\u57FA\u7840\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">title</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0CModal \u7684\u6807\u9898</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">width</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">800px</td><td style="text-align:left;">\u53EF\u9009\uFF0CModal \u7684\u5BBD\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">bodyMaxHeight</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0CModal-body \u90E8\u5206 max-height</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">keep-last</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u4FDD\u7559\u4E0A\u6B21\u79FB\u52A8\u4F4D\u7F6E</td><td style="text-align:left;"><a href="#%E4%BF%9D%E7%95%99%E6%9C%80%E5%90%8E%E4%B8%80%E6%AC%A1%E5%85%B3%E9%97%AD%E4%BD%8D%E7%BD%AE">\u4FDD\u7559\u6700\u540E\u4E00\u6B21\u5173\u95ED\u4F4D\u7F6E</a></td></tr><tr><td style="text-align:left;">lock-scroll</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u5C06 body \u6EDA\u52A8\u9501\u5B9A</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">close-on-click-overlay</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u70B9\u51FB\u7A7A\u767D\u5904\u662F\u5426\u80FD\u5173\u95ED Modal</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">before-close</td><td style="text-align:left;"><code>(done) =&gt; void</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5173\u95ED\u524D\u7684\u56DE\u8C03\uFF0C\u8C03\u7528 done \u53EF\u5173\u95ED Modal</td><td style="text-align:left;"><a href="#%E5%85%B3%E9%97%AD%E5%89%8D%E5%9B%9E%E8%B0%83">\u5173\u95ED\u524D\u56DE\u8C03</a></td></tr><tr><td style="text-align:left;">open</td><td style="text-align:left;"><code>() =&gt; void</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u6253\u5F00\u5F39\u7A97\u65F6\u6267\u884C</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">escapable</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u652F\u6301 esc \u952E\u5173\u95ED\u5F39\u7A97</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">show-close</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u5C55\u793A\u5173\u95ED\u6309\u94AE</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">draggable</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5F39\u6846\u662F\u5426\u53EF\u62D6\u62FD</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">show-animation</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u52A8\u753B</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">show-overlay</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u5C55\u793A\u906E\u7F69\u5C42</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">append-to-body</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u5C06 Modal \u63D0\u5347\u5230 body \u5C42</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;">success | failed | warning | info</td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5F39\u6846\u4FE1\u606F\u63D0\u793A</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">fullscreen</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u5168\u5C4F</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">bodyClass</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">-</td><td style="text-align:left;">\u53EF\u9009\uFF0Cbody \u81EA\u5B9A\u4E49 class \u540D</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="modal-\u63D2\u69FD" tabindex="-1">Modal \u63D2\u69FD <a class="header-anchor" href="#modal-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u63D2\u69FD\u540D</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">default</td><td style="text-align:left;">Modal \u5185\u5BB9</td></tr><tr><td style="text-align:left;">header</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 Modal \u9876\u90E8</td></tr><tr><td style="text-align:left;">footer</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 Modal \u5E95\u90E8</td></tr></tbody></table>',4);function Y(e,p,o,l,a,i){const m=D("render-demo-0"),r=D("demo"),f=D("render-demo-1"),A=D("render-demo-2"),g=D("render-demo-3"),C=D("render-demo-4"),v=D("render-demo-5");return V(),q("div",null,[T,b(r,{sourceCode:`<template>
  <n-button @click="handleClick">\u6253\u5F00 modal</n-button>
  <n-modal v-model="visible" title="Start Snapshot Version">
    <div>name: {{ data.name }}</div>
    <div>age: {{ data.age }}</div>
    <div>address: {{ data.address }}</div>
  </n-modal>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = () => {
      visible.value = true;
    };

    return { visible, data, handleClick };
  },
});
<\/script>
`},{description:d(()=>[S]),highlight:d(()=>[M]),default:d(()=>[b(m)]),_:1}),$,b(r,{sourceCode:`<template>
  <n-button @click="handleClick">\u6253\u5F00 modal</n-button>
  <n-modal v-model="visible" title="Start Keep Last" bodyClass="123455" :keep-last="true" :bodyMaxHeight="400">
    <div style="margin-top: 5px">
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u4EEA\u8868\u677F\u540D\u79F0\uFF1A\u6D4B\u8BD5mix <br />
      \u5BFC\u51FA\u65F6\u95F4\uFF1A2023-05-11 16:21:47 <br />
      \u5BFC\u51FA\u4EBA\uFF1A\u7BA1\u7406\u5458 <br />
      \u8FD9\u91CC\u53EF\u4EE5\u8F93\u5165\u5176\u4ED6\u5185\u5BB9
    </div>

    <template #footer>
      <n-modal-footer>
        <n-button @click="visible = false">\u53D6\u6D88</n-button>
      </n-modal-footer>
    </template>
  </n-modal>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = () => {
      visible.value = true;
    };

    return { visible, data, handleClick };
  },
});
<\/script>
`},{description:d(()=>[U]),highlight:d(()=>[j]),default:d(()=>[b(f)]),_:1}),K,b(r,{sourceCode:`<template>
  <n-button @click="handleClick">\u6253\u5F00 modal</n-button>
  <n-modal v-model="visible">
    <template #header>
      <n-modal-header>
        <n-icon name="like"></n-icon>
        <span>Good Title</span>
      </n-modal-header>
    </template>
    <div>name: {{ data.name }}</div>
    <div>age: {{ data.age }}</div>
    <div>address: {{ data.address }}</div>
    <template #footer>
      <n-modal-footer style="text-align: right; padding-right: 20px;">
        <n-button @click="hidden">\u53D6\u6D88</n-button>
        <n-button @click="hidden">\u786E\u8BA4</n-button>
      </n-modal-footer>
    </template>
  </n-modal>
</template>
<script>
import { ref, defineComponent, reactive } from 'vue';
export default defineComponent({
  setup() {
    const visible = ref(false);
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = () => {
      visible.value = true;
    };
    const hidden = () => {
      visible.value = false;
    };

    return { visible, data, handleClick, hidden };
  },
});
<\/script>
`},{description:d(()=>[L]),highlight:d(()=>[H]),default:d(()=>[b(A)]),_:1}),G,b(r,{sourceCode:`<template>
  <n-button class="mr-1" @click="handleClick('success')">success</n-button>
  <n-button class="mr-1" @click="handleClick('failed')">failed</n-button>
  <n-button class="mr-1" @click="handleClick('warning')">warning</n-button>
  <n-button class="mr-1" @click="handleClick('info')">info</n-button>
  <n-modal v-model="visible" title="Start Snapshot Version" :type="type">
    <div>name: {{ data.name }}</div>
    <div>age: {{ data.age }}</div>
    <div>address: {{ data.address }}</div>
  </n-modal>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);
    const type = ref('');
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = (t) => {
      visible.value = true;
      type.value = t;
    };

    return { visible, data, handleClick, type };
  },
});
<\/script>
`},{description:d(()=>[P]),highlight:d(()=>[I]),default:d(()=>[b(g)]),_:1}),z,b(r,{sourceCode:`<template>
  <n-button @click="handleClick">\u6253\u5F00 modal</n-button>
  <n-modal v-model="visible" :before-close="beforeClose" style="width: 500px;">
    <div>name: {{ data.name }}</div>
    <div>age: {{ data.age }}</div>
    <div>address: {{ data.address }}</div>
    <template #footer>
      <n-modal-footer style="text-align: right; padding-right: 20px;">
        <n-button @click="hidden">\u53D6\u6D88</n-button>
        <n-button @click="hidden">\u786E\u8BA4</n-button>
      </n-modal-footer>
    </template>
  </n-modal>
</template>

<script>
import { ref, defineComponent, reactive } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = () => {
      visible.value = true;
    };
    const hidden = () => {
      visible.value = false;
    };
    const beforeClose = (done) => {
      new Promise((resolve) => {
        setTimeout(resolve, 1000);
      }).then(done);
    };

    return { visible, data, handleClick, hidden, beforeClose };
  },
});
<\/script>
`},{description:d(()=>[J]),highlight:d(()=>[O]),default:d(()=>[b(C)]),_:1}),Q,b(r,{sourceCode:`<template>
  <n-button @click="handleClick">\u6253\u5F00 modal</n-button>
  <n-modal v-model="visible" :fullscreen="fullscreen" title="Start Keep Last" :keep-last="true">
    <div>name: {{ data.name }}</div>
    <div>age: {{ data.age }}</div>
    <div>address: {{ data.address }}</div>
  </n-modal>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);
    const fullscreen = ref(true);
    const data = reactive({
      name: 'Tom',
      age: 20,
      address: 'Chengdu',
    });
    const handleClick = () => {
      visible.value = true;
    };
    return { visible, data, handleClick, fullscreen };
  },
});
<\/script>
`},{description:d(()=>[R]),highlight:d(()=>[W]),default:d(()=>[b(v)]),_:1}),X])}var en=w(N,[["render",Y]]);export{sn as __pageData,en as default};
