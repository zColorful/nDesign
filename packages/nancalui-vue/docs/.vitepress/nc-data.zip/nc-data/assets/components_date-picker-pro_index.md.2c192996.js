import{V as D}from"./framework.1c17ccd8.js";import{_ as Y}from"./plugin-vue_export-helper.21dcd24c.js";import{f as b,G as M,H as T,b as P,a6 as h,V as A,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const R={name:"component-doc",components:{"render-demo-0":function(){const{createElementVNode:a,resolveComponent:E,createVNode:o,openBlock:y,createElementBlock:l}=D,p={class:"picker-pro-format-demo mr30"},F=a("div",{class:"mb10"},"Small",-1),g={class:"picker-pro-format-demo mr30"},c=a("div",{class:"mb10"},"Middle",-1),r={class:"picker-pro-format-demo mr30"},v=a("div",{class:"mb10"},"Large",-1);function f(d,e){const s=E("n-date-picker-pro");return y(),l("div",null,[a("div",p,[F,o(s,{modelValue:d.datePickerProValue,"onUpdate:modelValue":e[0]||(e[0]=i=>d.datePickerProValue=i),class:"mb20 wh250",size:"sm"},null,8,["modelValue"])]),a("div",g,[c,o(s,{modelValue:d.datePickerProValue2,"onUpdate:modelValue":e[1]||(e[1]=i=>d.datePickerProValue2=i),class:"mb20 wh250"},null,8,["modelValue"])]),a("div",r,[v,o(s,{modelValue:d.datePickerProValue3,"onUpdate:modelValue":e[2]||(e[2]=i=>d.datePickerProValue3=i),class:"mb20 wh250",size:"lg"},null,8,["modelValue"])])])}const{defineComponent:m,ref:u}=D,k=m({setup(){const d=u(""),e=u(""),s=u("");return{datePickerProValue:d,datePickerProValue2:e,datePickerProValue3:s}}});return{render:f,...k}}(),"render-demo-1":function(){const{resolveComponent:a,createVNode:E,openBlock:o,createElementBlock:y}=D;function l(c,r){const v=a("n-date-picker-pro");return o(),y("div",null,[E(v,{modelValue:c.datePickerProValue1,"onUpdate:modelValue":r[0]||(r[0]=f=>c.datePickerProValue1=f),class:"mb20 wh250",showTime:!0,format:"YYYY/MM/DD HH:mm:ss"},null,8,["modelValue"])])}const{defineComponent:p,ref:F}=D,g=p({setup(){return{datePickerProValue1:F("")}}});return{render:l,...g}}(),"render-demo-2":function(){const{createElementVNode:a,renderSlot:E,createTextVNode:o,resolveComponent:y,withCtx:l,createVNode:p,toDisplayString:F,openBlock:g,createElementBlock:c}=D,r=a("div",{class:"mb10"},"right area",-1),v={class:"date-picker-right-panel"},f=a("div",{class:"mb10"},"footer",-1),m={class:"date-picker-footer"};function u(s,i){const C=y("n-button"),V=y("n-date-picker-pro");return g(),c("div",null,[r,p(V,{modelValue:s.datePickerProValue1,"onUpdate:modelValue":i[4]||(i[4]=w=>s.datePickerProValue1=w),class:"mb20 wh250",showTime:!0},{rightArea:l(()=>[E(s.$slots,"rightArea",{},()=>[a("ul",v,[a("li",null,[p(C,{variant:"text",color:"primary",onClick:i[0]||(i[0]=()=>{s.setDate(-30)})},{default:l(()=>[o(" \u4E00\u4E2A\u6708\u524D ")]),_:1}),a("span",null,F(s.getDateString(-30)),1)]),a("li",null,[p(C,{variant:"text",color:"primary",onClick:i[1]||(i[1]=()=>{s.setDate(-14)})},{default:l(()=>[o(" \u4E24\u5468\u524D ")]),_:1}),a("span",null,F(s.getDateString(-14)),1)]),a("li",null,[p(C,{variant:"text",color:"primary",onClick:i[2]||(i[2]=()=>{s.setDate(-7)})},{default:l(()=>[o(" \u4E00\u5468\u524D ")]),_:1}),a("span",null,F(s.getDateString(-7)),1)]),a("li",null,[p(C,{variant:"text",color:"primary",onClick:i[3]||(i[3]=()=>{s.setDate(0)})},{default:l(()=>[o(" \u4ECA\u5929 ")]),_:1}),a("span",null,F(s.getDateString(0)),1)])])])]),_:3},8,["modelValue"]),f,p(V,{modelValue:s.datePickerProValue2,"onUpdate:modelValue":i[5]||(i[5]=w=>s.datePickerProValue2=w),class:"mb20 wh250",showTime:!0},{footer:l(()=>[E(s.$slots,"footer",{},()=>[a("div",m,[p(C,{variant:"solid",color:"secondary",onClick:s.setToday},{default:l(()=>[o(" \u4ECA\u5929 ")]),_:1},8,["onClick"]),p(C,{variant:"solid",color:"secondary",onClick:s.clearDate},{default:l(()=>[o(" \u6E05\u9664\u65F6\u95F4 ")]),_:1},8,["onClick"])])])]),_:3},8,["modelValue"])])}const{defineComponent:k,ref:d}=D,e=k({setup(){const s=d(""),i=d("");return{datePickerProValue1:s,datePickerProValue2:i,setDate:B=>{s.value=new Date(new Date().getTime()+B*24*3600*1e3)},getDateString:B=>{const x=new Date(new Date().getTime()+B*24*3600*1e3);return`${x.getMonth()+1}\u6708${x.getDate()}\u65E5`},setToday:()=>{i.value=new Date(new Date().getTime())},clearDate:()=>{i.value=""}}}});return{render:u,...e}}(),"render-demo-3":function(){const{createElementVNode:a,resolveComponent:E,createVNode:o,openBlock:y,createElementBlock:l}=D,p={class:"picker-pro-format-demo mr30"},F=a("div",{class:"mb10"},"\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD",-1),g={class:"picker-pro-format-demo"},c=a("div",{class:"mb10"},"\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD HH:mm:ss",-1);function r(u,k){const d=E("n-date-picker-pro");return y(),l("div",null,[a("div",p,[F,o(d,{modelValue:u.pickerProFormatValue,"onUpdate:modelValue":k[0]||(k[0]=e=>u.pickerProFormatValue=e),class:"mb20 wh250",format:"YYYY-MM-DD"},null,8,["modelValue"])]),a("div",g,[c,o(d,{modelValue:u.pickerProFormatValue1,"onUpdate:modelValue":k[1]||(k[1]=e=>u.pickerProFormatValue1=e),class:"mb20 wh250",showTime:!0,format:"YYYY-MM-DD HH:mm:ss"},null,8,["modelValue"])])])}const{defineComponent:v,ref:f}=D,m=v({setup(){const u=f(""),k=f("");return{pickerProFormatValue:u,pickerProFormatValue1:k}}});return{render:r,...m}}(),"render-demo-4":function(){const{createElementVNode:a,resolveComponent:E,createVNode:o,openBlock:y,createElementBlock:l}=D,p={class:"picker-pro-format-demo mr30"},F=a("div",{class:"mb10"},"year picker",-1),g=a("div",{class:"mb10"},"month picker",-1);function c(m,u){const k=E("n-date-picker-pro");return y(),l("div",null,[a("div",p,[F,o(k,{modelValue:m.pickerProFormatValue,"onUpdate:modelValue":u[0]||(u[0]=d=>m.pickerProFormatValue=d),class:"mb20 wh250",type:"year"},null,8,["modelValue"]),g,o(k,{modelValue:m.pickerProFormatValue1,"onUpdate:modelValue":u[1]||(u[1]=d=>m.pickerProFormatValue1=d),class:"mb20 wh250",type:"month"},null,8,["modelValue"])])])}const{defineComponent:r,ref:v}=D,f=r({setup(){const m=v(""),u=v("");return{pickerProFormatValue:m,pickerProFormatValue1:u}}});return{render:c,...f}}(),"render-demo-5":function(){const{createElementVNode:a,resolveComponent:E,createVNode:o,openBlock:y,createElementBlock:l}=D,p=a("div",{class:"mb10"},"basic range picker",-1),F=a("div",{class:"mb10"},"time range picker",-1),g=a("div",{class:"mb10"},"year range picker",-1),c=a("div",{class:"mb10"},"month range picker",-1);function r(u,k){const d=E("n-range-date-picker-pro");return y(),l("div",null,[p,o(d,{modelValue:u.rangeDatePickerProValue,"onUpdate:modelValue":k[0]||(k[0]=e=>u.rangeDatePickerProValue=e),class:"mb20"},null,8,["modelValue"]),F,o(d,{modelValue:u.rangeDatePickerProValue1,"onUpdate:modelValue":k[1]||(k[1]=e=>u.rangeDatePickerProValue1=e),class:"mb20",showTime:!0,format:"YYYY/MM/DD HH:mm:ss"},null,8,["modelValue"]),g,o(d,{modelValue:u.rangeDatePickerProValue2,"onUpdate:modelValue":k[2]||(k[2]=e=>u.rangeDatePickerProValue2=e),class:"mb20 wh250",type:"year"},null,8,["modelValue"]),c,o(d,{modelValue:u.rangeDatePickerProValue3,"onUpdate:modelValue":k[3]||(k[3]=e=>u.rangeDatePickerProValue3=e),class:"mb20 wh250",type:"month"},null,8,["modelValue"])])}const{defineComponent:v,ref:f}=D,m=v({setup(){const u=f(["",""]),k=f(["",""]),d=f(["",""]),e=f(["",""]);return{rangeDatePickerProValue:u,rangeDatePickerProValue1:k,rangeDatePickerProValue2:d,rangeDatePickerProValue3:e}}});return{render:r,...m}}(),"render-demo-6":function(){const{createElementVNode:a,renderSlot:E,createTextVNode:o,resolveComponent:y,withCtx:l,createVNode:p,openBlock:F,createElementBlock:g}=D,c=a("div",{class:"mb10"},"right area",-1),r={class:"date-picker-right-panel"},v=a("div",{class:"mb10"},"footer",-1),f={class:"date-picker-footer"};function m(e,s){const i=y("n-button"),C=y("n-range-date-picker-pro");return F(),g("div",null,[c,p(C,{modelValue:e.datePickerProValue1,"onUpdate:modelValue":s[3]||(s[3]=V=>e.datePickerProValue1=V),class:"mb20 wh250",showTime:!0},{rightArea:l(()=>[E(e.$slots,"rightArea",{},()=>[a("ul",r,[a("li",null,[p(i,{variant:"text",color:"primary",onClick:s[0]||(s[0]=()=>{e.setDate(-30)})},{default:l(()=>[o(" \u4E00\u4E2A\u6708\u524D ")]),_:1})]),a("li",null,[p(i,{variant:"text",color:"primary",onClick:s[1]||(s[1]=()=>{e.setDate(-14)})},{default:l(()=>[o(" \u4E00\u5468\u524D ")]),_:1})]),a("li",null,[p(i,{variant:"text",color:"primary",onClick:s[2]||(s[2]=()=>{e.selectThisWeek()})},{default:l(()=>[o(" \u5F53\u524D\u5468 ")]),_:1})])])])]),_:3},8,["modelValue"]),v,p(C,{ref:"footerCustom",modelValue:e.datePickerProValue2,"onUpdate:modelValue":s[4]||(s[4]=V=>e.datePickerProValue2=V),class:"mb20 wh250",showTime:!0},{footer:l(()=>[E(e.$slots,"footer",{},()=>[a("div",f,[p(i,{variant:"solid",color:"secondary",onClick:e.clearStartDate},{default:l(()=>[o(" \u6E05\u9664\u5F00\u59CB\u65F6\u95F4 ")]),_:1},8,["onClick"]),p(i,{variant:"solid",color:"secondary",onClick:e.clearEndDate},{default:l(()=>[o(" \u6E05\u9664\u7ED3\u675F\u65F6\u95F4 ")]),_:1},8,["onClick"])])])]),_:3},8,["modelValue"])])}const{defineComponent:u,ref:k}=D,d=u({setup(){const e=k(["",""]),s=k(["",""]),i=B=>{e.value=[new Date(new Date().getTime()+B*24*3600*1e3),new Date]},C=()=>{const B=new Date,x=new Date(new Date().setDate(B.getDate()-B.getDay())),q=new Date(new Date().setDate(x.getDate()+6));e.value=[x,q]},V=k();return{datePickerProValue1:e,datePickerProValue2:s,setDate:i,selectThisWeek:C,footerCustom:V,clearStartDate:()=>{const[B,x]=s.value;s.value=["",x],V==null||V.value.focusChange("start")},clearEndDate:()=>{const[B,x]=s.value;s.value=[B,""],V==null||V.value.focusChange("end")}}}});return{render:m,...d}}(),"render-demo-7":function(){const{resolveComponent:a,createVNode:E,openBlock:o,createElementBlock:y}=D;function l(c,r){const v=a("n-date-picker-pro"),f=a("n-range-date-picker-pro");return o(),y("div",null,[E(v,{modelValue:c.datePickerProValue1,"onUpdate:modelValue":r[0]||(r[0]=m=>c.datePickerProValue1=m),class:"mb20 wh250 mr30",disabled:!0},null,8,["modelValue"]),E(f,{modelValue:c.datePickerProValue2,"onUpdate:modelValue":r[1]||(r[1]=m=>c.datePickerProValue2=m),class:"mb20 wh250",disabled:!0},null,8,["modelValue"])])}const{defineComponent:p,ref:F}=D,g=p({setup(){const c=F(""),r=F(["",""]);return{datePickerProValue1:c,datePickerProValue2:r}}});return{render:l,...g}}(),"render-demo-8":function(){const{resolveComponent:a,createVNode:E,openBlock:o,createElementBlock:y}=D;function l(c,r){const v=a("n-date-picker-pro"),f=a("n-range-date-picker-pro");return o(),y("div",null,[E(v,{modelValue:c.datePickerProValue1,"onUpdate:modelValue":r[0]||(r[0]=m=>c.datePickerProValue1=m),class:"mb20 wh250 mr30",calendarRange:[2022,2025],limitDateRange:c.limitDateRange},null,8,["modelValue","limitDateRange"]),E(f,{modelValue:c.datePickerProValue2,"onUpdate:modelValue":r[1]||(r[1]=m=>c.datePickerProValue2=m),class:"mb20 wh250",calendarRange:[2022,2025],limitDateRange:c.limitDateRange},null,8,["modelValue","limitDateRange"])])}const{defineComponent:p,ref:F}=D,g=p({setup(){const c=F(""),r=F(["",""]),v=F([new Date(2022,1,5),new Date(2023,1,5)]);return{datePickerProValue1:c,datePickerProValue2:r,limitDateRange:v}}});return{render:l,...g}}()}},kt='{"title":"DatePickerPro \u65E5\u671F\u9009\u62E9\u5668","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u663E\u793A\u65F6\u95F4","slug":"\u663E\u793A\u65F6\u95F4"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF","slug":"\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF"},{"level":3,"title":"\u65E5\u671F\u683C\u5F0F","slug":"\u65E5\u671F\u683C\u5F0F"},{"level":3,"title":"\u5E74\u6708\u9009\u62E9\u5668","slug":"\u5E74\u6708\u9009\u62E9\u5668"},{"level":3,"title":"\u8303\u56F4\u9009\u62E9\u5668","slug":"\u8303\u56F4\u9009\u62E9\u5668"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF","slug":"\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF"},{"level":3,"title":"\u7981\u7528\u9009\u62E9\u5668","slug":"\u7981\u7528\u9009\u62E9\u5668"},{"level":3,"title":"\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4","slug":"\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4"},{"level":3,"title":"DatePickerPro \u53C2\u6570","slug":"datepickerpro-\u53C2\u6570"},{"level":3,"title":"DatePickerPro \u4E8B\u4EF6","slug":"datepickerpro-\u4E8B\u4EF6"},{"level":3,"title":"DatePickerPro \u63D2\u69FD","slug":"datepickerpro-\u63D2\u69FD"},{"level":3,"title":"DatePickerPro \u7C7B\u578B\u5B9A\u4E49","slug":"datepickerpro-\u7C7B\u578B\u5B9A\u4E49"},{"level":3,"title":"RangeDatePickerPro \u53C2\u6570","slug":"rangedatepickerpro-\u53C2\u6570"},{"level":3,"title":"RangeDatePickerPro \u4E8B\u4EF6","slug":"rangedatepickerpro-\u4E8B\u4EF6"},{"level":3,"title":"RangeDatePickerPro \u63D2\u69FD","slug":"rangedatepickerpro-\u63D2\u69FD"}],"relativePath":"components/date-picker-pro/index.md","lastUpdated":1672994787088}',N=A('<h1 id="datepickerpro-\u65E5\u671F\u9009\u62E9\u5668" tabindex="-1">DatePickerPro \u65E5\u671F\u9009\u62E9\u5668 <a class="header-anchor" href="#datepickerpro-\u65E5\u671F\u9009\u62E9\u5668" aria-hidden="true">#</a></h1><p>\u8F93\u5165\u6216\u9009\u62E9\u65E5\u671F\u7684\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u7528\u6237\u9700\u8981\u8F93\u5165\u4E00\u4E2A\u65E5\u671F\u65F6\uFF1B\u9700\u8981\u70B9\u51FB\u6807\u51C6\u8F93\u5165\u6846\uFF0C\u5F39\u51FA\u65E5\u671F\u9762\u677F\u8FDB\u884C\u9009\u62E9\u65F6\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),S=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo mr30"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Small"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"size"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("sm"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo mr30"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Middle"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo mr30"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("Large"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"size"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("lg"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue3 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue3`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},".mb20"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"margin-bottom"),t("span",{class:"token punctuation"},":"),n(" 20px"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`

`),t("span",{class:"token selector"},".wh250"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 250px"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),H=t("h3",{id:"\u663E\u793A\u65F6\u95F4",tabindex:"-1"},[n("\u663E\u793A\u65F6\u95F4 "),t("a",{class:"header-anchor",href:"#\u663E\u793A\u65F6\u95F4","aria-hidden":"true"},"#")],-1),U=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"format"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("YYYY/MM/DD HH:mm:ss"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),$=t("h3",{id:"\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF",tabindex:"-1"},[n("\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF "),t("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF","aria-hidden":"true"},"#")],-1),j=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("right area"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#rightArea"),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("slot")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rightArea"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("ul")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("date-picker-right-panel"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(-30);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4E00\u4E2A\u6708\u524D
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),t("span",{class:"token punctuation"},">")]),n("{{ getDateString(-30) }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(-14);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4E24\u5468\u524D
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),t("span",{class:"token punctuation"},">")]),n("{{ getDateString(-14) }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(-7);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4E00\u5468\u524D
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),t("span",{class:"token punctuation"},">")]),n("{{ getDateString(-7) }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(0);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4ECA\u5929
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("span")]),t("span",{class:"token punctuation"},">")]),n("{{ getDateString(0) }}"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("span")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("ul")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("slot")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-date-picker-pro")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("footer"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#footer"),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("slot")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("footer"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("date-picker-footer"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("solid"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("secondary"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("setToday"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(" \u4ECA\u5929 "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("solid"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("secondary"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("clearDate"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(" \u6E05\u9664\u65F6\u95F4 "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("slot")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-date-picker-pro")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string "),t("span",{class:"token operator"},"|"),n(" Date"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string "),t("span",{class:"token operator"},"|"),n(" Date"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"setDate"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[t("span",{class:"token literal-property property"},"days"),t("span",{class:"token operator"},":"),n(" number")]),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getTime"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"+"),n(" days "),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"24"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"3600"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"1000"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"getDateString"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[t("span",{class:"token literal-property property"},"days"),t("span",{class:"token operator"},":"),n(" number")]),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token keyword"},"const"),n(" date "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getTime"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"+"),n(" days "),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"24"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"3600"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"1000"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
      `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token template-string"},[t("span",{class:"token template-punctuation string"},"`"),t("span",{class:"token interpolation"},[t("span",{class:"token interpolation-punctuation punctuation"},"${"),n("date"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getMonth"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"+"),n(),t("span",{class:"token number"},"1"),t("span",{class:"token interpolation-punctuation punctuation"},"}")]),t("span",{class:"token string"},"\u6708"),t("span",{class:"token interpolation"},[t("span",{class:"token interpolation-punctuation punctuation"},"${"),n("date"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getDate"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token interpolation-punctuation punctuation"},"}")]),t("span",{class:"token string"},"\u65E5"),t("span",{class:"token template-punctuation string"},"`")]),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"setToday"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getTime"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"clearDate"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
      setDate`),t("span",{class:"token punctuation"},","),n(`
      getDateString`),t("span",{class:"token punctuation"},","),n(`
      setToday`),t("span",{class:"token punctuation"},","),n(`
      clearDate`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},".date-picker-right-panel"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"padding"),t("span",{class:"token punctuation"},":"),n(" 0"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token selector"},"li"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token property"},"list-style-type"),t("span",{class:"token punctuation"},":"),n(" none"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token selector"},"button"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 66px"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),n(`
    `),t("span",{class:"token selector"},"span"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token property"},"margin-left"),t("span",{class:"token punctuation"},":"),n(" 8px"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),n(`
  `),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token selector"},".date-picker-footer"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" flex"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"justify-content"),t("span",{class:"token punctuation"},":"),n(" end"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token selector"},"button"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token property"},"margin-left"),t("span",{class:"token punctuation"},":"),n(" 10px"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),z=t("h3",{id:"\u65E5\u671F\u683C\u5F0F",tabindex:"-1"},[n("\u65E5\u671F\u683C\u5F0F "),t("a",{class:"header-anchor",href:"#\u65E5\u671F\u683C\u5F0F","aria-hidden":"true"},"#")],-1),W=t("p",null,[n("\u901A\u8FC7"),t("code",null,"format"),n("\u6307\u5B9A\u8F93\u5165\u6846\u663E\u793A\u7684\u65E5\u671F\u683C\u5F0F, \u8BE6\u89C1 "),t("a",{href:"#format"},"Format")],-1),L=t("p",null,[n("\u4F8B\u5982\uFF1A"),t("code",null,"YYYY-MM-DD")],-1),G=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo mr30"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("pickerProFormatValue"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"format"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("YYYY-MM-DD"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD HH:mm:ss"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("pickerProFormatValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"format"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("YYYY-MM-DD HH:mm:ss"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" pickerProFormatValue "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" pickerProFormatValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      pickerProFormatValue`),t("span",{class:"token punctuation"},","),n(`
      pickerProFormatValue1`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},".picker-pro-format-demo"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"display"),t("span",{class:"token punctuation"},":"),n(" inline-block"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token selector"},".mr30"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"margin-right"),t("span",{class:"token punctuation"},":"),n(" 20px"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`),t("span",{class:"token selector"},".mb10"),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"margin-bottom"),t("span",{class:"token punctuation"},":"),n(" 10px"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),I=t("h3",{id:"\u5E74\u6708\u9009\u62E9\u5668",tabindex:"-1"},[n("\u5E74\u6708\u9009\u62E9\u5668 "),t("a",{class:"header-anchor",href:"#\u5E74\u6708\u9009\u62E9\u5668","aria-hidden":"true"},"#")],-1),J=t("p",null,[n("\u901A\u8FC7"),t("code",null,"type"),n("\u6307\u5B9A\u9009\u62E9\u5668\u7C7B\u578B")],-1),K=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("picker-pro-format-demo mr30"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("year picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("pickerProFormatValue"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("year"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("month picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("pickerProFormatValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("month"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" pickerProFormatValue "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" pickerProFormatValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      pickerProFormatValue`),t("span",{class:"token punctuation"},","),n(`
      pickerProFormatValue1`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),O=t("h3",{id:"\u8303\u56F4\u9009\u62E9\u5668",tabindex:"-1"},[n("\u8303\u56F4\u9009\u62E9\u5668 "),t("a",{class:"header-anchor",href:"#\u8303\u56F4\u9009\u62E9\u5668","aria-hidden":"true"},"#")],-1),Q=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("basic range picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rangeDatePickerProValue"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("time range picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rangeDatePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"format"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("YYYY/MM/DD HH:mm:ss"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("year range picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rangeDatePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("year"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("month range picker"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rangeDatePickerProValue3"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"type"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("month"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" rangeDatePickerProValue "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" rangeDatePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" rangeDatePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" rangeDatePickerProValue3 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      rangeDatePickerProValue`),t("span",{class:"token punctuation"},","),n(`
      rangeDatePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
      rangeDatePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
      rangeDatePickerProValue3`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),X=t("h3",{id:"\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF",tabindex:"-1"},[n("\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF "),t("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF","aria-hidden":"true"},"#")],-1),Z=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("right area"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#rightArea"),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("slot")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("rightArea"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("ul")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("date-picker-right-panel"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(-30);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4E00\u4E2A\u6708\u524D
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  setDate(-14);
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u4E00\u5468\u524D
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(`
              `),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("text"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("primary"),t("span",{class:"token punctuation"},'"')]),n(`
              `),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n(`
                () => {
                  selectThisWeek();
                }
              `),t("span",{class:"token punctuation"},'"')]),n(`
            `),t("span",{class:"token punctuation"},">")]),n(`
              \u5F53\u524D\u5468
            `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("li")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("ul")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("slot")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-range-date-picker-pro")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb10"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n("footer"),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"ref"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("footerCustom"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":showTime"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),n(),t("span",{class:"token attr-name"},"#footer"),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("slot")]),n(),t("span",{class:"token attr-name"},"name"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("footer"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("date-picker-footer"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("solid"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("secondary"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("clearStartDate"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(" \u6E05\u9664\u5F00\u59CB\u65F6\u95F4 "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
          `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-button")]),n(),t("span",{class:"token attr-name"},"variant"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("solid"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"color"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("secondary"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@click"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("clearEndDate"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(" \u6E05\u9664\u7ED3\u675F\u65F6\u95F4 "),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-button")]),t("span",{class:"token punctuation"},">")]),n(`
        `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("div")]),t("span",{class:"token punctuation"},">")]),n(`
      `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("slot")]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-range-date-picker-pro")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string "),t("span",{class:"token operator"},"|"),n(" Date"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string "),t("span",{class:"token operator"},"|"),n(" Date"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"setDate"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},[t("span",{class:"token literal-property property"},"days"),t("span",{class:"token operator"},":"),n(" number")]),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"["),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getTime"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"+"),n(" days "),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"24"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"3600"),n(),t("span",{class:"token operator"},"*"),n(),t("span",{class:"token number"},"1000"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"selectThisWeek"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token keyword"},"const"),n(" tody "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
      `),t("span",{class:"token keyword"},"const"),n(" start "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"setDate"),t("span",{class:"token punctuation"},"("),n("tody"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getDate"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"-"),n(" tody"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getDay"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
      `),t("span",{class:"token keyword"},"const"),n(" end "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"setDate"),t("span",{class:"token punctuation"},"("),n("start"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"getDate"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"+"),n(),t("span",{class:"token number"},"6"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"["),n("start"),t("span",{class:"token punctuation"},","),n(" end"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"const"),n(" footerCustom "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"clearStartDate"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token punctuation"},"["),n("start"),t("span",{class:"token punctuation"},","),n(" end"),t("span",{class:"token punctuation"},"]"),n(),t("span",{class:"token operator"},"="),n(" datePickerProValue2"),t("span",{class:"token punctuation"},"."),n("value"),t("span",{class:"token punctuation"},";"),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(" end"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),n(`
      footerCustom`),t("span",{class:"token operator"},"?."),n("value"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"focusChange"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'start'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"clearEndDate"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token punctuation"},"["),n("start"),t("span",{class:"token punctuation"},","),n(" end"),t("span",{class:"token punctuation"},"]"),n(),t("span",{class:"token operator"},"="),n(" datePickerProValue2"),t("span",{class:"token punctuation"},"."),n("value"),t("span",{class:"token punctuation"},";"),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},"."),n("value "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"["),n("start"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},";"),n(`
      footerCustom`),t("span",{class:"token operator"},"?."),n("value"),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"focusChange"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'end'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
      setDate`),t("span",{class:"token punctuation"},","),n(`
      selectThisWeek`),t("span",{class:"token punctuation"},","),n(`
      footerCustom`),t("span",{class:"token punctuation"},","),n(`
      clearStartDate`),t("span",{class:"token punctuation"},","),n(`
      clearEndDate`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),tt=t("h3",{id:"\u7981\u7528\u9009\u62E9\u5668",tabindex:"-1"},[n("\u7981\u7528\u9009\u62E9\u5668 "),t("a",{class:"header-anchor",href:"#\u7981\u7528\u9009\u62E9\u5668","aria-hidden":"true"},"#")],-1),nt=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250 mr30"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":disabled"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":disabled"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("true"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),at=t("h3",{id:"\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4",tabindex:"-1"},[n("\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4 "),t("a",{class:"header-anchor",href:"#\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4","aria-hidden":"true"},"#")],-1),st=t("p",null,[n("\u6DFB\u52A0 "),t("code",null,"calendarRange"),n(" \u5C5E\u6027\u8BBE\u7F6E\u9009\u62E9\u5668\u65E5\u5386\u9762\u677F\u663E\u793A\u7684\u65F6\u95F4\u8303\u56F4\u3002 \u6DFB\u52A0 "),t("code",null,"limitDateRange"),n(" \u5C5E\u6027\u8BBE\u7F6E\u9009\u62E9\u5668\u65E5\u5386\u9762\u677F\u53EF\u9009\u62E9\u7684\u65F6\u95F4\u8303\u56F4\u3002")],-1),et=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-date-picker-pro")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue1"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250 mr30"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":calendarRange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("[2022, 2025]"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":limitDateRange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("limitDateRange"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-range-date-picker-pro")]),n(`
    `),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("datePickerProValue2"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("mb20 wh250"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":calendarRange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("[2022, 2025]"),t("span",{class:"token punctuation"},'"')]),n(`
    `),t("span",{class:"token attr-name"},":limitDateRange"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("limitDateRange"),t("span",{class:"token punctuation"},'"')]),n(`
  `),t("span",{class:"token punctuation"},"/>")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("ts"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue1 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" datePickerProValue2 "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("string"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token string"},"''"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" limitDateRange "),t("span",{class:"token operator"},"="),n(" ref"),t("span",{class:"token operator"},"<"),n("Date"),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"]"),t("span",{class:"token operator"},">"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token number"},"2022"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token keyword"},"new"),n(),t("span",{class:"token class-name"},"Date"),t("span",{class:"token punctuation"},"("),t("span",{class:"token number"},"2023"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token number"},"5"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      datePickerProValue1`),t("span",{class:"token punctuation"},","),n(`
      datePickerProValue2`),t("span",{class:"token punctuation"},","),n(`
      limitDateRange`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),ot=A(`<h3 id="datepickerpro-\u53C2\u6570" tabindex="-1">DatePickerPro \u53C2\u6570 <a class="header-anchor" href="#datepickerpro-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>Date</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u9009\u4E2D\u9879\u7ED1\u5B9A\u7684\u503C</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">format</td><td style="text-align:left;"><a href="#format">Format</a></td><td style="text-align:left;">&#39;YYYY/MM/DD&#39; | &#39;YYYY/MM/DD HH:mm:ss&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7ED1\u5B9A\u503C\u7684\u65E5\u671F\u683C\u5F0F\uFF0C\u6839\u636E\u662F\u5426 showTime \u533A\u522B\u4E0D\u540C\u9ED8\u8BA4\u503C</td><td style="text-align:left;"><a href="#%E6%97%A5%E6%9C%9F%E6%A0%BC%E5%BC%8F">\u65E5\u671F\u683C\u5F0F</a></td></tr><tr><td style="text-align:left;">placeholder</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;\u8BF7\u9009\u62E9\u65E5\u671F&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u7684 placeholder</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">showTime</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u65F6\u5206\u79D2</td><td style="text-align:left;"><a href="#%E6%98%BE%E7%A4%BA%E6%97%B6%E9%97%B4">\u663E\u793A\u65F6\u95F4</a></td></tr><tr><td style="text-align:left;">size</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;md&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u7684\u5C3A\u5BF8</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">disabled</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u7981\u7528\u9009\u62E9\u5668</td><td style="text-align:left;"><a href="#%E7%A6%81%E7%94%A8%E9%80%89%E6%8B%A9%E5%99%A8">\u7981\u7528\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">calendarRange</td><td style="text-align:left;"><code>[number,number]</code></td><td style="text-align:left;">[1970, 2099]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u663E\u793A\u65F6\u95F4\u8303\u56F4</td><td style="text-align:left;"><a href="#%E8%AE%BE%E7%BD%AE%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8F%AF%E9%80%89%E6%97%B6%E9%97%B4%E8%8C%83%E5%9B%B4">\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</a></td></tr><tr><td style="text-align:left;">limitDateRange</td><td style="text-align:left;"><code>[Date,Date]</code></td><td style="text-align:left;">[new Date(calendarRange[0]), new Date(calendarRange[1])]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</td><td style="text-align:left;"><a href="#%E8%AE%BE%E7%BD%AE%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8F%AF%E9%80%89%E6%97%B6%E9%97%B4%E8%8C%83%E5%9B%B4">\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</a></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;date&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u671F\u9009\u62E9\u5668\u7C7B\u578B(date/year/month)</td><td style="text-align:left;"><a href="#%E5%B9%B4%E6%9C%88%E9%80%89%E6%8B%A9%E5%99%A8">\u5E74\u6708\u9009\u62E9\u5668</a></td></tr></tbody></table><h3 id="datepickerpro-\u4E8B\u4EF6" tabindex="-1">DatePickerPro \u4E8B\u4EF6 <a class="header-anchor" href="#datepickerpro-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">toggleChange</td><td style="text-align:left;"><code>(bool: boolean) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u9009\u62E9\u5668\u6253\u5F00\u5173\u95ED toggle \u4E8B\u4EF6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">confirmEvent</td><td style="text-align:left;"><code>(date: Date) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7528\u6237\u786E\u5B9A\u9009\u5B9A\u7684\u503C\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">focus</td><td style="text-align:left;"><code>(e: MouseEvent) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u83B7\u53D6\u7126\u70B9\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">blur</td><td style="text-align:left;"><code>() =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u5931\u53BB\u7126\u70B9\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="datepickerpro-\u63D2\u69FD" tabindex="-1">DatePickerPro \u63D2\u69FD <a class="header-anchor" href="#datepickerpro-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u540D\u79F0</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">rightArea</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 DatePickerPro \u65E5\u5386\u9762\u677F\u53F3\u4FA7\u5185\u5BB9\uFF0C \u5982\uFF1A\u65E5\u671F\u5FEB\u6377\u9009\u9879</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8C%BA%E5%9F%9F">\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF</a></td></tr><tr><td style="text-align:left;">footer</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 DatePickerPro \u65E5\u5386\u9762\u677F\u4E0B\u4FA7\u5185\u5BB9</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8C%BA%E5%9F%9F">\u81EA\u5B9A\u4E49\u65E5\u5386\u9762\u677F\u533A\u57DF</a></td></tr></tbody></table><h3 id="datepickerpro-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">DatePickerPro \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#datepickerpro-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="format" tabindex="-1">Format <a class="header-anchor" href="#format" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">Format</span> <span class="token operator">=</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
</code></pre></div><p>\u65E5\u671F\u683C\u5F0F <code>format</code> \u652F\u6301\u7684\u6807\u8BC6\u5217\u8868</p><table><thead><tr><th style="text-align:left;">\u6807\u8BC6</th><th style="text-align:left;">\u793A\u4F8B</th><th style="text-align:left;">\u63CF\u8FF0</th></tr></thead><tbody><tr><td style="text-align:left;">YY</td><td style="text-align:left;">22</td><td style="text-align:left;">\u5E74\uFF0C\u4E24\u4F4D\u6570</td></tr><tr><td style="text-align:left;">YYYY</td><td style="text-align:left;">2022</td><td style="text-align:left;">\u5E74\uFF0C\u56DB\u4F4D\u6570</td></tr><tr><td style="text-align:left;">M</td><td style="text-align:left;">1-12</td><td style="text-align:left;">\u6708\uFF0C\u4ECE 1 \u5F00\u59CB</td></tr><tr><td style="text-align:left;">MM</td><td style="text-align:left;">01-12</td><td style="text-align:left;">\u6708\uFF0C\u4E24\u4F4D\u6570\u5B57</td></tr><tr><td style="text-align:left;">MMM</td><td style="text-align:left;">Jan-Dec</td><td style="text-align:left;">\u6708\uFF0C\u82F1\u6587\u7F29\u5199</td></tr><tr><td style="text-align:left;">D</td><td style="text-align:left;">1-31</td><td style="text-align:left;">\u65E5</td></tr><tr><td style="text-align:left;">DD</td><td style="text-align:left;">01-31</td><td style="text-align:left;">\u65E5\uFF0C\u4E24\u4F4D\u6570</td></tr><tr><td style="text-align:left;">H</td><td style="text-align:left;">0-23</td><td style="text-align:left;">24 \u5C0F\u65F6</td></tr><tr><td style="text-align:left;">HH</td><td style="text-align:left;">00-23</td><td style="text-align:left;">24 \u5C0F\u65F6\uFF0C\u4E24\u4F4D\u6570</td></tr><tr><td style="text-align:left;">h</td><td style="text-align:left;">1-12</td><td style="text-align:left;">12 \u5C0F\u65F6</td></tr><tr><td style="text-align:left;">hh</td><td style="text-align:left;">01-12</td><td style="text-align:left;">12 \u5C0F\u65F6\uFF0C\u4E24\u4F4D\u6570</td></tr><tr><td style="text-align:left;">m</td><td style="text-align:left;">0-59</td><td style="text-align:left;">\u5206\u949F</td></tr><tr><td style="text-align:left;">mm</td><td style="text-align:left;">00-59</td><td style="text-align:left;">\u5206\u949F\uFF0C\u4E24\u4F4D\u6570</td></tr><tr><td style="text-align:left;">s</td><td style="text-align:left;">0-59</td><td style="text-align:left;">\u79D2</td></tr><tr><td style="text-align:left;">ss</td><td style="text-align:left;">00-59</td><td style="text-align:left;">\u79D2\uFF0C\u4E24\u4F4D\u6570</td></tr></tbody></table><h3 id="rangedatepickerpro-\u53C2\u6570" tabindex="-1">RangeDatePickerPro \u53C2\u6570 <a class="header-anchor" href="#rangedatepickerpro-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>[Date, Date]</code></td><td style="text-align:left;">[&#39;&#39;,&#39;&#39;]</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u9009\u4E2D\u9879\u7ED1\u5B9A\u7684\u503C</td><td style="text-align:left;"><a href="#%E8%8C%83%E5%9B%B4%E9%80%89%E6%8B%A9%E5%99%A8">\u8303\u56F4\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">format</td><td style="text-align:left;"><a href="#format">Format</a></td><td style="text-align:left;">&#39;YYYY/MM/DD&#39; | &#39;YYYY/MM/DD HH:mm:ss&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7ED1\u5B9A\u503C\u7684\u65E5\u671F\u683C\u5F0F\uFF0C\u6839\u636E\u662F\u5426 showTime \u533A\u522B\u4E0D\u540C\u9ED8\u8BA4\u503C</td><td style="text-align:left;"><a href="#%E6%97%A5%E6%9C%9F%E6%A0%BC%E5%BC%8F">\u65E5\u671F\u683C\u5F0F</a></td></tr><tr><td style="text-align:left;">placeholder</td><td style="text-align:left;"><code>Array</code></td><td style="text-align:left;">[&#39;\u8BF7\u9009\u62E9\u5F00\u59CB\u65E5\u671F&#39;, &#39;\u8BF7\u9009\u62E9\u7ED3\u675F\u65E5\u671F&#39;]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u7684 placeholder</td><td style="text-align:left;"><a href="#%E8%8C%83%E5%9B%B4%E9%80%89%E6%8B%A9%E5%99%A8">\u8303\u56F4\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">showTime</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u65F6\u5206\u79D2</td><td style="text-align:left;"><a href="#%E8%8C%83%E5%9B%B4%E9%80%89%E6%8B%A9%E5%99%A8">\u8303\u56F4\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">separator</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;-&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8303\u56F4\u9009\u62E9\u5668\u7684\u5206\u5272\u7B26</td><td style="text-align:left;"><a href="#%E8%8C%83%E5%9B%B4%E9%80%89%E6%8B%A9%E5%99%A8">\u8303\u56F4\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">size</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;md&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u7684\u5C3A\u5BF8</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">disabled</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u7981\u7528\u9009\u62E9\u5668</td><td style="text-align:left;"><a href="#%E7%A6%81%E7%94%A8%E9%80%89%E6%8B%A9%E5%99%A8">\u7981\u7528\u9009\u62E9\u5668</a></td></tr><tr><td style="text-align:left;">calendarRange</td><td style="text-align:left;"><code>[number,number]</code></td><td style="text-align:left;">[1970,2099]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u663E\u793A\u65F6\u95F4\u8303\u56F4</td><td style="text-align:left;"><a href="#%E8%AE%BE%E7%BD%AE%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8F%AF%E9%80%89%E6%97%B6%E9%97%B4%E8%8C%83%E5%9B%B4">\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</a></td></tr><tr><td style="text-align:left;">limitDateRange</td><td style="text-align:left;"><code>[Date,Date]</code></td><td style="text-align:left;">[new Date(calendarRange[0]), new Date(calendarRange[1])]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</td><td style="text-align:left;"><a href="#%E8%AE%BE%E7%BD%AE%E6%97%A5%E5%8E%86%E9%9D%A2%E6%9D%BF%E5%8F%AF%E9%80%89%E6%97%B6%E9%97%B4%E8%8C%83%E5%9B%B4">\u8BBE\u7F6E\u65E5\u5386\u9762\u677F\u53EF\u9009\u65F6\u95F4\u8303\u56F4</a></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;date&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u65E5\u671F\u9009\u62E9\u5668\u7C7B\u578B(date/year/month)</td><td style="text-align:left;"><a href="#%E8%8C%83%E5%9B%B4%E9%80%89%E6%8B%A9%E5%99%A8">\u8303\u56F4\u9009\u62E9\u5668</a></td></tr></tbody></table><h3 id="rangedatepickerpro-\u4E8B\u4EF6" tabindex="-1">RangeDatePickerPro \u4E8B\u4EF6 <a class="header-anchor" href="#rangedatepickerpro-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">toggleChange</td><td style="text-align:left;"><code>(bool: boolean) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u9009\u62E9\u5668\u6253\u5F00\u5173\u95ED toggle \u4E8B\u4EF6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">confirmEvent</td><td style="text-align:left;"><code>(date: Date[]) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u7528\u6237\u786E\u5B9A\u9009\u5B9A\u7684\u65F6\u95F4\u8303\u56F4\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">focus</td><td style="text-align:left;"><code>(e: MouseEvent) =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u83B7\u53D6\u7126\u70B9\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">blur</td><td style="text-align:left;"><code>() =&gt; void</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8F93\u5165\u6846\u5931\u53BB\u7126\u70B9\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="rangedatepickerpro-\u63D2\u69FD" tabindex="-1">RangeDatePickerPro \u63D2\u69FD <a class="header-anchor" href="#rangedatepickerpro-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u540D\u79F0</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">rightArea</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 RangeDatePickerPro \u65E5\u5386\u9762\u677F\u53F3\u4FA7\u5185\u5BB9\uFF0C \u5982\uFF1A\u65E5\u671F\u8303\u56F4\u5FEB\u6377\u9009\u9879</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E6%9C%9F%E8%8C%83%E5%9B%B4%E9%9D%A2%E6%9D%BF%E5%8C%BA%E5%9F%9F">\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF</a></td></tr><tr><td style="text-align:left;">footer</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 RangeDatePickerPro \u65E5\u5386\u9762\u677F\u4E0B\u4FA7\u5185\u5BB9</td><td style="text-align:left;"><a href="#%E8%87%AA%E5%AE%9A%E4%B9%89%E6%97%A5%E6%9C%9F%E8%8C%83%E5%9B%B4%E9%9D%A2%E6%9D%BF%E5%8C%BA%E5%9F%9F">\u81EA\u5B9A\u4E49\u65E5\u671F\u8303\u56F4\u9762\u677F\u533A\u57DF</a></td></tr></tbody></table>`,17);function ut(a,E,o,y,l,p){const F=b("render-demo-0"),g=b("demo"),c=b("render-demo-1"),r=b("render-demo-2"),v=b("render-demo-3"),f=b("render-demo-4"),m=b("render-demo-5"),u=b("render-demo-6"),k=b("render-demo-7"),d=b("render-demo-8");return M(),T("div",null,[N,P(g,{sourceCode:`<template>
  <div class="picker-pro-format-demo mr30">
    <div class="mb10">Small</div>
    <n-date-picker-pro v-model="datePickerProValue" class="mb20 wh250" size="sm" />
  </div>
  <div class="picker-pro-format-demo mr30">
    <div class="mb10">Middle</div>
    <n-date-picker-pro v-model="datePickerProValue2" class="mb20 wh250" />
  </div>
  <div class="picker-pro-format-demo mr30">
    <div class="mb10">Large</div>
    <n-date-picker-pro v-model="datePickerProValue3" class="mb20 wh250" size="lg" />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue = ref<string>('');
    const datePickerProValue2 = ref<string>('');
    const datePickerProValue3 = ref<string>('');

    return {
      datePickerProValue,
      datePickerProValue2,
      datePickerProValue3,
    };
  },
});
<\/script>

<style>
.mb20 {
  margin-bottom: 20px;
}

.wh250 {
  width: 250px;
}
</style>
`},{highlight:h(()=>[S]),default:h(()=>[P(F)]),_:1}),H,P(g,{sourceCode:`<template>
  <n-date-picker-pro v-model="datePickerProValue1" class="mb20 wh250" :showTime="true" format="YYYY/MM/DD HH:mm:ss" />
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue1 = ref<string>('');

    return {
      datePickerProValue1,
    };
  },
});
<\/script>
`},{highlight:h(()=>[U]),default:h(()=>[P(c)]),_:1}),$,P(g,{sourceCode:`<template>
  <div class="mb10">right area</div>
  <n-date-picker-pro v-model="datePickerProValue1" class="mb20 wh250" :showTime="true">
    <template #rightArea>
      <slot name="rightArea">
        <ul class="date-picker-right-panel">
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(-30);
                }
              "
            >
              \u4E00\u4E2A\u6708\u524D
            </n-button>
            <span>{{ getDateString(-30) }}</span>
          </li>
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(-14);
                }
              "
            >
              \u4E24\u5468\u524D
            </n-button>
            <span>{{ getDateString(-14) }}</span>
          </li>
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(-7);
                }
              "
            >
              \u4E00\u5468\u524D
            </n-button>
            <span>{{ getDateString(-7) }}</span>
          </li>
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(0);
                }
              "
            >
              \u4ECA\u5929
            </n-button>
            <span>{{ getDateString(0) }}</span>
          </li>
        </ul>
      </slot>
    </template>
  </n-date-picker-pro>
  <div class="mb10">footer</div>
  <n-date-picker-pro v-model="datePickerProValue2" class="mb20 wh250" :showTime="true">
    <template #footer>
      <slot name="footer">
        <div class="date-picker-footer">
          <n-button variant="solid" color="secondary" @click="setToday"> \u4ECA\u5929 </n-button>
          <n-button variant="solid" color="secondary" @click="clearDate"> \u6E05\u9664\u65F6\u95F4 </n-button>
        </div>
      </slot>
    </template>
  </n-date-picker-pro>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue1 = ref<string | Date>('');
    const datePickerProValue2 = ref<string | Date>('');
    const setDate = (days: number) => {
      datePickerProValue1.value = new Date(new Date().getTime() + days * 24 * 3600 * 1000);
    };
    const getDateString = (days: number) => {
      const date = new Date(new Date().getTime() + days * 24 * 3600 * 1000);
      return \`\${date.getMonth() + 1}\u6708\${date.getDate()}\u65E5\`;
    };
    const setToday = () => {
      datePickerProValue2.value = new Date(new Date().getTime());
    };
    const clearDate = () => {
      datePickerProValue2.value = '';
    };

    return {
      datePickerProValue1,
      datePickerProValue2,
      setDate,
      getDateString,
      setToday,
      clearDate,
    };
  },
});
<\/script>
<style>
.date-picker-right-panel {
  padding: 0;
  li {
    list-style-type: none;
    button {
      width: 66px;
    }
    span {
      margin-left: 8px;
    }
  }
}
.date-picker-footer {
  display: flex;
  justify-content: end;
  button {
    margin-left: 10px;
  }
}
</style>
`},{highlight:h(()=>[j]),default:h(()=>[P(r)]),_:1}),z,W,L,P(g,{sourceCode:`<template>
  <div class="picker-pro-format-demo mr30">
    <div class="mb10">\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD</div>
    <n-date-picker-pro v-model="pickerProFormatValue" class="mb20 wh250" format="YYYY-MM-DD" />
  </div>
  <div class="picker-pro-format-demo">
    <div class="mb10">\u65E5\u671F\u683C\u5F0F\uFF1A YYYY-MM-DD HH:mm:ss</div>
    <n-date-picker-pro v-model="pickerProFormatValue1" class="mb20 wh250" :showTime="true" format="YYYY-MM-DD HH:mm:ss" />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const pickerProFormatValue = ref<string>('');
    const pickerProFormatValue1 = ref<string>('');

    return {
      pickerProFormatValue,
      pickerProFormatValue1,
    };
  },
});
<\/script>
<style>
.picker-pro-format-demo {
  display: inline-block;
}
.mr30 {
  margin-right: 20px;
}
.mb10 {
  margin-bottom: 10px;
}
</style>
`},{highlight:h(()=>[G]),default:h(()=>[P(v)]),_:1}),I,J,P(g,{sourceCode:`<template>
  <div class="picker-pro-format-demo mr30">
    <div class="mb10">year picker</div>
    <n-date-picker-pro v-model="pickerProFormatValue" class="mb20 wh250" type="year" />
    <div class="mb10">month picker</div>
    <n-date-picker-pro v-model="pickerProFormatValue1" class="mb20 wh250" type="month" />
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const pickerProFormatValue = ref<string>('');
    const pickerProFormatValue1 = ref<string>('');
    return {
      pickerProFormatValue,
      pickerProFormatValue1,
    };
  },
});
<\/script>
`},{highlight:h(()=>[K]),default:h(()=>[P(f)]),_:1}),O,P(g,{sourceCode:`<template>
  <div class="mb10">basic range picker</div>
  <n-range-date-picker-pro v-model="rangeDatePickerProValue" class="mb20" />
  <div class="mb10">time range picker</div>
  <n-range-date-picker-pro v-model="rangeDatePickerProValue1" class="mb20" :showTime="true" format="YYYY/MM/DD HH:mm:ss" />
  <div class="mb10">year range picker</div>
  <n-range-date-picker-pro v-model="rangeDatePickerProValue2" class="mb20 wh250" type="year" />
  <div class="mb10">month range picker</div>
  <n-range-date-picker-pro v-model="rangeDatePickerProValue3" class="mb20 wh250" type="month" />
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const rangeDatePickerProValue = ref<string[]>(['', '']);
    const rangeDatePickerProValue1 = ref<string[]>(['', '']);
    const rangeDatePickerProValue2 = ref<string[]>(['', '']);
    const rangeDatePickerProValue3 = ref<string[]>(['', '']);

    return {
      rangeDatePickerProValue,
      rangeDatePickerProValue1,
      rangeDatePickerProValue2,
      rangeDatePickerProValue3,
    };
  },
});
<\/script>
`},{highlight:h(()=>[Q]),default:h(()=>[P(m)]),_:1}),X,P(g,{sourceCode:`<template>
  <div class="mb10">right area</div>
  <n-range-date-picker-pro v-model="datePickerProValue1" class="mb20 wh250" :showTime="true">
    <template #rightArea>
      <slot name="rightArea">
        <ul class="date-picker-right-panel">
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(-30);
                }
              "
            >
              \u4E00\u4E2A\u6708\u524D
            </n-button>
          </li>
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  setDate(-14);
                }
              "
            >
              \u4E00\u5468\u524D
            </n-button>
          </li>
          <li>
            <n-button
              variant="text"
              color="primary"
              @click="
                () => {
                  selectThisWeek();
                }
              "
            >
              \u5F53\u524D\u5468
            </n-button>
          </li>
        </ul>
      </slot>
    </template>
  </n-range-date-picker-pro>
  <div class="mb10">footer</div>
  <n-range-date-picker-pro ref="footerCustom" v-model="datePickerProValue2" class="mb20 wh250" :showTime="true">
    <template #footer>
      <slot name="footer">
        <div class="date-picker-footer">
          <n-button variant="solid" color="secondary" @click="clearStartDate"> \u6E05\u9664\u5F00\u59CB\u65F6\u95F4 </n-button>
          <n-button variant="solid" color="secondary" @click="clearEndDate"> \u6E05\u9664\u7ED3\u675F\u65F6\u95F4 </n-button>
        </div>
      </slot>
    </template>
  </n-range-date-picker-pro>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue1 = ref<string | Date[]>(['', '']);
    const datePickerProValue2 = ref<string | Date[]>(['', '']);
    const setDate = (days: number) => {
      datePickerProValue1.value = [new Date(new Date().getTime() + days * 24 * 3600 * 1000), new Date()];
    };
    const selectThisWeek = () => {
      const tody = new Date();
      const start = new Date(new Date().setDate(tody.getDate() - tody.getDay()));
      const end = new Date(new Date().setDate(start.getDate() + 6));
      datePickerProValue1.value = [start, end];
    };

    const footerCustom = ref();

    const clearStartDate = () => {
      const [start, end] = datePickerProValue2.value;
      datePickerProValue2.value = ['', end];
      footerCustom?.value.focusChange('start');
    };
    const clearEndDate = () => {
      const [start, end] = datePickerProValue2.value;
      datePickerProValue2.value = [start, ''];
      footerCustom?.value.focusChange('end');
    };

    return {
      datePickerProValue1,
      datePickerProValue2,
      setDate,
      selectThisWeek,
      footerCustom,
      clearStartDate,
      clearEndDate,
    };
  },
});
<\/script>
`},{highlight:h(()=>[Z]),default:h(()=>[P(u)]),_:1}),tt,P(g,{sourceCode:`<template>
  <n-date-picker-pro v-model="datePickerProValue1" class="mb20 wh250 mr30" :disabled="true" />
  <n-range-date-picker-pro v-model="datePickerProValue2" class="mb20 wh250" :disabled="true" />
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue1 = ref<string>('');
    const datePickerProValue2 = ref<string[]>(['', '']);

    return {
      datePickerProValue1,
      datePickerProValue2,
    };
  },
});
<\/script>
`},{highlight:h(()=>[nt]),default:h(()=>[P(k)]),_:1}),at,st,P(g,{sourceCode:`<template>
  <n-date-picker-pro v-model="datePickerProValue1" class="mb20 wh250 mr30" :calendarRange="[2022, 2025]" :limitDateRange="limitDateRange" />
  <n-range-date-picker-pro
    v-model="datePickerProValue2"
    class="mb20 wh250"
    :calendarRange="[2022, 2025]"
    :limitDateRange="limitDateRange"
  />
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const datePickerProValue1 = ref<string>('');
    const datePickerProValue2 = ref<string[]>(['', '']);
    const limitDateRange = ref<Date[]>([new Date(2022, 1, 5), new Date(2023, 1, 5)]);

    return {
      datePickerProValue1,
      datePickerProValue2,
      limitDateRange,
    };
  },
});
<\/script>
`},{highlight:h(()=>[et]),default:h(()=>[P(d)]),_:1}),ot])}var it=Y(R,[["render",ut]]);export{kt as __pageData,it as default};
