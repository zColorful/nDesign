import{V as y}from"./framework.1c17ccd8.js";import{_ as D}from"./plugin-vue_export-helper.21dcd24c.js";import{f as E,G as v,H as h,b as g,a6 as m,V as f,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const b={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:c,createVNode:l,createElementVNode:r,openBlock:i,createElementBlock:k}=y,d={class:"card-list-demo"};function o(a,C){const e=c("n-card-list");return i(),k("div",null,[r("div",d,[l(e,{cardType:1,data:a.data,page:a.pageInfo,onCardSizeChange:a.cardSizeChange},null,8,["data","page","onCardSizeChange"])])])}const{defineComponent:s,ref:F,reactive:p}=y,u=s({setup(){const a=F({size:"sm",total:1,pageSize:12,pageIndex:1,pageSizeOptions:[12,24,48]}),C=p([{cardTitle:"\u6570\u636E\u5E93\u7BA1\u7406",cardDate:"2023-02-01 15:30:24",cardUser:"\u7CFB\u7EDF\u7BA1\u7406\u5458",cardLogo:"http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png",cardStatus:1,noCardContent:!1,cardContentTitle:!1,cardContentLabel:[{name:"\u5B9E\u4F8B\u540D\u79F0",value:"lyjtest",type:1},{name:"\u6570\u636E\u5E93\u7C7B\u578B",value:"MYSQL",type:1}],cardOperation:"125",showMore:!1}]);return{pageInfo:a,data:C,cardSizeChange:B=>{console.log(B)}}}});return{render:o,...u}}(),"render-demo-1":function(){const{resolveComponent:c,createVNode:l,createElementVNode:r,openBlock:i,createElementBlock:k}=y,d={class:"card-list-demo2"};function o(a,C){const e=c("n-card-list");return i(),k("div",null,[r("div",d,[l(e,{cardType:2,data:a.data,onCardDevelopFn:a.cardDevelopFn},null,8,["data","onCardDevelopFn"])])])}const{defineComponent:s,ref:F,reactive:p}=y,u=s({setup(){return{data:p([{cardTitle:"\u5DE5\u5E8F\u8BA1\u5212\u91C7\u96C6",cardDate:"2023-02-01 15:30:24",cardUser:"\u7CFB\u7EDF\u7BA1\u7406\u5458",cardStatus:0,noCardContent:!1,cardOperation:"345",cardMappingTitle:"\u6620\u5C04\u5173\u7CFB",cardMappingLabel:[{name:"\u6570\u636E\u6E90\u7C7B\u578B",value:"MYSQL",type:1},{name:"\u91C7\u96C6\u89C4\u5219",value:"\u589E\u91CF\u91C7\u96C6",type:1},{name:"\u6570\u636E\u6E90",value:"MYSQL\u4E13\u7528",type:1},{name:"\u6570\u636E\u8868",value:"table_name",type:1},{name:"\u6570\u636E\u6A21\u578B",value:"table_model",type:1}],cardContentTitle:"\u8C03\u5EA6\u7B56\u7565",cardContentLabel:[{name:"\u6267\u884C\u65F6\u95F4",value:"2023-01-05 14:42:48",type:1},{name:"\u8C03\u5EA6\u9891\u6B21",value:["\u6BCF\u65E5","14:23:45"],type:2}],cardRerunTitle:"\u91CD\u8DD1\u673A\u5236",cardRerunLabel:[{name:"\u5931\u8D25\u91CD\u8BD5",value:["1\u6B21"],type:2},{name:"\u91CD\u8BD5\u95F4\u9694",value:["5\u5206"],type:2}],cardOperationLabel:"\u6570\u636E\u5F00\u53D1",showMore:!1}]),cardDevelopFn:e=>{console.log(e)}}}});return{render:o,...u}}(),"render-demo-2":function(){const{resolveComponent:c,createVNode:l,createElementVNode:r,openBlock:i,createElementBlock:k}=y,d={class:"card-list-demo3"};function o(a,C){const e=c("n-card-list");return i(),k("div",null,[r("div",d,[l(e,{cardType:3,data:a.data},null,8,["data"])])])}const{defineComponent:s,ref:F,reactive:p}=y,u=s({setup(){return{data:p([{cardTitle:"\u8D28\u91CF\u4EFB\u52A1",cardDate:"2023-02-01 15:30:24",cardUser:"\u7CFB\u7EDF\u7BA1\u7406\u5458",cardLogo:"http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png",cardStatus:3,noCardContent:!1,cardOperation:"123",cardContentTitle:"\u8C03\u5EA6\u7B56\u7565",cardContentLabel:[{name:"\u6267\u884C\u65F6\u95F4",value:"2023-01-05 14:42:48",type:1},{name:"\u8C03\u5EA6\u9891\u6B21",value:["\u6BCF\u65E5","14:23:45"],type:2}],cardRulerTitle:"\u6821\u9A8C\u89C4\u5219\u540D",cardRulerLabel:[{name:"\u90FD\u4E3A\u6574\u6570",type:2},{name:"\u90FD\u5927\u4E8E0",type:2},{name:"\u90FD\u5C0F\u4E8E100",type:2}],showMore:!1}])}}});return{render:o,...u}}(),"render-demo-3":function(){const{resolveComponent:c,createVNode:l,createElementVNode:r,openBlock:i,createElementBlock:k}=y,d={class:"card-list-demo4"};function o(a,C){const e=c("n-card-list");return i(),k("div",null,[r("div",d,[l(e,{cardType:4,data:a.data,noHeaderStatus:!0},null,8,["data"])])])}const{defineComponent:s,ref:F,reactive:p}=y,u=s({setup(){return{data:p([{cardTitle:"\u4E1A\u52A1\u57DF",cardDate:"2023-02-01 15:30:24",cardUser:"\u7CFB\u7EDF\u7BA1\u7406\u5458",cardLogo:"http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png",cardStatus:4,cardOperation:"145",description:"\u4E0A\u53489:00\u64CD\u4F5C",showMore:!1}])}}});return{render:o,...u}}()}},Q='{"title":"CardList \u5361\u7247\u5217\u8868\u7EC4\u4EF6","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u6570\u636E\u6E90\u7BA1\u7406","slug":"\u6570\u636E\u6E90\u7BA1\u7406"},{"level":3,"title":"\u6570\u636E\u5F00\u53D1/\u91C7\u96C6","slug":"\u6570\u636E\u5F00\u53D1-\u91C7\u96C6"},{"level":3,"title":"\u6570\u636E\u8D28\u91CF","slug":"\u6570\u636E\u8D28\u91CF"},{"level":3,"title":"\u4E1A\u52A1\u57DF","slug":"\u4E1A\u52A1\u57DF"},{"level":3,"title":"CardList \u53C2\u6570","slug":"cardlist-\u53C2\u6570"},{"level":3,"title":"CardList \u4E8B\u4EF6","slug":"cardlist-\u4E8B\u4EF6"},{"level":3,"title":"CardList data \u5B9A\u4E49","slug":"cardlist-data-\u5B9A\u4E49"}],"relativePath":"components/card-list/index.md","lastUpdated":1676259085486}',x=f('<h1 id="cardlist-\u5361\u7247\u5217\u8868\u7EC4\u4EF6" tabindex="-1">CardList \u5361\u7247\u5217\u8868\u7EC4\u4EF6 <a class="header-anchor" href="#cardlist-\u5361\u7247\u5217\u8868\u7EC4\u4EF6" aria-hidden="true">#</a></h1><p>\u5361\u7247\u5217\u8868\u7EC4\u4EF6</p><h4 id="\u5982\u4F55\u4F7F\u7528" tabindex="-1">\u5982\u4F55\u4F7F\u7528 <a class="header-anchor" href="#\u5982\u4F55\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u7528\u6237\u9700\u8981\u5C55\u793A\u5361\u7247\u7684\u5217\u8868\u65F6,\u5361\u7247\u5217\u8868\u7EC4\u4EF6\u662F\u7EDD\u5BF9\u5B9A\u4F4D\u7684\uFF0C\u9700\u8981\u7236\u5143\u7D20\u8BBE\u7F6E\u76F8\u5BF9\u5B9A\u4F4D\uFF0C\u4E14\u56FA\u5B9A\u597D\u5BBD\u5EA6\u548C\u9AD8\u5EA6\u3002</p><h3 id="\u6570\u636E\u6E90\u7BA1\u7406" tabindex="-1">\u6570\u636E\u6E90\u7BA1\u7406 <a class="header-anchor" href="#\u6570\u636E\u6E90\u7BA1\u7406" aria-hidden="true">#</a></h3>',5),A=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("card-list-demo"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-card-list")]),t(),n("span",{class:"token attr-name"},":cardType"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("1"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":page"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("pageInfo"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@cardSizeChange"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("cardSizeChange"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-card-list")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" pageInfo "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"size"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'sm'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"total"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"pageSize"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"12"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"pageIndex"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"pageSizeOptions"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"12"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"24"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"48"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token comment"},"// \u6BCF\u6B21\u5C55\u793A\u6761\u6570\u7684\u53EF\u914D\u7F6E\u9879"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"cardTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u5E93\u7BA1\u7406'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardDate"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-02-01 15:30:24'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardUser"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u7CFB\u7EDF\u7BA1\u7406\u5458'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardLogo"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardStatus"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"noCardContent"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u5B9E\u4F8B\u540D\u79F0'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'lyjtest'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u5E93\u7C7B\u578B'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'MYSQL'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardOperation"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'125'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"showMore"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"cardSizeChange"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"e"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),t("e"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      pageInfo`),n("span",{class:"token punctuation"},","),t(`
      data`),n("span",{class:"token punctuation"},","),t(`
      cardSizeChange`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),t(),n("span",{class:"token attr-name"},"scoped"),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".card-list-demo"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" flex-start"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" flex-end"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"position"),n("span",{class:"token punctuation"},":"),t(" relative"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"box-sizing"),n("span",{class:"token punctuation"},":"),t(" border-box"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"min-height"),n("span",{class:"token punctuation"},":"),t(" 360px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),t(" #f7f8fa"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},".cardList"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"top"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),_=n("h3",{id:"\u6570\u636E\u5F00\u53D1-\u91C7\u96C6",tabindex:"-1"},[t("\u6570\u636E\u5F00\u53D1/\u91C7\u96C6 "),n("a",{class:"header-anchor",href:"#\u6570\u636E\u5F00\u53D1-\u91C7\u96C6","aria-hidden":"true"},"#")],-1),L=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("card-list-demo2"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-card-list")]),t(),n("span",{class:"token attr-name"},":cardType"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("2"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@cardDevelopFn"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("cardDevelopFn"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-card-list")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"cardTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u5DE5\u5E8F\u8BA1\u5212\u91C7\u96C6'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardDate"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-02-01 15:30:24'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardUser"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u7CFB\u7EDF\u7BA1\u7406\u5458'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardStatus"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"noCardContent"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardOperation"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'345'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardMappingTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6620\u5C04\u5173\u7CFB'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardMappingLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u6E90\u7C7B\u578B'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'MYSQL'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u91C7\u96C6\u89C4\u5219'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u589E\u91CF\u91C7\u96C6'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u6E90'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'MYSQL\u4E13\u7528'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u8868'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'table_name'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u6A21\u578B'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'table_model'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u8C03\u5EA6\u7B56\u7565'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6267\u884C\u65F6\u95F4'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-01-05 14:42:48'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u8C03\u5EA6\u9891\u6B21'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'\u6BCF\u65E5'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'14:23:45'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardRerunTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u91CD\u8DD1\u673A\u5236'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardRerunLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u5931\u8D25\u91CD\u8BD5'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'1\u6B21'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u91CD\u8BD5\u95F4\u9694'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'5\u5206'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardOperationLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6570\u636E\u5F00\u53D1'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"showMore"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"cardDevelopFn"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"item"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),t("item"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      data`),n("span",{class:"token punctuation"},","),t(`
      cardDevelopFn`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),t(),n("span",{class:"token attr-name"},"scoped"),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".card-list-demo2"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" flex-start"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" flex-end"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"position"),n("span",{class:"token punctuation"},":"),t(" relative"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"box-sizing"),n("span",{class:"token punctuation"},":"),t(" border-box"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"min-height"),n("span",{class:"token punctuation"},":"),t(" 630px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),t(" #f7f8fa"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},".cardList"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"top"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),S=n("h3",{id:"\u6570\u636E\u8D28\u91CF",tabindex:"-1"},[t("\u6570\u636E\u8D28\u91CF "),n("a",{class:"header-anchor",href:"#\u6570\u636E\u8D28\u91CF","aria-hidden":"true"},"#")],-1),w=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("card-list-demo3"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-card-list")]),t(),n("span",{class:"token attr-name"},":cardType"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("3"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-card-list")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"cardTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u8D28\u91CF\u4EFB\u52A1'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardDate"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-02-01 15:30:24'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardUser"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u7CFB\u7EDF\u7BA1\u7406\u5458'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardLogo"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardStatus"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"3"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"noCardContent"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardOperation"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'123'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u8C03\u5EA6\u7B56\u7565'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardContentLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6267\u884C\u65F6\u95F4'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-01-05 14:42:48'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u8C03\u5EA6\u9891\u6B21'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"value"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'\u6BCF\u65E5'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'14:23:45'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardRulerTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6821\u9A8C\u89C4\u5219\u540D'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardRulerLabel"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"["),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u90FD\u4E3A\u6574\u6570'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u90FD\u5927\u4E8E0'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u90FD\u5C0F\u4E8E100'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"type"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"2"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"showMore"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      data`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),t(),n("span",{class:"token attr-name"},"scoped"),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".card-list-demo3"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" flex-start"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" flex-end"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"position"),n("span",{class:"token punctuation"},":"),t(" relative"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"box-sizing"),n("span",{class:"token punctuation"},":"),t(" border-box"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"min-height"),n("span",{class:"token punctuation"},":"),t(" 410px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),t(" #f7f8fa"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},".cardList"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"top"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),T=n("h3",{id:"\u4E1A\u52A1\u57DF",tabindex:"-1"},[t("\u4E1A\u52A1\u57DF "),n("a",{class:"header-anchor",href:"#\u4E1A\u52A1\u57DF","aria-hidden":"true"},"#")],-1),M=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("card-list-demo4"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-card-list")]),t(),n("span",{class:"token attr-name"},":cardType"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("4"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":noHeaderStatus"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("true"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-card-list")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" reactive "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"reactive"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"cardTitle"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u4E1A\u52A1\u57DF'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardDate"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2023-02-01 15:30:24'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardUser"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u7CFB\u7EDF\u7BA1\u7406\u5458'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardLogo"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardStatus"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"4"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"cardOperation"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'145'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"description"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u4E0A\u53489:00\u64CD\u4F5C'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"showMore"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      data`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),t(),n("span",{class:"token attr-name"},"scoped"),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scss"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".card-list-demo4"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" flex-start"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" flex-end"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"position"),n("span",{class:"token punctuation"},":"),t(" relative"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100%"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"box-sizing"),n("span",{class:"token punctuation"},":"),t(" border-box"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"min-height"),n("span",{class:"token punctuation"},":"),t(" 300px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background-color"),n("span",{class:"token punctuation"},":"),t(" #f7f8fa"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},".cardList"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"top"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),z=f(`<h3 id="cardlist-\u53C2\u6570" tabindex="-1">CardList \u53C2\u6570 <a class="header-anchor" href="#cardlist-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">cardType</td><td style="text-align:left;">number</td><td style="text-align:left;">1</td><td style="text-align:left;">\u5FC5\u9009\uFF0C1.\u6570\u636E\u6E90 2.\u6570\u636E\u5F00\u53D1/\u91C7\u96C6 3.\u6570\u636E\u8D28\u91CF 4.\u4E1A\u52A1\u57DF</td></tr><tr><td style="text-align:left;">data</td><td style="text-align:left;">array</td><td style="text-align:left;">[]</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u5217\u8868\u6570\u636E</td></tr><tr><td style="text-align:left;">noHeaderStatus</td><td style="text-align:left;">boolean</td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u4E0D\u663E\u793A\u5934\u90E8</td></tr></tbody></table><h3 id="cardlist-\u4E8B\u4EF6" tabindex="-1">CardList \u4E8B\u4EF6 <a class="header-anchor" href="#cardlist-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u56DE\u8C03\u53C2\u6570</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">cardDispatchFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u8C03\u5EA6\u7B56\u7565\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u9009\u4E2D\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardRerunFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u91CD\u8DD1\u673A\u5236\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u9009\u4E2D\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardShowMoreRulerFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u6821\u68C0\u89C4\u5219\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u9009\u4E2D\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardDevelopFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u6570\u636E\u5F00\u53D1\u6309\u94AE\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardSendFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u53D1\u5E03\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardDelFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u5220\u9664\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardEditFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u7F16\u8F91\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardOffFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u4E0B\u67B6\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardSeeFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u67E5\u770B\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardRunFn</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u6267\u884C\u56FE\u6807\u70B9\u51FB\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u70B9\u51FB\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">cardCurrentChange</td><td style="text-align:left;"><code>Function(number)</code></td><td style="text-align:left;">\u5206\u9875\u9875\u7801\u6539\u53D8\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u6700\u65B0\u7684\u5206\u9875\u9875\u7801</td></tr><tr><td style="text-align:left;">onPageSizeChange</td><td style="text-align:left;"><code>Function(number)</code></td><td style="text-align:left;">\u5206\u9875\u5355\u9875\u6570\u91CF\u6539\u53D8\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u6700\u65B0\u7684\u5206\u9875\u6570\u91CF</td></tr></tbody></table><h3 id="cardlist-data-\u5B9A\u4E49" tabindex="-1">CardList data \u5B9A\u4E49 <a class="header-anchor" href="#cardlist-data-\u5B9A\u4E49" aria-hidden="true">#</a></h3><div class="language-ts"><pre><code><span class="token keyword">interface</span> <span class="token class-name">IDataNode</span> <span class="token punctuation">{</span>
  cardTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u5934\u90E8\u540D\u79F0</span>
  cardDate<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u521B\u5EFA\u65E5\u671F</span>
  cardUser<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u521B\u5EFA\u89D2\u8272\u540D</span>
  cardLogo<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u53F3\u8FB9\u89D2\u56FE\u7247</span>
  cardStatus<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u53F3\u4E0A\u89D2\u72B6\u6001 0-\u5DF2\u4E0B\u67B6 1-\u5DF2\u53D1\u5E03 3-\u5BA1\u6838\u4E2D 4-\u5BA1\u6838\u5931\u8D25</span>
  cardOperation<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// &#39;123456&#39;,\u5361\u7247\u66F4\u591A\u64CD\u4F5C 1\uFF1A\u53D1\u5E03 2\uFF1A\u5220\u9664 3\uFF1A\u7F16\u8F91 4\uFF1A\u4E0B\u67B6 5\uFF1A\u67E5\u770B 6:\u7ACB\u5373\u6267\u884C</span>
  cardOperationLabel<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u53F3\u4E0B\u89D2\u6309\u94AE\u540D\u79F0</span>
  cardContentTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u5185\u5BB9\u90E8\u5206\u540D\u79F0</span>
  cardContentLabel<span class="token operator">:</span> <span class="token builtin">Array</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u5185\u5BB9\u6570\u7EC4type:1\u8868\u793A\u666E\u901A\u6587\u5B57 2\u8868\u793A\u6570\u7EC4\u6309\u94AE\u6587\u5B57[{name:&#39;\u6267\u884C\u65F6\u95F4&#39;,value:&#39;2023-01-05 14:42:48&#39;,type:1},{name:&#39;\u8C03\u5EA6\u89C4\u5219&#39;,value:[&#39;\u6BCF\u5929&#39;,&#39;15:01&#39;],type:2}]</span>
  cardRerunTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u91CD\u8DD1\u673A\u5236\u540D\u79F0</span>
  cardRerunLabel<span class="token operator">:</span> <span class="token builtin">Array</span><span class="token punctuation">;</span> <span class="token comment">// \u540CcardContentLabel</span>
  cardRulerTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5361\u7247\u6821\u9A8C\u89C4\u5219\u540D\u79F0</span>
  cardRulerLabel<span class="token operator">:</span> <span class="token builtin">Array</span><span class="token punctuation">;</span> <span class="token comment">// [&#39;\u4E3A\u7A7A\u6548\u9A8C&#39;,&#39;\u5927\u4E8E1\u6821\u68C0&#39;] \u5361\u7247\u5C55\u793A\u89C4\u5219\u5217\u8868</span>
  description<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u4E1A\u52A1\u57DF\u63CF\u8FF0\u4FE1\u606F</span>
<span class="token punctuation">}</span>
</code></pre></div>`,6);function V(c,l,r,i,k,d){const o=E("render-demo-0"),s=E("demo"),F=E("render-demo-1"),p=E("render-demo-2"),u=E("render-demo-3");return v(),h("div",null,[x,g(s,{sourceCode:`<template>
  <div class="card-list-demo">
    <n-card-list :cardType="1" :data="data" :page="pageInfo" @cardSizeChange="cardSizeChange"></n-card-list>
  </div>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';
export default defineComponent({
  setup() {
    const pageInfo = ref({
      size: 'sm',
      total: 1,
      pageSize: 12,
      pageIndex: 1,
      pageSizeOptions: [12, 24, 48], // \u6BCF\u6B21\u5C55\u793A\u6761\u6570\u7684\u53EF\u914D\u7F6E\u9879
    });

    const data = reactive([
      {
        cardTitle: '\u6570\u636E\u5E93\u7BA1\u7406',
        cardDate: '2023-02-01 15:30:24',
        cardUser: '\u7CFB\u7EDF\u7BA1\u7406\u5458',
        cardLogo: 'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png',
        cardStatus: 1,
        noCardContent: false,
        cardContentTitle: false,
        cardContentLabel: [
          { name: '\u5B9E\u4F8B\u540D\u79F0', value: 'lyjtest', type: 1 },
          { name: '\u6570\u636E\u5E93\u7C7B\u578B', value: 'MYSQL', type: 1 },
        ],
        cardOperation: '125',
        showMore: false,
      },
    ]);

    const cardSizeChange = (e) => {
      console.log(e);
    };

    return {
      pageInfo,
      data,
      cardSizeChange,
    };
  },
});
<\/script>

<style scoped lang="scss">
.card-list-demo {
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  min-height: 360px;
  background-color: #f7f8fa;
  .cardList {
    top: 10px;
  }
}
</style>
`},{highlight:m(()=>[A]),default:m(()=>[g(o)]),_:1}),_,g(s,{sourceCode:`<template>
  <div class="card-list-demo2">
    <n-card-list :cardType="2" :data="data" @cardDevelopFn="cardDevelopFn"></n-card-list>
  </div>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';
export default defineComponent({
  setup() {
    const data = reactive([
      {
        cardTitle: '\u5DE5\u5E8F\u8BA1\u5212\u91C7\u96C6',
        cardDate: '2023-02-01 15:30:24',
        cardUser: '\u7CFB\u7EDF\u7BA1\u7406\u5458',
        cardStatus: 0,
        noCardContent: false,
        cardOperation: '345',
        cardMappingTitle: '\u6620\u5C04\u5173\u7CFB',
        cardMappingLabel: [
          { name: '\u6570\u636E\u6E90\u7C7B\u578B', value: 'MYSQL', type: 1 },
          { name: '\u91C7\u96C6\u89C4\u5219', value: '\u589E\u91CF\u91C7\u96C6', type: 1 },
          { name: '\u6570\u636E\u6E90', value: 'MYSQL\u4E13\u7528', type: 1 },
          { name: '\u6570\u636E\u8868', value: 'table_name', type: 1 },
          { name: '\u6570\u636E\u6A21\u578B', value: 'table_model', type: 1 },
        ],
        cardContentTitle: '\u8C03\u5EA6\u7B56\u7565',
        cardContentLabel: [
          { name: '\u6267\u884C\u65F6\u95F4', value: '2023-01-05 14:42:48', type: 1 },
          { name: '\u8C03\u5EA6\u9891\u6B21', value: ['\u6BCF\u65E5', '14:23:45'], type: 2 },
        ],
        cardRerunTitle: '\u91CD\u8DD1\u673A\u5236',
        cardRerunLabel: [
          { name: '\u5931\u8D25\u91CD\u8BD5', value: ['1\u6B21'], type: 2 },
          { name: '\u91CD\u8BD5\u95F4\u9694', value: ['5\u5206'], type: 2 },
        ],
        cardOperationLabel: '\u6570\u636E\u5F00\u53D1',
        showMore: false,
      },
    ]);

    const cardDevelopFn = (item) => {
      console.log(item);
    };

    return {
      data,
      cardDevelopFn,
    };
  },
});
<\/script>

<style scoped lang="scss">
.card-list-demo2 {
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  min-height: 630px;
  background-color: #f7f8fa;
  .cardList {
    top: 10px;
  }
}
</style>
`},{highlight:m(()=>[L]),default:m(()=>[g(F)]),_:1}),S,g(s,{sourceCode:`<template>
  <div class="card-list-demo3">
    <n-card-list :cardType="3" :data="data"></n-card-list>
  </div>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';
export default defineComponent({
  setup() {
    const data = reactive([
      {
        cardTitle: '\u8D28\u91CF\u4EFB\u52A1',
        cardDate: '2023-02-01 15:30:24',
        cardUser: '\u7CFB\u7EDF\u7BA1\u7406\u5458',
        cardLogo: 'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png',
        cardStatus: 3,
        noCardContent: false,
        cardOperation: '123',
        cardContentTitle: '\u8C03\u5EA6\u7B56\u7565',
        cardContentLabel: [
          { name: '\u6267\u884C\u65F6\u95F4', value: '2023-01-05 14:42:48', type: 1 },
          { name: '\u8C03\u5EA6\u9891\u6B21', value: ['\u6BCF\u65E5', '14:23:45'], type: 2 },
        ],
        cardRulerTitle: '\u6821\u9A8C\u89C4\u5219\u540D',
        cardRulerLabel: [
          { name: '\u90FD\u4E3A\u6574\u6570', type: 2 },
          { name: '\u90FD\u5927\u4E8E0', type: 2 },
          { name: '\u90FD\u5C0F\u4E8E100', type: 2 },
        ],
        showMore: false,
      },
    ]);

    return {
      data,
    };
  },
});
<\/script>

<style scoped lang="scss">
.card-list-demo3 {
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  min-height: 410px;
  background-color: #f7f8fa;
  .cardList {
    top: 10px;
  }
}
</style>
`},{highlight:m(()=>[w]),default:m(()=>[g(p)]),_:1}),T,g(s,{sourceCode:`<template>
  <div class="card-list-demo4">
    <n-card-list :cardType="4" :data="data" :noHeaderStatus="true"></n-card-list>
  </div>
</template>

<script>
import { defineComponent, ref, reactive } from 'vue';
export default defineComponent({
  setup() {
    const data = reactive([
      {
        cardTitle: '\u4E1A\u52A1\u57DF',
        cardDate: '2023-02-01 15:30:24',
        cardUser: '\u7CFB\u7EDF\u7BA1\u7406\u5458',
        cardLogo: 'http://139.9.159.225:9006/static/css/MYSQL-b7481da6.png',
        cardStatus: 4,
        cardOperation: '145',
        description: '\u4E0A\u53489:00\u64CD\u4F5C',
        showMore: false,
      },
    ]);

    return {
      data,
    };
  },
});
<\/script>

<style scoped lang="scss">
.card-list-demo4 {
  display: flex;
  justify-content: flex-start;
  align-items: flex-end;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  min-height: 300px;
  background-color: #f7f8fa;
  .cardList {
    top: 10px;
  }
}
</style>
`},{highlight:m(()=>[M]),default:m(()=>[g(u)]),_:1}),z])}var Y=D(b,[["render",V]]);export{Q as __pageData,Y as default};
