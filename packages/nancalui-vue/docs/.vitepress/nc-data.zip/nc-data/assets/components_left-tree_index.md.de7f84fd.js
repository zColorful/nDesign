import{V as k}from"./framework.1c17ccd8.js";import{_ as D}from"./plugin-vue_export-helper.21dcd24c.js";import{f as d,G as g,H as C,b as E,a6 as h,V as y,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const m={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:o,createVNode:u,openBlock:p,createElementBlock:l}=k;function c(a,f){const i=o("n-left-tree");return p(),l("div",null,[u(i,{data:a.data,treeAttrData:a.treeAttrData,onTreeDelNode:a.treeDelNode},null,8,["data","treeAttrData","onTreeDelNode"])])}const{defineComponent:r,ref:e}=k,s=r({setup(){return{data:e([{id:0,label:"\u5168\u90E8",type:"ROOT",children:[{id:1,label:"\u7EC4\u4E00",type:"group",children:[{id:4,label:"\u7EC4\u56DB",type:"group",children:null}]},{id:2,label:"\u7EC4\u4E8C",type:"group",children:null},{id:3,label:"\u7EC4\u4E09",type:"group",children:null}]}]),treeAttrData:{showCheckbox:!1,showControl:!0,showLeftIcon:!0},treeDelNode:F=>{console.log(F)}}}});return{render:c,...s}}()}},T='{"title":"leftTree \u5DE6\u4FA7\u6811","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"LeftTree \u53C2\u6570","slug":"lefttree-\u53C2\u6570"},{"level":3,"title":"LeftTree \u4E8B\u4EF6","slug":"lefttree-\u4E8B\u4EF6"},{"level":3,"title":"LeftTree \u63D2\u69FD","slug":"lefttree-\u63D2\u69FD"},{"level":3,"title":"LeftTree treeAttrData \u5B9A\u4E49","slug":"lefttree-treeattrdata-\u5B9A\u4E49"}],"relativePath":"components/left-tree/index.md","lastUpdated":1677130536208}',b=y('<h1 id="lefttree-\u5DE6\u4FA7\u6811" tabindex="-1">leftTree \u5DE6\u4FA7\u6811 <a class="header-anchor" href="#lefttree-\u5DE6\u4FA7\u6811" aria-hidden="true">#</a></h1><p>\u4E00\u79CD\u5448\u73B0\u5D4C\u5957\u7ED3\u6784\u7684\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u6587\u4EF6\u5939\u3001\u7EC4\u7EC7\u67B6\u6784\u3001\u751F\u7269\u5206\u7C7B\u3001\u56FD\u5BB6\u5730\u533A\u7B49\u7B49\uFF0C\u4E16\u95F4\u4E07\u7269\u7684\u5927\u591A\u6570\u7ED3\u6784\u90FD\u662F\u6811\u5F62\u7ED3\u6784\u3002\u4F7F\u7528\u6811\u7EC4\u4EF6\u53EF\u4EE5\u5B8C\u6574\u5C55\u73B0\u5176\u4E2D\u7684\u5C42\u7EA7\u5173\u7CFB\uFF0C\u5E76\u5177\u6709\u5C55\u5F00/\u6536\u8D77\u3001\u9009\u62E9\u7B49\u4EA4\u4E92\u529F\u80FD\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),B=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-left-tree")]),n(),t("span",{class:"token attr-name"},":data"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":treeAttrData"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("treeAttrData"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},"@treeDelNode"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("treeDelNode"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-left-tree")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" data "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"["),n(`
      `),t("span",{class:"token punctuation"},"{"),n(`
        `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token number"},"0"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"label"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u5168\u90E8'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"type"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'ROOT'"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token literal-property property"},"children"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token punctuation"},"["),n(`
          `),t("span",{class:"token punctuation"},"{"),n(`
            `),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token number"},"1"),t("span",{class:"token punctuation"},","),n(`
            `),t("span",{class:"token literal-property property"},"label"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7EC4\u4E00'"),t("span",{class:"token punctuation"},","),n(`
            `),t("span",{class:"token literal-property property"},"type"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'group'"),t("span",{class:"token punctuation"},","),n(`
            `),t("span",{class:"token literal-property property"},"children"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token punctuation"},"["),t("span",{class:"token punctuation"},"{"),n(),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token number"},"4"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"label"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7EC4\u56DB'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"type"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'group'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"children"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token keyword"},"null"),n(),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),n(`
          `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
          `),t("span",{class:"token punctuation"},"{"),n(),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token number"},"2"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"label"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7EC4\u4E8C'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"type"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'group'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"children"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token keyword"},"null"),n(),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
          `),t("span",{class:"token punctuation"},"{"),n(),t("span",{class:"token literal-property property"},"id"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token number"},"3"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"label"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'\u7EC4\u4E09'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"type"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token string"},"'group'"),t("span",{class:"token punctuation"},","),n(),t("span",{class:"token literal-property property"},"children"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token keyword"},"null"),n(),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
        `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"]"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"const"),n(" treeAttrData "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"{"),n(`
      `),t("span",{class:"token literal-property property"},"showCheckbox"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token boolean"},"false"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token literal-property property"},"showControl"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},","),n(`
      `),t("span",{class:"token literal-property property"},"showLeftIcon"),t("span",{class:"token operator"},":"),n(),t("span",{class:"token boolean"},"true"),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"const"),n(),t("span",{class:"token function-variable function"},"treeDelNode"),n(),t("span",{class:"token operator"},"="),n(),t("span",{class:"token punctuation"},"("),t("span",{class:"token parameter"},"item"),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(),t("span",{class:"token punctuation"},"{"),n(`
      console`),t("span",{class:"token punctuation"},"."),t("span",{class:"token function"},"log"),t("span",{class:"token punctuation"},"("),n("item"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      data`),t("span",{class:"token punctuation"},","),n(`
      treeAttrData`),t("span",{class:"token punctuation"},","),n(`
      treeDelNode`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),x=y(`<h3 id="lefttree-\u53C2\u6570" tabindex="-1">LeftTree \u53C2\u6570 <a class="header-anchor" href="#lefttree-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">data</td><td style="text-align:left;">array</td><td style="text-align:left;">[]</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u6811\u57FA\u7840\u6570\u636E,\u5982 [{label:&#39;\u8282\u70B9&#39;,type:&#39;tag&#39;,id:1,children:[]}]</td></tr><tr><td style="text-align:left;">treeAttrData</td><td style="text-align:left;">object</td><td style="text-align:left;">{}</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6811\u5C5E\u6027\u6570\u636E</td></tr></tbody></table><h3 id="lefttree-\u4E8B\u4EF6" tabindex="-1">LeftTree \u4E8B\u4EF6 <a class="header-anchor" href="#lefttree-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u56DE\u8C03\u53C2\u6570</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">treeUpdateNode</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u65B0\u589E\u6216\u4FEE\u6539\u8282\u70B9\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u4FEE\u6539\u540E\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">treeDelNode</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u5220\u9664\u8282\u70B9\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u9009\u4E2D\u7684\u8282\u70B9\u5BF9\u8C61</td></tr><tr><td style="text-align:left;">treeCheckNode</td><td style="text-align:left;"><code>Function(item)</code></td><td style="text-align:left;">\u9009\u4E2D\u72B6\u6001\u53D1\u751F\u53D8\u5316\u4E8B\u4EF6\uFF0C\u8FD4\u56DE\u6240\u6709\u9009\u4E2D\u7684\u8282\u70B9\u5BF9\u8C61</td></tr></tbody></table><h3 id="lefttree-\u63D2\u69FD" tabindex="-1">LeftTree \u63D2\u69FD <a class="header-anchor" href="#lefttree-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u63D2\u69FD\u540D</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">pageTop</td><td style="text-align:left;">\u5934\u90E8\u5185\u5BB9\u66FF\u6362</td></tr></tbody></table><h3 id="lefttree-treeattrdata-\u5B9A\u4E49" tabindex="-1">LeftTree treeAttrData \u5B9A\u4E49 <a class="header-anchor" href="#lefttree-treeattrdata-\u5B9A\u4E49" aria-hidden="true">#</a></h3><div class="language-ts"><pre><code><span class="token keyword">interface</span> <span class="token class-name">treeAttrData</span> <span class="token punctuation">{</span>
  isHideSearch<span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u662F\u5426\u9690\u85CF\u5DE6\u4FA7\u9876\u90E8\u641C\u7D22\u6846</span>
  isHideTree<span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u662F\u5426\u5DE6\u4FA7\u9690\u85CF\u6811</span>
  filterText<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u8FC7\u6EE4\u5185\u5BB9</span>
  showCheckbox<span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u662F\u5426\u663E\u793A\u9009\u62E9\u6846checkbox</span>
  showControl<span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u663E\u793A\u63A7\u5236\u6309\u94AE</span>
  showLeftIcon<span class="token operator">:</span> <span class="token builtin">boolean</span><span class="token punctuation">;</span> <span class="token comment">// \u663E\u793A\u5DE6\u4FA7icon\u56FE\u6807</span>
  dialogTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5F39\u7A97\u9876\u90E8\u540D\u79F0</span>
  dialogName<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5F39\u7A97\u8F93\u5165\u76EE\u5F55\u540D\u79F0</span>
  dialogDesc<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u5F39\u7A97\u63CF\u8FF0\u540D\u79F0</span>
  childTitle<span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span> <span class="token comment">// \u4E8C\u7EA7\u7236\u7C7B\u5143\u7D20\u65B0\u589E\u540D\u79F0</span>
<span class="token punctuation">}</span>
</code></pre></div>`,8);function A(o,u,p,l,c,r){const e=d("render-demo-0"),s=d("demo");return g(),C("div",null,[b,E(s,{sourceCode:`<template>
  <n-left-tree :data="data" :treeAttrData="treeAttrData" @treeDelNode="treeDelNode"></n-left-tree>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const data = ref([
      {
        id: 0,
        label: '\u5168\u90E8',
        type: 'ROOT',
        children: [
          {
            id: 1,
            label: '\u7EC4\u4E00',
            type: 'group',
            children: [{ id: 4, label: '\u7EC4\u56DB', type: 'group', children: null }],
          },
          { id: 2, label: '\u7EC4\u4E8C', type: 'group', children: null },
          { id: 3, label: '\u7EC4\u4E09', type: 'group', children: null },
        ],
      },
    ]);

    const treeAttrData = {
      showCheckbox: false,
      showControl: true,
      showLeftIcon: true,
    };

    const treeDelNode = (item) => {
      console.log(item);
    };

    return {
      data,
      treeAttrData,
      treeDelNode,
    };
  },
});
<\/script>
`},{highlight:h(()=>[B]),default:h(()=>[E(e)]),_:1}),x])}var L=D(m,[["render",A]]);export{T as __pageData,L as default};
