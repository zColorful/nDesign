import{V as v}from"./framework.1c17ccd8.js";import{_ as j}from"./plugin-vue_export-helper.21dcd24c.js";import{f as $,G as M,H as P,b,a6 as A,a3 as T,V as K,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const G={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:f,createVNode:g,createCommentVNode:x,openBlock:w,createElementBlock:E}=v;function C(s,u){const c=f("n-table-v");return w(),E("div",null,[g(c,{columns:s.columns,data:s.data,width:850,height:400,fixed:"",style:{width:"100%"}},null,8,["columns","data"]),x(` <n-my-table :attrList="attrList" :tableData="dataSource" :isAction="true" borderType="bordered">
    <template #action="scoped">
      <n-button type="text" @click="test(scoped)">\u6D4B\u8BD5</n-button>
    </template>
  </n-my-table> `)])}const{defineComponent:F,ref:d}=v,r=F({setup(){const s=(y=10,o="column-",e)=>Array.from({length:y}).map((i,m)=>({...e,key:`${o}${m}`,dataKey:`${o}${m}`,title:`Column ${m}`,width:150})),u=(y,o=200,e="row-")=>Array.from({length:o}).map((i,m)=>y.reduce((p,a,k)=>(p[a.dataKey]=`Row ${m} - Col ${k}`,p),{id:`${e}${m}`,parentId:null})),c=s(2);return{data:u(c,1e5),columns:c}}});return{render:C,...r}}(),"render-demo-1":function(){const{resolveComponent:f,createVNode:g,withCtx:x,createElementVNode:w,openBlock:E,createElementBlock:C}=v,F={style:{height:"400px"}};function d(c,l){const y=f("n-table-v"),o=f("n-auto-resizer");return E(),C("div",null,[w("div",F,[g(o,null,{default:x(({height:e,width:i})=>[g(y,{columns:c.columns,data:c.data,width:i,height:e,fixed:""},null,8,["columns","data","width","height"])]),_:1})])])}const{defineComponent:r,ref:s}=v,u=r({setup(){const c=(e=10,i="column-",m)=>Array.from({length:e}).map((p,a)=>({...m,key:`${i}${a}`,dataKey:`${i}${a}`,title:`Column ${a}`,width:150})),l=(e,i=200,m="row-")=>Array.from({length:i}).map((p,a)=>e.reduce((k,h,D)=>(k[h.dataKey]=`Row ${a} - Col ${D}`,k),{id:`${m}${a}`,parentId:null})),y=c(10);return{data:l(y,1e3),columns:y}}});return{render:d,...u}}(),"render-demo-2":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(r,s){const u=f("n-table-v");return x(),w("div",null,[g(u,{columns:r.columns,data:r.data,width:700,height:400,fixed:""},null,8,["columns","data"])])}const{defineComponent:C,ref:F}=v,d=C({setup(){let r=0;const s=()=>({id:`random-id-${++r}`,name:"Tom",date:"2020-10-1"}),u=[{key:"date",title:"Date",dataKey:"date",width:150,fixed:"right"},{key:"name",title:"Name",dataKey:"name",align:"center",width:200,cellRenderer:({cellData:l})=>666},{key:"operations",title:"Operations",width:200,align:"center"}];return{data:F(Array.from({length:200}).map(s)),columns:u}}});return{render:E,...d}}(),"render-demo-3":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(r,s){const u=f("n-table-v");return x(),w("div",null,[g(u,{columns:r.columns,data:r.data,"row-class":r.rowClass,width:700,height:400},null,8,["columns","data","row-class"])])}const{ref:C,defineComponent:F}=v,d=F({setup(){let r=0;const s=()=>({id:`random-id-${++r}`,name:"Tom",date:"2020-10-1"}),u=[{key:"date",title:"Date",dataKey:"date",width:150,fixed:"left"},{key:"name",title:"Name",dataKey:"name",width:150,align:"center"},{key:"operations",title:"Operations",width:150,align:"center",flexGrow:1}],c=C(Array.from({length:200}).map(s));return{columns:u,rowClass:({rowIndex:y})=>y%10===5?"bg-red-100":y%10===0?"bg-blue-200":"",data:c}}});return{render:E,...d}}(),"render-demo-4":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(s,u){const c=f("n-table-v");return x(),w("div",null,[g(c,{columns:s.columns,data:s.tableData,"fixed-data":s.fixedData,width:700,height:400,"row-class":s.rowClass,fixed:"",onScroll:s.onScroll},null,8,["columns","data","fixed-data","row-class","onScroll"])])}const{ref:C,defineComponent:F,computed:d}=v,r=F({setup(){const s=(p=10,a="column-",k)=>Array.from({length:p}).map((h,D)=>({...k,key:`${a}${D}`,dataKey:`${a}${D}`,title:`Column ${D}`,width:150})),u=(p,a=200,k="row-")=>Array.from({length:a}).map((h,D)=>p.reduce((_,B,q)=>(_[B.dataKey]=`Row ${D} - Col ${q}`,_),{id:`${k}${D}`,parentId:null})),c=s(10),l=u(c,200),y=({rowIndex:p})=>{if(p<0||(p+1)%5===0)return"sticky-row"},o=C(0),e=d(()=>l.slice(o.value,o.value+1)),i=d(()=>l.slice(1));return{columns:c,rowClass:y,tableData:i,onScroll:({scrollTop:p})=>{o.value=Math.floor(p/250)*5},fixedData:e}}});return{render:E,...r}}(),"render-demo-5":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(r,s){const u=f("n-table-v");return x(),w("div",null,[g(u,{columns:r.columns,data:r.data,"sort-by":r.sortBy,width:700,height:400,fixed:"",onColumnSort:r.onSort},null,8,["columns","data","sort-by","onColumnSort"])])}const{ref:C,defineComponent:F}=v,d=F({setup(){const r=(o=10,e="column-",i)=>Array.from({length:o}).map((m,p)=>({...i,key:`${e}${p}`,dataKey:`${e}${p}`,title:`Column ${p}`,width:150})),s=(o,e=200,i="row-")=>Array.from({length:e}).map((m,p)=>o.reduce((a,k,h)=>(a[k.dataKey]=`Row ${p} - Col ${h}`,a),{id:`${i}${p}`,parentId:null})),u=r(10);let c=s(u,200);const l=C({key:"column-0",order:"asc"}),y=o=>{c=c.reverse(),l.value=o};u[0].fixed=!0,u[1].fixed="left",u[9].fixed="right";for(let o=0;o<3;o++)u[o].sortable=!0;return{columns:u,data:c,sortBy:l,onSort:y}}});return{render:E,...d}}(),"render-demo-6":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(r,s){const u=f("n-table-v");return x(),w("div",null,[g(u,{columns:r.columns,data:r.data,"sort-by":r.sortState,width:700,height:400,fixed:"",onColumnSort:r.onSort},null,8,["columns","data","sort-by","onColumnSort"])])}const{ref:C,defineComponent:F}=v,d=F({setup(){const r=(o=10,e="column-",i)=>Array.from({length:o}).map((m,p)=>({...i,key:`${e}${p}`,dataKey:`${e}${p}`,title:`Column ${p}`,width:150})),s=(o,e=200,i="row-")=>Array.from({length:e}).map((m,p)=>o.reduce((a,k,h)=>(a[k.dataKey]=`Row ${p} - Col ${h}`,a),{id:`${i}${p}`,parentId:null})),u=r(10);let c=s(u,200);u[0].sortable=!0;const l=C({key:"column-0",order:"asc"});return{columns:u,data:c,onSort:o=>{console.log(o),c=c.reverse(),l.value=o},sortState:l}}});return{render:E,...d}}(),"render-demo-7":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(r,s){const u=f("n-table-v");return x(),w("div",null,[g(u,{"sort-state":r.sortState,"onUpdate:sortState":s[0]||(s[0]=c=>r.sortState=c),columns:r.columns,data:r.data,width:700,height:400,fixed:"",onColumnSort:r.onSort},null,8,["sort-state","columns","data","onColumnSort"])])}const{ref:C,defineComponent:F}=v,d=F({setup(){const r=(o=10,e="column-",i)=>Array.from({length:o}).map((m,p)=>({...i,key:`${e}${p}`,dataKey:`${e}${p}`,title:`Column ${p}`,width:150})),s=(o,e=200,i="row-")=>Array.from({length:e}).map((m,p)=>o.reduce((a,k,h)=>(a[k.dataKey]=`Row ${p} - Col ${h}`,a),{id:`${i}${p}`,parentId:null})),u=r(10),c=C(s(u,200));u[0].sortable=!0,u[1].sortable=!0;const l=C({"column-0":"desc","column-1":"asc"});return{columns:u,data:c,onSort:({key:o,order:e})=>{l.value[o]=e,c.value=c.value.reverse()},sortState:l}}});return{render:E,...d}}(),"render-demo-8":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(s,u){const c=f("n-table-v");return x(),w("div",null,[g(c,{"expanded-row-keys":s.expandedRowKeys,"onUpdate:expandedRowKeys":u[0]||(u[0]=l=>s.expandedRowKeys=l),columns:s.columns,data:s.treeData,width:700,"expand-column-key":s.expandColumnKey,height:400,fixed:"",onRowExpand:s.onRowExpanded,onExpandedRowsChange:s.onExpandedRowsChange},null,8,["expanded-row-keys","columns","data","expand-column-key","onRowExpand","onExpandedRowsChange"])])}const{ref:C,defineComponent:F,computed:d}=v,r=F({setup(){const s=(a=10,k="column-",h)=>Array.from({length:a}).map((D,_)=>({...h,key:`${k}${_}`,dataKey:`${k}${_}`,title:`Column ${_}`,width:150})),u=(a,k=200,h="row-")=>Array.from({length:k}).map((D,_)=>a.reduce((B,q,I)=>(B[q.dataKey]=`Row ${_} - Col ${I}`,B),{id:`${h}${_}`,parentId:null})),c=s(10).map((a,k)=>{let h;return k<2&&(h="left"),k>8&&(h="right"),{...a,fixed:h}}),l=u(c,200),y="column-0";for(let a=0;a<50;a++)l.push({...l[0],id:`${l[0].id}-sub-${a}`,parentId:l[0].id,[y]:`Sub ${a}`},{...l[2],id:`${l[2].id}-sub-${a}`,parentId:l[2].id,[y]:`Sub ${a}`},{...l[2],id:`${l[2].id}-sub-sub-${a}`,parentId:`${l[2].id}-sub-${a}`,[y]:`Sub-Sub ${a}`});function o(a,k=null,h="id",D="parentId"){const _=[],B={};for(const q of a){const I={...q},S=I[h],R=I[D];Array.isArray(I.children)?B[S]=I.children.concat(B[S]||[]):B[S]||(B[S]=[]),I.children=B[S],R!==void 0&&R!==k?(B[R]||(B[R]=[]),B[R].push(I)):_.push(I)}return _}const e=d(()=>o(l)),i=C([]);return{columns:c,treeData:e,onExpandedRowsChange:a=>{console.log(a)},onRowExpanded:({expanded:a})=>{console.log("Expanded:",a)},expandedRowKeys:i,expandColumnKey:y}}});return{render:E,...r}}(),"render-demo-9":function(){const{resolveComponent:f,createVNode:g,openBlock:x,createElementBlock:w}=v;function E(s,u){const c=f("n-table-v");return x(),w("div",null,[g(c,{columns:s.columns,data:s.data,"sort-by":s.sort,"estimated-row-height":80,width:700,height:400,fixed:"",onColumnSort:s.onColumnSort},null,8,["columns","data","sort-by","onColumnSort"])])}const{ref:C,defineComponent:F,computed:d}=v,r=F({setup(){const l=["Eius optio fugiat.","Corrupti doloremque a quos vero delectus consequatur.","Quaerat ipsam necessitatibus eum quibusdam est id voluptatem cumque mollitia."];let y=0;const o=()=>({id:`random:${++y}`,name:"Tom",date:"2016-05-03",description:l[Math.floor(Math.random()*3)]}),e=[{key:"id",title:"Id",dataKey:"id",width:150,sortable:!0,fixed:"left"},{key:"name",title:"Name",dataKey:"name",width:150,align:"center",cellRenderer:({cellData:a})=>"name"},{key:"description",title:"Description",dataKey:"description",width:150,cellRenderer:({cellData:a})=>"description"},{key:"operations",title:"Operations",cellRenderer:()=>"test",width:150,align:"center"}],i=C(Array.from({length:200}).map(o).sort((a,k)=>a.name>k.name?1:-1)),m=C({key:"name",order:"asc"});return{columns:e,data:i,onColumnSort:a=>{const k=a.order==="asc"?1:-1,h=[...i.value];h.sort((D,_)=>D[a.key]>_[a.key]?k:-k),m.value=a,i.value=h},sort:m}}});return{render:E,...r}}(),"render-demo-10":function(){const{createElementVNode:f,resolveComponent:g,withCtx:x,createVNode:w,openBlock:E,createElementBlock:C}=v,F=f("div",{class:"flex items-center",style:{"justify-content":"center",height:"100%","background-color":"#447DFD"}}," Display a message in the footer ",-1);function d(l,y){const o=g("n-table-v");return E(),C("div",null,[w(o,{columns:l.columns,data:l.data,"row-height":40,width:700,height:400,"footer-height":50,fixed:""},{footer:x(()=>[F]),_:1},8,["columns","data"])])}const{ref:r,defineComponent:s,computed:u}=v,c=s({setup(){const l=(i=10,m="column-",p)=>Array.from({length:i}).map((a,k)=>({...p,key:`${m}${k}`,dataKey:`${m}${k}`,title:`Column ${k}`,width:150})),y=(i,m=200,p="row-")=>Array.from({length:m}).map((a,k)=>i.reduce((h,D,_)=>(h[D.dataKey]=`Row ${k} - Col ${_}`,h),{id:`${p}${k}`,parentId:null})),o=l(10),e=y(o,200);return{columns:o,data:e}}});return{render:d,...c}}(),"render-demo-11":function(){const{createElementVNode:f,resolveComponent:g,withCtx:x,createVNode:w,openBlock:E,createElementBlock:C}=v,F=f("div",{class:"flex items-center justify-center h-100%"},"testEmpty",-1);function d(l,y){const o=g("n-table-v");return E(),C("div",null,[w(o,{columns:l.columns,data:[],"row-height":40,width:700,height:400,"footer-height":50},{empty:x(()=>[F]),_:1},8,["columns"])])}const{ref:r,defineComponent:s,computed:u}=v,c=s({setup(){return{columns:((o=10,e="column-",i)=>Array.from({length:o}).map((m,p)=>({...i,key:`${e}${p}`,dataKey:`${e}${p}`,title:`Column ${p}`,width:150})))(10)}}});return{render:d,...c}}(),"render-demo-12":function(){const{resolveComponent:f,createVNode:g,createElementVNode:x,withCtx:w,openBlock:E,createElementBlock:C}=v,F={class:"el-loading-mask",style:{display:"flex","align-items":"center","justify-content":"center"}};function d(l,y){const o=f("n-icon"),e=f("n-table-v");return E(),C("div",null,[g(e,{columns:l.columns,data:l.data,"row-height":40,width:700,height:400},{overlay:w(()=>[x("div",F,[g(o,{name:"icon-loading",class:"is-loading",size:26})])]),_:1},8,["columns","data"])])}const{ref:r,defineComponent:s,computed:u}=v,c=s({setup(){const l=(e=10,i="column-",m)=>Array.from({length:e}).map((p,a)=>({...m,key:`${i}${a}`,dataKey:`${i}${a}`,title:`Column ${a}`,width:150})),y=(e,i=200,m="row-")=>Array.from({length:i}).map((p,a)=>e.reduce((k,h,D)=>(k[h.dataKey]=`Row ${a} - Col ${D}`,k),{id:`${m}${a}`,parentId:null})),o=l(10);return y(o,200),{columns:o}}});return{render:d,...c}}(),"render-demo-13":function(){const{resolveComponent:f,createVNode:g,withCtx:x,createElementVNode:w,createTextVNode:E,openBlock:C,createElementBlock:F}=v,d={class:"mb-4 flex items-center"},r={class:"mb-4 flex items-center"},s={style:{height:"400px"}};function u(e,i){const m=f("n-input"),p=f("n-form-item"),a=f("n-button"),k=f("n-table-v"),h=f("n-auto-resizer");return C(),F("div",null,[w("div",d,[g(p,{label:"Scroll pixels",class:"mr-4"},{default:x(()=>[g(m,{modelValue:e.scrollDelta,"onUpdate:modelValue":i[0]||(i[0]=D=>e.scrollDelta=D)},null,8,["modelValue"])]),_:1}),g(p,{label:"Scroll rows"},{default:x(()=>[g(m,{modelValue:e.scrollRows,"onUpdate:modelValue":i[1]||(i[1]=D=>e.scrollRows=D)},null,8,["modelValue"])]),_:1})]),w("div",r,[g(a,{onClick:e.scrollByPixels},{default:x(()=>[E(" Scroll by pixels ")]),_:1},8,["onClick"]),g(a,{onClick:e.scrollByRows},{default:x(()=>[E(" Scroll by rows ")]),_:1},8,["onClick"])]),w("div",s,[g(h,null,{default:x(({height:D,width:_})=>[g(k,{ref:"tableRef",columns:e.columns,data:e.data,width:_,height:D,fixed:""},null,8,["columns","data","width","height"])]),_:1})])])}const{ref:c,defineComponent:l,computed:y}=v,o=l({setup(){const e=(B=10,q="column-",I)=>Array.from({length:B}).map((S,R)=>({...I,key:`${q}${R}`,dataKey:`${q}${R}`,title:`Column ${R}`,width:150})),i=(B,q=200,I="row-")=>Array.from({length:q}).map((S,R)=>B.reduce((V,N,z)=>(V[N.dataKey]=`Row ${R} - Col ${z}`,V),{id:`${I}${R}`,parentId:null})),m=e(10),p=i(m,200),a=c(),k=c(200),h=c(10);function D(){var B;(B=a.value)==null||B.scrollToTop(k.value)}function _(){var B;(B=a.value)==null||B.scrollToRow(h.value)}return{columns:m,scrollRows:h,data:p,scrollDelta:k,scrollByPixels:D,scrollByRows:_,tableRef:a}}});return{render:u,...o}}()}},Tn='{"title":"table v \u865A\u62DF\u5217\u8868\u7EC4\u4EF6","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u81EA\u52A8\u8C03\u6574\u5927\u5C0F","slug":"\u81EA\u52A8\u8C03\u6574\u5927\u5C0F"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3","slug":"\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3"},{"level":3,"title":"\u5E26\u72B6\u6001\u7684\u8868\u683C","slug":"\u5E26\u72B6\u6001\u7684\u8868\u683C"},{"level":3,"title":"\u8868\u683C\u884C\u7684\u7C98\u6027\u5E03\u5C40","slug":"\u8868\u683C\u884C\u7684\u7C98\u6027\u5E03\u5C40"},{"level":3,"title":"\u56FA\u5B9A\u5217\u8868\u683C","slug":"\u56FA\u5B9A\u5217\u8868\u683C"},{"level":3,"title":"\u53EF\u6392\u5E8F\u8868\u683C","slug":"\u53EF\u6392\u5E8F\u8868\u683C"},{"level":3,"title":"\u53D7\u63A7\u7684\u6392\u5E8F","slug":"\u53D7\u63A7\u7684\u6392\u5E8F"},{"level":3,"title":"\u6811\u5F62\u6570\u636E","slug":"\u6811\u5F62\u6570\u636E"},{"level":3,"title":"\u52A8\u6001\u9AD8\u5EA6","slug":"\u52A8\u6001\u9AD8\u5EA6"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u9875\u811A","slug":"\u81EA\u5B9A\u4E49\u9875\u811A"},{"level":3,"title":"\u81EA\u5B9A\u4E49\u7A7A\u5143\u7D20\u6E32\u67D3\u5668","slug":"\u81EA\u5B9A\u4E49\u7A7A\u5143\u7D20\u6E32\u67D3\u5668"},{"level":3,"title":"\u6D6E\u52A8\u906E\u7F69\u5C42","slug":"\u6D6E\u52A8\u906E\u7F69\u5C42"},{"level":3,"title":"\u624B\u52A8\u6EDA\u52A8","slug":"\u624B\u52A8\u6EDA\u52A8"},{"level":3,"title":"TableV \u53C2\u6570","slug":"tablev-\u53C2\u6570"},{"level":3,"title":"TableV \u63D2\u69FD","slug":"tablev-\u63D2\u69FD"},{"level":3,"title":"TableV \u4E8B\u4EF6","slug":"tablev-\u4E8B\u4EF6"},{"level":3,"title":"TableV \u65B9\u6CD5","slug":"tablev-\u65B9\u6CD5"},{"level":3,"title":"Column \u5C5E\u6027","slug":"column-\u5C5E\u6027"}],"relativePath":"components/table-v/index.md","lastUpdated":1685590067262}',O=K('<h1 id="table-v-\u865A\u62DF\u5217\u8868\u7EC4\u4EF6" tabindex="-1">table v \u865A\u62DF\u5217\u8868\u7EC4\u4EF6 <a class="header-anchor" href="#table-v-\u865A\u62DF\u5217\u8868\u7EC4\u4EF6" aria-hidden="true">#</a></h1><p>\u865A\u62DF\u5217\u8868\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u6570\u636E\u91CF\u8FC7\u5927\u53C8\u65E0\u9700\u7FFB\u9875\u65F6\uFF0C\u9632\u6B62\u9875\u9762\u5361\u987F\uFF0C\u4F7F\u7528\u865A\u62DF\u5217\u8868\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),L=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("850"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t("100%")]),n("span",{class:"token punctuation"},'"')])]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
  `),n("span",{class:"token comment"},`<!-- <n-my-table :attrList="attrList" :tableData="dataSource" :isAction="true" borderType="bordered">
    <template #action="scoped">
      <n-button type="text" @click="test(scoped)">\u6D4B\u8BD5</n-button>
    </template>
  </n-my-table> -->`),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"100000"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" data"),n("span",{class:"token punctuation"},","),t(" columns "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"}),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),H=K('<h3 id="\u81EA\u52A8\u8C03\u6574\u5927\u5C0F" tabindex="-1">\u81EA\u52A8\u8C03\u6574\u5927\u5C0F <a class="header-anchor" href="#\u81EA\u52A8\u8C03\u6574\u5927\u5C0F" aria-hidden="true">#</a></h3><p>\u5982\u679C\u60A8\u4E0D\u60F3\u624B\u52A8\u8BBE\u7F6E\u8868\u683C\u7684 <code>width</code> \u548C <code>height</code> \uFF0C\u53EF\u4EE5\u4F7F\u7528 <code>AutoResizer</code> \u7EC4\u4EF6\u5305\u88F9\u8868\u683C\u7EC4\u4EF6\uFF0C\u8FD9\u5C06\u4F1A\u81EA\u52A8\u66F4\u65B0\u8868\u683C\u7684\u5BBD\u5EA6\u548C\u9AD8\u5EA6\u3002 \u5C1D\u8BD5\u8C03\u6574\u60A8\u7684\u6D4F\u89C8\u5668\u5927\u5C0F\u6765\u770B\u770B\u5B83\u662F\u5982\u4F55\u5DE5\u4F5C\u7684\u3002</p><p>\u7531\u4E8E <code>AutoResizer</code> \u7EC4\u4EF6\u7684\u9ED8\u8BA4\u9AD8\u5EA6\u662F 100%\uFF0C \u6240\u4EE5\u8BF7\u786E\u4FDD \u8BE5\u7EC4\u4EF6\u7684\u7236\u5143\u7D20\u88AB\u8BBE\u7F6E\u4E86\u4E00\u4E2A\u56FA\u5B9A\u7684\u9AD8\u5EA6 \u4E5F\u53EF\u4EE5\u901A\u8FC7 \u8BBE\u7F6E <code>style</code> \u5C5E\u6027\u4E3A <code>AutoResizer</code> \u6307\u5B9A\u9AD8\u5EA6\u3002</p>',3),U=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 400px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-auto-resizer")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#default"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("{ height, width }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("width"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("height"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-auto-resizer")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("ts"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"1000"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" data"),n("span",{class:"token punctuation"},","),t(" columns "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"}),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),Q=n("h3",{id:"\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3",tabindex:"-1"},[t("\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3 "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3","aria-hidden":"true"},"#")],-1),J=n("p",null,"\u60A8\u53EF\u4EE5\u81EA\u7531\u5B9A\u5236\u8868\u683C\u5355\u5143\u683C\u7684\u6E32\u67D3\u5185\u5BB9\uFF0C\u4E0B\u9762\u662F\u4E00\u4E2A\u7B80\u5355\u4F8B\u5B50\u3002 Markdown \u9650\u5236\u8D5E\u4E0D\u80FD\u5C55\u793A\u8FD4\u56DE\u8282\u70B9\uFF0C\u5F85\u4FEE\u590D\u540E\u5C55\u793A",-1),W=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" id "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"dataGenerator"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"random-id-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),n("span",{class:"token operator"},"++"),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"date"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2020-10-1'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"fixed"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'right'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// cellRenderer: ({ cellData: date }) => {"),t(`
        `),n("span",{class:"token comment"},"//   return ("),t(`
        `),n("span",{class:"token comment"},'//     <n-tooltip content="test">'),t(`
        `),n("span",{class:"token comment"},'//       <span class="flex items-center">tooltip</span>'),t(`
        `),n("span",{class:"token comment"},"//     </n-tooltip>"),t(`
        `),n("span",{class:"token comment"},"//   );"),t(`
        `),n("span",{class:"token comment"},"// },"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token function-variable function"},"cellRenderer"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"cellData"),n("span",{class:"token operator"},":"),t(" name "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
          `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token number"},"666"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// cellRenderer: () => ("),t(`
        `),n("span",{class:"token comment"},"//   <>"),t(`
        `),n("span",{class:"token comment"},'//     <n-button size="small">Edit</n-button>'),t(`
        `),n("span",{class:"token comment"},'//     <n-button size="small" type="danger">'),t(`
        `),n("span",{class:"token comment"},"//       Delete"),t(`
        `),n("span",{class:"token comment"},"//     </n-button>"),t(`
        `),n("span",{class:"token comment"},"//   </>"),t(`
        `),n("span",{class:"token comment"},"// ),"),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),t("Array"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"length"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"200"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),t("dataGenerator"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" data"),n("span",{class:"token punctuation"},","),t(" columns "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"}),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),X=K('<h3 id="\u5E26\u72B6\u6001\u7684\u8868\u683C" tabindex="-1">\u5E26\u72B6\u6001\u7684\u8868\u683C <a class="header-anchor" href="#\u5E26\u72B6\u6001\u7684\u8868\u683C" aria-hidden="true">#</a></h3><p>\u53EF\u5C06\u8868\u683C\u5185\u5BB9 highlight \u663E\u793A\uFF0C\u65B9\u4FBF\u533A\u5206\u300C\u6210\u529F\u3001\u4FE1\u606F\u3001\u8B66\u544A\u3001\u5371\u9669\u300D\u7B49\u5185\u5BB9\u3002 \u53EF\u4EE5\u901A\u8FC7\u6307\u5B9A <code>Table</code> \u7EC4\u4EF6\u7684 <code>row-class-name</code> \u5C5E\u6027\u6765\u4E3A <code>Table</code> \u4E2D\u7684\u67D0\u4E00\u884C\u6DFB\u52A0 class\uFF0C \u8868\u660E\u8BE5\u884C\u5904\u4E8E\u67D0\u79CD\u72B6\u6001\u3002 \u6BCF 10 \u884C\u4F1A\u81EA\u52A8\u6DFB\u52A0 <code>bg-blue-200</code> \u7C7B\u540D\uFF0C\u6BCF 5 \u884C\u4F1A\u6DFB\u52A0 <code>bg-red-100</code> \u7C7B\u540D\u3002</p>',2),Y=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":row-class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("rowClass"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" id "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"dataGenerator"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"random-id-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),n("span",{class:"token operator"},"++"),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"date"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2020-10-1'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'date'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"fixed"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'left'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// cellRenderer: ({ cellData: date }) => <div>test</div>,"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// cellRenderer: ({ cellData: name }) => <ElTag>{name}</ElTag>,"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// cellRenderer: () => ("),t(`
        `),n("span",{class:"token comment"},"//   <>"),t(`
        `),n("span",{class:"token comment"},'//     <ElButton size="small">Edit</ElButton>'),t(`
        `),n("span",{class:"token comment"},'//     <ElButton size="small" type="danger">'),t(`
        `),n("span",{class:"token comment"},"//       Delete"),t(`
        `),n("span",{class:"token comment"},"//     </ElButton>"),t(`
        `),n("span",{class:"token comment"},"//   </>"),t(`
        `),n("span",{class:"token comment"},"// ),"),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"flexGrow"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),t("Array"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"length"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"200"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),t("dataGenerator"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"rowClass"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(" rowIndex "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("rowIndex "),n("span",{class:"token operator"},"%"),t(),n("span",{class:"token number"},"10"),t(),n("span",{class:"token operator"},"==="),t(),n("span",{class:"token number"},"5"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token string"},"'bg-red-100'"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"else"),t(),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("rowIndex "),n("span",{class:"token operator"},"%"),t(),n("span",{class:"token number"},"10"),t(),n("span",{class:"token operator"},"==="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token string"},"'bg-blue-200'"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(`
      `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token string"},"''"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" rowClass"),n("span",{class:"token punctuation"},","),t(" data "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".bg-blue-200"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" blue"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token selector"},".bg-red-100"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" red"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),Z=n("h3",{id:"\u8868\u683C\u884C\u7684\u7C98\u6027\u5E03\u5C40",tabindex:"-1"},[t("\u8868\u683C\u884C\u7684\u7C98\u6027\u5E03\u5C40 "),n("a",{class:"header-anchor",href:"#\u8868\u683C\u884C\u7684\u7C98\u6027\u5E03\u5C40","aria-hidden":"true"},"#")],-1),nn=n("p",null,[t("\u60A8\u53EF\u4EE5\u7B80\u5355\u5730\u4F7F\u7528 "),n("code",null,"fixed-data"),t(" \u5C5E\u6027\u6765\u5B9E\u73B0\u5C06\u67D0\u4E9B\u884C\u56FA\u5B9A\u5230\u8868\u683C\u7684\u5934\u90E8\u3002")],-1),tn=n("p",null,"\u60A8\u53EF\u4EE5\u4F7F\u7528\u6EDA\u52A8\u4E8B\u4EF6\u52A8\u6001\u5730\u8BBE\u7F6E\u7C98\u6027\u884C\uFF0C\u89C1\u6B64\u793A\u4F8B",-1),an=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(`
    `),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tableData"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":fixed-data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("fixedData"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":row-class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("rowClass"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},"fixed"),t(`
    `),n("span",{class:"token attr-name"},"@scroll"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onScroll"),n("span",{class:"token punctuation"},'"')]),t(`
  `),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"rowClass"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(" rowIndex "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("rowIndex "),n("span",{class:"token operator"},"<"),t(),n("span",{class:"token number"},"0"),t(),n("span",{class:"token operator"},"||"),t(),n("span",{class:"token punctuation"},"("),t("rowIndex "),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"%"),t(),n("span",{class:"token number"},"5"),t(),n("span",{class:"token operator"},"==="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token string"},"'sticky-row'"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" stickyIndex "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" fixedData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"computed"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(" data"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"slice"),n("span",{class:"token punctuation"},"("),t("stickyIndex"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},","),t(" stickyIndex"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"+"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" tableData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"computed"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"return"),t(" data"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"slice"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onScroll"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(" scrollTop "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      stickyIndex`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" Math"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"floor"),n("span",{class:"token punctuation"},"("),t("scrollTop "),n("span",{class:"token operator"},"/"),t(),n("span",{class:"token number"},"250"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"*"),t(),n("span",{class:"token number"},"5"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" rowClass"),n("span",{class:"token punctuation"},","),t(" tableData"),n("span",{class:"token punctuation"},","),t(" onScroll"),n("span",{class:"token punctuation"},","),t(" fixedData "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),sn=K('<h3 id="\u56FA\u5B9A\u5217\u8868\u683C" tabindex="-1">\u56FA\u5B9A\u5217\u8868\u683C <a class="header-anchor" href="#\u56FA\u5B9A\u5217\u8868\u683C" aria-hidden="true">#</a></h3><p>\u51FA\u4E8E\u67D0\u4E9B\u539F\u56E0\uFF0C\u60A8\u53EF\u80FD\u4F1A\u8BA9\u4E00\u4E9B\u5217\u56FA\u5B9A\u5728\u8868\u683C\u7684\u5DE6\u4FA7\u548C\u53F3\u4FA7\u3002\u60A8\u53EF\u4EE5\u901A\u8FC7\u4E3A\u8868\u683C\u6DFB\u52A0\u7279\u6B8A\u5C5E\u6027\u6765\u5B9E\u73B0\u3002</p><p>\u60A8\u53EF\u4EE5\u8BBE\u7F6E\u8BE5\u884C\u7684 <code>fixed</code> \u5C5E\u6027\u4E3A <code>true</code> \uFF08\u4EE3\u8868<code>left</code>\uFF09\u3001<code>left</code> \u6216 <code>right</code></p>',3),on=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":sort-by"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("sortBy"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token attr-name"},"@column-sort"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onSort"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" sortBy "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("any"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'column-0'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"order"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'asc'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onSort"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token literal-property property"},"_sortBy"),n("span",{class:"token operator"},":"),t(" any")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      data `),n("span",{class:"token operator"},"="),t(" data"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reverse"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      sortBy`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" _sortBy"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("fixed "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("fixed "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'left'"),n("span",{class:"token punctuation"},";"),t(`
    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"9"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("fixed "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'right'"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"for"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token keyword"},"let"),t(" i "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},";"),t(" i "),n("span",{class:"token operator"},"<"),t(),n("span",{class:"token number"},"3"),n("span",{class:"token punctuation"},";"),t(" i"),n("span",{class:"token operator"},"++"),n("span",{class:"token punctuation"},")"),t(" columns"),n("span",{class:"token punctuation"},"["),t("i"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("sortable "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" sortBy"),n("span",{class:"token punctuation"},","),t(" onSort "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),en=n("h3",{id:"\u53EF\u6392\u5E8F\u8868\u683C",tabindex:"-1"},[t("\u53EF\u6392\u5E8F\u8868\u683C "),n("a",{class:"header-anchor",href:"#\u53EF\u6392\u5E8F\u8868\u683C","aria-hidden":"true"},"#")],-1),pn=n("p",null,"\u60A8\u53EF\u4EE5\u4F7F\u7528\u6392\u5E8F\u72B6\u6001\u6765\u5BF9\u8868\u683C\u8FDB\u884C\u6392\u5E8F\u3002",-1),un=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":sort-by"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("sortState"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token attr-name"},"@column-sort"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onSort"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"let"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("sortable "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" sortState "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("any"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'column-0'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"order"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'asc'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onSort"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token literal-property property"},"sortBy"),n("span",{class:"token operator"},":"),t(" any")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),t("sortBy"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      data `),n("span",{class:"token operator"},"="),t(" data"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reverse"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      sortState`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" sortBy"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" onSort"),n("span",{class:"token punctuation"},","),t(" sortState "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),cn=n("h3",{id:"\u53D7\u63A7\u7684\u6392\u5E8F",tabindex:"-1"},[t("\u53D7\u63A7\u7684\u6392\u5E8F "),n("a",{class:"header-anchor",href:"#\u53D7\u63A7\u7684\u6392\u5E8F","aria-hidden":"true"},"#")],-1),ln=n("p",null,"\u60A8\u53EF\u4EE5\u5728\u9700\u8981\u65F6\u5B9A\u4E49\u591A\u4E2A\u53EF\u6392\u5E8F\u7684\u5217\u3002 \u8BF7\u8BB0\u4F4F\uFF0C\u5F53\u60A8\u5728\u5B9A\u4E49\u4E86\u591A\u4E2A\u53EF\u6392\u5E8F\u7684\u5217\u65F6\uFF0C UI \u53EF\u80FD\u4F1A\u663E\u5F97\u6709\u4E9B\u5947\u602A\uFF0C\u56E0\u4E3A\u7528\u6237\u4E0D\u77E5\u9053\u54EA\u4E00\u5217\u88AB\u6392\u5E8F\u3002",-1),rn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-model:"),t("sort-state")]),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("sortState"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token attr-name"},"@column-sort"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onSort"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("sortable "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`
    columns`),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("sortable "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" sortState "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token string-property property"},"'column-0'"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'desc'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token string-property property"},"'column-1'"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'asc'"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onSort"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(" key"),n("span",{class:"token punctuation"},","),t(" order "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      sortState`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},"["),t("key"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(" order"),n("span",{class:"token punctuation"},";"),t(`
      data`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" data"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reverse"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" onSort"),n("span",{class:"token punctuation"},","),t(" sortState "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),kn=n("h3",{id:"\u6811\u5F62\u6570\u636E",tabindex:"-1"},[t("\u6811\u5F62\u6570\u636E "),n("a",{class:"header-anchor",href:"#\u6811\u5F62\u6570\u636E","aria-hidden":"true"},"#")],-1),dn=n("p",null,"\u865A\u62DF\u5316\u8868\u683C\u5F53\u7136\u53EF\u4EE5\u6E32\u67D3\u6811\u5F62\u6570\u636E\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u70B9\u51FB\u7BAD\u5934\u56FE\u6807\u6765\u5C55\u5F00/\u6298\u53E0\u6811\u8282\u70B9\u3002",-1),mn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(`
    `),n("span",{class:"token attr-name"},[n("span",{class:"token namespace"},"v-model:"),t("expanded-row-keys")]),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("expandedRowKeys"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("treeData"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":expand-column-key"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("expandColumnKey"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},"fixed"),t(`
    `),n("span",{class:"token attr-name"},"@row-expand"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onRowExpanded"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},"@expanded-rows-change"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onExpandedRowsChange"),n("span",{class:"token punctuation"},'"')]),t(`
  `),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"let"),t(" fixed"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("columnIndex "),n("span",{class:"token operator"},"<"),t(),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},")"),t(" fixed "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'left'"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("columnIndex "),n("span",{class:"token operator"},">"),t(),n("span",{class:"token number"},"8"),n("span",{class:"token punctuation"},")"),t(" fixed "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'right'"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token operator"},"..."),t("column"),n("span",{class:"token punctuation"},","),t(" fixed "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" expandColumnKey "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-0'"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token comment"},"// add some sub items"),t(`
    `),n("span",{class:"token keyword"},"for"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token keyword"},"let"),t(" i "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},";"),t(" i "),n("span",{class:"token operator"},"<"),t(),n("span",{class:"token number"},"50"),n("span",{class:"token punctuation"},";"),t(" i"),n("span",{class:"token operator"},"++"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      data`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"push"),n("span",{class:"token punctuation"},"("),t(`
        `),n("span",{class:"token punctuation"},"{"),t(`
          `),n("span",{class:"token operator"},"..."),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"},"-sub-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(" data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"["),t("expandColumnKey"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Sub "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"{"),t(`
          `),n("span",{class:"token operator"},"..."),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"},"-sub-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(" data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"["),t("expandColumnKey"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Sub "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"{"),t(`
          `),n("span",{class:"token operator"},"..."),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"},"-sub-sub-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("data"),n("span",{class:"token punctuation"},"["),n("span",{class:"token number"},"2"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"},"-sub-"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"["),t("expandColumnKey"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Sub-Sub "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("i"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token punctuation"},"}"),t(`
      `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"unflatten"),n("span",{class:"token punctuation"},"("),t("data"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateData"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" rootId "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(" dataKey "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'id'"),n("span",{class:"token punctuation"},","),t(" parentKey "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'parentId'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token literal-property property"},"tree"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"const"),t(" childrenMap "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"{"),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

      `),n("span",{class:"token keyword"},"for"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token keyword"},"const"),t(" datum "),n("span",{class:"token keyword"},"of"),t(" data"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"const"),t(" item "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token operator"},"..."),t("datum "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token keyword"},"const"),t(" id "),n("span",{class:"token operator"},"="),t(" item"),n("span",{class:"token punctuation"},"["),t("dataKey"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token keyword"},"const"),t(" parentId "),n("span",{class:"token operator"},"="),t(" item"),n("span",{class:"token punctuation"},"["),t("parentKey"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`

        `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("Array"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"isArray"),n("span",{class:"token punctuation"},"("),t("item"),n("span",{class:"token punctuation"},"."),t("children"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
          childrenMap`),n("span",{class:"token punctuation"},"["),t("id"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(" item"),n("span",{class:"token punctuation"},"."),t("children"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"concat"),n("span",{class:"token punctuation"},"("),t("childrenMap"),n("span",{class:"token punctuation"},"["),t("id"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"||"),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"else"),t(),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token operator"},"!"),t("childrenMap"),n("span",{class:"token punctuation"},"["),t("id"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
          childrenMap`),n("span",{class:"token punctuation"},"["),t("id"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),t(`
        item`),n("span",{class:"token punctuation"},"."),t("children "),n("span",{class:"token operator"},"="),t(" childrenMap"),n("span",{class:"token punctuation"},"["),t("id"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`

        `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("parentId "),n("span",{class:"token operator"},"!=="),t(),n("span",{class:"token keyword"},"undefined"),t(),n("span",{class:"token operator"},"&&"),t(" parentId "),n("span",{class:"token operator"},"!=="),t(" rootId"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
          `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token operator"},"!"),t("childrenMap"),n("span",{class:"token punctuation"},"["),t("parentId"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),t(" childrenMap"),n("span",{class:"token punctuation"},"["),t("parentId"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
          childrenMap`),n("span",{class:"token punctuation"},"["),t("parentId"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"push"),n("span",{class:"token punctuation"},"("),t("item"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"else"),t(),n("span",{class:"token punctuation"},"{"),t(`
          tree`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"push"),n("span",{class:"token punctuation"},"("),t("item"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
        `),n("span",{class:"token punctuation"},"}"),t(`
      `),n("span",{class:"token punctuation"},"}"),t(`

      `),n("span",{class:"token keyword"},"return"),t(" tree"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" treeData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"computed"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token function"},"unflatten"),n("span",{class:"token punctuation"},"("),t("data"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" expandedRowKeys "),n("span",{class:"token operator"},"="),t(" ref"),n("span",{class:"token operator"},"<"),t("string"),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onRowExpanded"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(" expanded "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),n("span",{class:"token string"},"'Expanded:'"),n("span",{class:"token punctuation"},","),t(" expanded"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onExpandedRowsChange"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"expandedKeys"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      console`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"log"),n("span",{class:"token punctuation"},"("),t("expandedKeys"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" treeData"),n("span",{class:"token punctuation"},","),t(" onExpandedRowsChange"),n("span",{class:"token punctuation"},","),t(" onRowExpanded"),n("span",{class:"token punctuation"},","),t(" expandedRowKeys"),n("span",{class:"token punctuation"},","),t(" expandColumnKey "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),gn=n("h3",{id:"\u52A8\u6001\u9AD8\u5EA6",tabindex:"-1"},[t("\u52A8\u6001\u9AD8\u5EA6 "),n("a",{class:"header-anchor",href:"#\u52A8\u6001\u9AD8\u5EA6","aria-hidden":"true"},"#")],-1),yn=n("p",null,[t("\u865A\u62DF\u8868\u683C\u4E5F\u652F\u6301\u6E32\u67D3\u52A8\u6001\u9AD8\u5EA6\u7684\u5355\u5143\u683C\u3002\u5F53\u4E0D\u77E5\u9053\u4E00\u6761\u6570\u636E\u5177\u4F53\u7684\u5C55\u793A\u9AD8\u5EA6\u65F6\uFF0C\u4E0D\u59A8\u4F7F\u7528\u52A8\u6001\u6E32\u67D3\u9AD8\u5EA6\u6765\u89E3\u51B3\u3002 \u901A\u8FC7\u8BBE\u7F6E\u9884\u4F30\u884C\u9AD8\u5EA6 "),n("code",null,"estimated-row-height"),t(" \u6765\u542F\u7528\u6B64 \u529F\u80FD\uFF0C\u4F30\u8BA1\u503C\u8D8A\u63A5\u8FD1\uFF0C\u6E32\u67D3\u6548\u679C\u5C06\u4F1A\u8D8A\u5E73\u6ED1\u3002")],-1),fn=n("p",null,"\u6BCF\u884C\u7684\u5B9E\u9645\u6E32\u67D3\u9AD8\u5EA6\u662F\u5728\u6E32\u67D3\u65F6\u52A8\u6001\u6D4B\u91CF\u7684\uFF0C \u5982\u679C\u60A8\u5C1D\u8BD5\u6E32\u67D3\u5927\u91CF\u6570\u636E\uFF0C\u6E32\u67D3\u754C\u9762 \u53EF\u80FD \u4F1A\u51FA\u73B0\u6296\u52A8\u3002",-1),xn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(`
    `),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":sort-by"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("sort"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":estimated-row-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("80"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(`
    `),n("span",{class:"token attr-name"},"fixed"),t(`
    `),n("span",{class:"token attr-name"},"@column-sort"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("onColumnSort"),n("span",{class:"token punctuation"},'"')]),t(`
  `),n("span",{class:"token punctuation"},"/>")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" longText "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'Quaerat ipsam necessitatibus eum quibusdam est id voluptatem cumque mollitia.'"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" midText "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'Corrupti doloremque a quos vero delectus consequatur.'"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" shortText "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'Eius optio fugiat.'"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" textList "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),t("shortText"),n("span",{class:"token punctuation"},","),t(" midText"),n("span",{class:"token punctuation"},","),t(" longText"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token comment"},"// generate random number in range 0 to 2"),t(`

    `),n("span",{class:"token keyword"},"let"),t(" id "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"dataGenerator"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"random:"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),n("span",{class:"token operator"},"++"),t("id"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"name"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Tom'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"date"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'2016-05-03'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token literal-property property"},"description"),n("span",{class:"token operator"},":"),t(" textList"),n("span",{class:"token punctuation"},"["),t("Math"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"floor"),n("span",{class:"token punctuation"},"("),t("Math"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"random"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"*"),t(),n("span",{class:"token number"},"3"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'id'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Id'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'id'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"sortable"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token boolean"},"true"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"fixed"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'left'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token function-variable function"},"cellRenderer"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"cellData"),n("span",{class:"token operator"},":"),t(" name "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'description'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Description'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'description'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token function-variable function"},"cellRenderer"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"cellData"),n("span",{class:"token operator"},":"),t(" description "),n("span",{class:"token punctuation"},"}")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token string"},"'description'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'Operations'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token function-variable function"},"cellRenderer"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token string"},"'test'"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token comment"},"// <>"),t(`
        `),n("span",{class:"token comment"},'//   <ElButton size="small">Edit</ElButton>'),t(`
        `),n("span",{class:"token comment"},'//   <ElButton size="small" type="danger">'),t(`
        `),n("span",{class:"token comment"},"//     Delete"),t(`
        `),n("span",{class:"token comment"},"//   </ElButton>"),t(`
        `),n("span",{class:"token comment"},"// </>"),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"align"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'center'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"length"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"200"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),t(`
        `),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),t("dataGenerator"),n("span",{class:"token punctuation"},")"),t(`
        `),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"sort"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("a"),n("span",{class:"token punctuation"},","),t(" b")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),t("a"),n("span",{class:"token punctuation"},"."),t("name "),n("span",{class:"token operator"},">"),t(" b"),n("span",{class:"token punctuation"},"."),t("name "),n("span",{class:"token operator"},"?"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token operator"},":"),t(),n("span",{class:"token operator"},"-"),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),t(`
    `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" sort "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'name'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token literal-property property"},"order"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'asc'"),t(),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"onColumnSort"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},"sortBy"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"const"),t(" order "),n("span",{class:"token operator"},"="),t(" sortBy"),n("span",{class:"token punctuation"},"."),t("order "),n("span",{class:"token operator"},"==="),t(),n("span",{class:"token string"},"'asc'"),t(),n("span",{class:"token operator"},"?"),t(),n("span",{class:"token number"},"1"),t(),n("span",{class:"token operator"},":"),t(),n("span",{class:"token operator"},"-"),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token keyword"},"const"),t(" dataClone "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"["),n("span",{class:"token operator"},"..."),t("data"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},";"),t(`
      dataClone`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"sort"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("a"),n("span",{class:"token punctuation"},","),t(" b")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),t("a"),n("span",{class:"token punctuation"},"["),t("sortBy"),n("span",{class:"token punctuation"},"."),t("key"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},">"),t(" b"),n("span",{class:"token punctuation"},"["),t("sortBy"),n("span",{class:"token punctuation"},"."),t("key"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"?"),t(" order "),n("span",{class:"token operator"},":"),t(),n("span",{class:"token operator"},"-"),t("order"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      sort`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" sortBy"),n("span",{class:"token punctuation"},";"),t(`
      data`),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"="),t(" dataClone"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" onColumnSort"),n("span",{class:"token punctuation"},","),t(" sort "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),hn=n("h3",{id:"\u81EA\u5B9A\u4E49\u9875\u811A",tabindex:"-1"},[t("\u81EA\u5B9A\u4E49\u9875\u811A "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u9875\u811A","aria-hidden":"true"},"#")],-1),wn=n("p",null,"\u81EA\u5B9A\u4E49\u8868\u683C footer\uFF0C \u901A\u5E38\u7528\u6765\u5C55\u793A\u4E00\u4E9B\u6C47\u603B\u6570\u636E\u548C\u4FE1\u606F\u3002",-1),Cn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":row-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("40"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":footer-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("50"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#footer"),t(`
      `),n("span",{class:"token punctuation"},">")]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(`
        `),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("flex items-center"),n("span",{class:"token punctuation"},'"')]),t(`
        `),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t(`
          justify-content: center;
          height: 100%;
          background-color: #447DFD;
        `),n("span",{class:"token punctuation"},'"')])]),t(`
      `),n("span",{class:"token punctuation"},">")]),t(`
        Display a message in the footer
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-table-v")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" data "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),En=n("h3",{id:"\u81EA\u5B9A\u4E49\u7A7A\u5143\u7D20\u6E32\u67D3\u5668",tabindex:"-1"},[t("\u81EA\u5B9A\u4E49\u7A7A\u5143\u7D20\u6E32\u67D3\u5668 "),n("a",{class:"header-anchor",href:"#\u81EA\u5B9A\u4E49\u7A7A\u5143\u7D20\u6E32\u67D3\u5668","aria-hidden":"true"},"#")],-1),Fn=n("p",null,"\u6E32\u67D3\u81EA\u5B9A\u4E49\u7684\u7A7A\u5143\u7D20",-1),vn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("[]"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":row-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("40"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":footer-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("50"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#empty"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("flex items-center justify-center h-100%"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("testEmpty"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-table-v")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),bn=n("h3",{id:"\u6D6E\u52A8\u906E\u7F69\u5C42",tabindex:"-1"},[t("\u6D6E\u52A8\u906E\u7F69\u5C42 "),n("a",{class:"header-anchor",href:"#\u6D6E\u52A8\u906E\u7F69\u5C42","aria-hidden":"true"},"#")],-1),An=n("p",null,"\u5F53\u60A8\u60F3\u8981\u663E\u793A\u52A0\u8F7D\u6307\u793A\u5668\u4E4B\u7C7B\u7684\u6D6E\u52A8\u5143\u7D20\uFF0C\u53EF\u4EE5\u901A\u8FC7\u6E32\u67D3\u4E00\u4E2A\u6D6E\u52A8\u5728\u8868\u683C\u4E4B\u4E0A\u7684\u906E\u7F69\u5C42\u6765\u5B9E\u73B0\u3002",-1),Dn=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":row-height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("40"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("700"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("400"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#overlay"),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("el-loading-mask"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" center")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-icon")]),t(),n("span",{class:"token attr-name"},"name"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("icon-loading"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("is-loading"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":size"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("26"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-table-v")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".example-showcase .nancalui-table-v__overlay"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"z-index"),n("span",{class:"token punctuation"},":"),t(" 9"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),Bn=K('<h3 id="\u624B\u52A8\u6EDA\u52A8" tabindex="-1">\u624B\u52A8\u6EDA\u52A8 <a class="header-anchor" href="#\u624B\u52A8\u6EDA\u52A8" aria-hidden="true">#</a></h3><p>\u4F7F\u7528 Table V \u66B4\u9732\u7684\u65B9\u6CD5\u8FDB\u884C\u624B\u52A8\u6216\u7F16\u7A0B\u5F0F\u6EDA\u52A8\u6307\u5B9A\u504F\u79FB\u6216\u884C\u3002</p><p><code>scrollToRow</code> \u7684\u7B2C\u4E8C\u4E2A\u53C2\u6570\u4EE3\u8868\u6EDA\u52A8\u7B56\u7565\uFF0C\u8BA1\u7B97\u4E86\u8981\u6EDA\u52A8\u7684\u4F4D\u7F6E\uFF0C\u5176\u9ED8\u8BA4\u503C\u662F <code>auto\u3002</code> \u5982\u679C\u4F60\u60F3\u8981\u8868\u683C\u6EDA\u52A8\u5230\u67D0\u4E2A\u7279\u5B9A\u4F4D\u7F6E\uFF0C\u53EF\u4EE5\u989D\u5916\u914D\u7F6E\u3002 \u53EF\u7528\u7684\u9009\u9879\u662F <code>&quot;auto&quot; | &quot;center&quot; | &quot;end&quot; | &quot;start&quot; | &quot;smart&quot;</code></p><p><code>smart</code> <code>\u548Cauto</code> \u4E4B\u95F4\u7684\u533A\u522B\u662F\uFF0C <code>auto</code> \u662F <code>smart</code> \u6EDA\u52A8\u7B56\u7565\u7684\u5B50\u96C6\u3002</p>',4),_n=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mb-4 flex items-center"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-form-item")]),t(),n("span",{class:"token attr-name"},"label"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Scroll pixels"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mr-4"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-input")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scrollDelta"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-form-item")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-form-item")]),t(),n("span",{class:"token attr-name"},"label"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("Scroll rows"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-input")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scrollRows"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-form-item")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("mb-4 flex items-center"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scrollByPixels"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(" Scroll by pixels "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("scrollByRows"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(" Scroll by rows "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token special-attr"},[n("span",{class:"token attr-name"},"style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),n("span",{class:"token value css language-css"},[n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 400px")]),n("span",{class:"token punctuation"},'"')])]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-auto-resizer")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),t(),n("span",{class:"token attr-name"},"#default"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("{ height, width }"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
        `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-table-v")]),t(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tableRef"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":columns"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("columns"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":data"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("data"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":width"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("width"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":height"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("height"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"fixed"),t(),n("span",{class:"token punctuation"},"/>")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-auto-resizer")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),t(),n("span",{class:"token attr-name"},"lang"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("tsx"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" generateColumns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'column-'"),n("span",{class:"token punctuation"},","),t(" props"),n("span",{class:"token operator"},"?"),n("span",{class:"token operator"},":"),t(" any"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token operator"},"..."),t("props"),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"key"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"dataKey"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"title"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Column "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
        `),n("span",{class:"token literal-property property"},"width"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token number"},"150"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" generateData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token operator"},":"),t(" ReturnType"),n("span",{class:"token operator"},"<"),n("span",{class:"token keyword"},"typeof"),t(" generateColumns"),n("span",{class:"token operator"},">"),n("span",{class:"token punctuation"},","),t(" length "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},","),t(" prefix "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token string"},"'row-'"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(`
      Array`),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"from"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(" length "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"map"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("_"),n("span",{class:"token punctuation"},","),t(" rowIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token keyword"},"return"),t(" columns"),n("span",{class:"token punctuation"},"."),n("span",{class:"token function"},"reduce"),n("span",{class:"token punctuation"},"("),t(`
          `),n("span",{class:"token punctuation"},"("),n("span",{class:"token parameter"},[t("rowData"),n("span",{class:"token punctuation"},","),t(" column"),n("span",{class:"token punctuation"},","),t(" columnIndex")]),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
            rowData`),n("span",{class:"token punctuation"},"["),t("column"),n("span",{class:"token punctuation"},"."),t("dataKey"),n("span",{class:"token punctuation"},"]"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token string"},"Row "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token string"}," - Col "),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("columnIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},";"),t(`
            `),n("span",{class:"token keyword"},"return"),t(" rowData"),n("span",{class:"token punctuation"},";"),t(`
          `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"{"),t(`
            `),n("span",{class:"token literal-property property"},"id"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token template-string"},[n("span",{class:"token template-punctuation string"},"`"),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("prefix"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token interpolation"},[n("span",{class:"token interpolation-punctuation punctuation"},"${"),t("rowIndex"),n("span",{class:"token interpolation-punctuation punctuation"},"}")]),n("span",{class:"token template-punctuation string"},"`")]),n("span",{class:"token punctuation"},","),t(`
            `),n("span",{class:"token literal-property property"},"parentId"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token keyword"},"null"),n("span",{class:"token punctuation"},","),t(`
          `),n("span",{class:"token punctuation"},"}"),t(`
        `),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"const"),t(" columns "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateColumns"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" data "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"generateData"),n("span",{class:"token punctuation"},"("),t("columns"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" tableRef "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" scrollDelta "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"200"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" scrollRows "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"10"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"scrollByPixels"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      tableRef`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"?."),n("span",{class:"token function"},"scrollToTop"),n("span",{class:"token punctuation"},"("),t("scrollDelta"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"function"),t(),n("span",{class:"token function"},"scrollByRows"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
      tableRef`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"?."),n("span",{class:"token function"},"scrollToRow"),n("span",{class:"token punctuation"},"("),t("scrollRows"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" columns"),n("span",{class:"token punctuation"},","),t(" scrollRows"),n("span",{class:"token punctuation"},","),t(" data"),n("span",{class:"token punctuation"},","),t(" scrollDelta"),n("span",{class:"token punctuation"},","),t(" scrollByPixels"),n("span",{class:"token punctuation"},","),t(" scrollByRows"),n("span",{class:"token punctuation"},","),t(" tableRef "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),$n=K('<h3 id="tablev-\u53C2\u6570" tabindex="-1">TableV \u53C2\u6570 <a class="header-anchor" href="#tablev-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">cache</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">2</td><td style="text-align:left;">\u4E3A\u4E86\u66F4\u597D\u7684\u6E32\u67D3\u6548\u679C\u9884\u5148\u591A\u52A0\u8F7D\u7684\u884C\u6570\u636E</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">estimated-row-height</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u6E32\u67D3\u52A8\u6001\u7684\u5355\u5143\u683C\u7684\u9884\u4F30\u9AD8\u5EA6\u9694</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">header-class</td><td style="text-align:left;"><code>String/Function&lt;HeaderClassGetter&gt;</code></td><td style="text-align:left;">-</td><td style="text-align:left;">header \u90E8\u5206\u7684\u81EA\u5B9A\u4E49 class \u540D 60px</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">header-props</td><td style="text-align:left;"><code>Object/Function&lt;HeaderPropsGetter&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">header \u90E8\u5206\u7684\u81EA\u5B9A\u4E49 props \u540D\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">header-cell-props</td><td style="text-align:left;"><code>Object/Function&lt;HeaderCellPropsGetter&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">header cell \u90E8\u5206\u7684\u81EA\u5B9A\u4E49 props \u540D\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">header-height</td><td style="text-align:left;"><code>Number/Array&lt;Number&gt;</code></td><td style="text-align:left;">50</td><td style="text-align:left;">header \u90E8\u5206\u7684\u9AD8\u5EA6\u3002\u5F53\u4F20\u5165\u6570\u7EC4\u65F6, \u5C06\u4F1A\u6E32\u67D3\u548C\u6570\u7EC4\u957F\u5EA6\u4E00\u6837\u591A\u7684 header \u884C\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">table-height</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8868\u683C\u9AD8\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">footer-height</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">0</td><td style="text-align:left;">footer \u90E8\u5206\u7684\u9AD8\u5EA6\uFF0C\u5F53\u4F20\u5165\u503C\u65F6\uFF0C\u8FD9\u90E8\u5206\u5C06\u88AB\u8BA1\u7B97\u5165 table \u7684\u9AD8\u5EA6\u91CC</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-class</td><td style="text-align:left;"><code>String/Function&lt;RowClassGetter&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">row wrapper \u90E8\u5206\u7684\u81EA\u5B9A\u4E49 class \u540D\u90E8</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-key</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u6BCF\u884C\u7684 key \u503C\uFF0C\u5982\u679C\u4E0D\u63D0\u4F9B\uFF0C\u5C06\u4F7F\u7528\u7D22\u5F15 index \u4EE3\u66FF</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-props</td><td style="text-align:left;"><code>Object/Function&lt;RowPropsGetter&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">row component \u90E8\u5206\u7684\u81EA\u5B9A\u4E49 class \u540D</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-height</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">50</td><td style="text-align:left;">\u6BCF\u884C\u7684\u9AD8\u5EA6, \u7528\u4E8E\u8BA1\u7B97\u8868\u7684\u603B\u9AD8\u5EA6&#39;auto&#39;</td><td style="text-align:left;"><a href="#%E8%A1%A8%E6%A0%BC%E6%A0%B7%E5%BC%8F">\u8868\u683C\u6837\u5F0F</a></td></tr><tr><td style="text-align:left;">cell-props</td><td style="text-align:left;"><code>Object/Function&lt;CellPropsGetter&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u6BCF\u4E2A\u5355\u5143\u683C cell \u7684\u81EA\u5B9A\u4E49 props (\u9664\u4E86 header cell \u4EE5\u5916)</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">columns</td><td style="text-align:left;"><code>Array&lt;Column&gt;</code></td><td style="text-align:left;">&#39;&#39;</td><td style="text-align:left;">\u5217 column \u7684\u914D\u7F6E\u6570\u7EC4</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">data</td><td style="text-align:left;"><code>Array&lt;Data&gt;</code></td><td style="text-align:left;">[]</td><td style="text-align:left;">\u8981\u5728\u8868\u4E2D\u6E32\u67D3\u7684\u6570\u636E\u6570\u7EC4</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">fixed-data</td><td style="text-align:left;"><code>Array&lt;Data&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u6E32\u67D3\u884C\u5728\u8868\u683C\u4E3B\u5185\u5BB9\u4E0A\u65B9\u548C header \u4E0B\u65B9\u533A\u57DF\u7684\u6570\u636E</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">expanded-row-keys</td><td style="text-align:left;"><code>Array&lt;KeyType&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u5B58\u653E\u884C\u5C55\u5F00\u72B6\u6001\u7684 key \u7684\u6570\u7EC4\uFF0C\u53EF\u4EE5\u548C <code>v-model</code> \u642D\u914D\u4F7F\u7528</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">default-expanded-row-keys</td><td style="text-align:left;"><code>Array&lt;KeyType&gt;</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u9ED8\u8BA4\u5C55\u5F00\u7684\u884C\u7684 key \u7684\u6570\u7EC4, \u8FD9\u4E2A\u6570\u636E\u4E0D\u662F\u54CD\u5E94\u5F0F\u7684</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">class</td><td style="text-align:left;"><code>String/Array/Object</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u8868\u683C\u7684\u7C7B\u540D\u79F0\uFF0C\u5C06\u5E94\u7528\u4E8E\u8868\u683C\u7684\u5168\u90E8\u7684\u4E09\u4E2A\u90E8\u5206 (\u5DE6\u3001\u53F3\u3001\u4E3B)</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">width *</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u8868\u7684\u5BBD\u5EA6\uFF0C\u5FC5\u586B\u5B9A</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">height *</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u8868\u7684\u9AD8\u5EA6\uFF0C\u5FC5\u586B\u5B9A</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">max-height</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u8868\u683C\u7684\u6700\u5927\u9AD8\u5EA6</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">sort-by</td><td style="text-align:left;"><code>Object&lt;SortBy&gt;</code></td><td style="text-align:left;">{}</td><td style="text-align:left;">\u6392\u5E8F\u65B9\u5F0F</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">sort-state</td><td style="text-align:left;"><code>Object&lt;SortState&gt;</code></td><td style="text-align:left;">undefined</td><td style="text-align:left;">\u591A\u4E2A\u6392\u5E8F</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="tablev-\u63D2\u69FD" tabindex="-1">TableV \u63D2\u69FD <a class="header-anchor" href="#tablev-\u63D2\u69FD" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u63D2\u69FD\u540D</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u53C2\u6570</th></tr></thead><tbody><tr><td style="text-align:left;">cell</td><td style="text-align:left;"></td><td style="text-align:left;">CellSlotProps</td></tr><tr><td style="text-align:left;">header</td><td style="text-align:left;"></td><td style="text-align:left;">HeaderSlotProps</td></tr><tr><td style="text-align:left;">header-cell</td><td style="text-align:left;"></td><td style="text-align:left;">HeaderCellSlotProps</td></tr><tr><td style="text-align:left;">row</td><td style="text-align:left;"></td><td style="text-align:left;">RowSlotProps</td></tr><tr><td style="text-align:left;">footer</td><td style="text-align:left;"></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">empty</td><td style="text-align:left;"></td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">overlay</td><td style="text-align:left;"></td><td style="text-align:left;"></td></tr></tbody></table><h3 id="tablev-\u4E8B\u4EF6" tabindex="-1">TableV \u4E8B\u4EF6 <a class="header-anchor" href="#tablev-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u56DE\u8C03\u53C2\u6570</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">column-sort</td><td style="text-align:left;"><code>Object&lt;ColumnSortParam&gt;</code></td><td style="text-align:left;">\u5217\u6392\u5E8F\u65F6\u8C03\u7528</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">expanded-rows-change</td><td style="text-align:left;"><code>Array&lt;KeyType&gt;</code></td><td style="text-align:left;">\u884C\u5C55\u5F00\u72B6\u6001\u6539\u53D8\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">end-reached</td><td style="text-align:left;">--</td><td style="text-align:left;">\u5230\u8FBE\u8868\u683C\u672B\u5C3E\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">scroll</td><td style="text-align:left;"><code> Object&lt;ScrollParams&gt;</code></td><td style="text-align:left;">\u8868\u683C\u88AB\u7528\u6237\u6EDA\u52A8\u540E\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">rows-rendered</td><td style="text-align:left;"><code>Object&lt;RowsRenderedParams&gt;</code></td><td style="text-align:left;">\u5F53\u884C\u88AB\u6E32\u67D3\u540E\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-expand</td><td style="text-align:left;"><code>Object&lt;RowExpandParams&gt;</code></td><td style="text-align:left;">\u70B9\u51FB\u7BAD\u5934\u56FE\u6807\u5C55\u5F00/\u6298\u53E0\u6811\u8282\u70B9\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">row-event-handlers</td><td style="text-align:left;"><code>Object&lt;RowEventHandlers&gt;</code></td><td style="text-align:left;">\u5F53\u6BCF\u884C\u6DFB\u52A0\u4E86\u4E00\u7CFB\u5217\u4E8B\u4EF6\u5904\u7406\u5668\u65F6\u89E6\u53D1</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="tablev-\u65B9\u6CD5" tabindex="-1">TableV \u65B9\u6CD5 <a class="header-anchor" href="#tablev-\u65B9\u6CD5" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u65B9\u6CD5\u540D</th><th style="text-align:left;">\u53C2\u6570</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">scrollTo</td><td style="text-align:left;"><code>{ scrollLeft?: number, scrollTop?: number}</code></td><td style="text-align:left;">\u6EDA\u52A8\u5230\u7ED9\u5B9A\u4F4D\u7F6E</td></tr><tr><td style="text-align:left;">scrollToLeft</td><td style="text-align:left;"><code>scrollLeft: number</code></td><td style="text-align:left;">\u6EDA\u52A8\u5230\u7ED9\u5B9A\u7684\u6C34\u5E73\u4F4D\u7F6E</td></tr><tr><td style="text-align:left;">scrollToTop</td><td style="text-align:left;"><code>scrollTop: number</code></td><td style="text-align:left;">\u6EDA\u52A8\u5230\u7ED9\u5B9A\u7684\u5782\u76F4\u4F4D\u7F6E</td></tr><tr><td style="text-align:left;">scrollToRow</td><td style="text-align:left;"><code>row: number, strategy?: &quot;auto&quot;/&quot;center&quot;/&quot;end&quot;/&quot;start&quot; /&quot;smart&quot;</code></td><td style="text-align:left;">\u4F7F\u7528\u7ED9\u5B9A\u7684\u6EDA\u52A8\u7B56\u7565\u6EDA\u52A8\u81F3\u6307\u5B9A\u884C</td></tr></tbody></table><h3 id="column-\u5C5E\u6027" tabindex="-1">Column \u5C5E\u6027 <a class="header-anchor" href="#column-\u5C5E\u6027" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u5C5E\u6027</th><th style="text-align:left;">\u63CF\u8FF0</th><th style="text-align:left;">\u7C7B\u578B</th><th>\u9ED8\u8BA4\u503C</th></tr></thead><tbody><tr><td style="text-align:left;">align</td><td style="text-align:left;">\u8868\u683C\u5355\u5143\u683C\u5185\u5BB9\u5BF9\u9F50\u65B9\u5F0F</td><td style="text-align:left;"><code>Alignment</code></td><td>left</td></tr><tr><td style="text-align:left;">class</td><td style="text-align:left;">\u5217\u7684\u7C7B\u540D</td><td style="text-align:left;"><code>String</code></td><td>--</td></tr><tr><td style="text-align:left;">fixed</td><td style="text-align:left;">\u56FA\u5B9A\u5217\u4F4D\u7F6E</td><td style="text-align:left;"><code>Boolean/FixedDir</code></td><td>false</td></tr><tr><td style="text-align:left;">flexGrow</td><td style="text-align:left;">CSS \u5C5E\u6027 flex grow, \u4EC5\u5F53\u4E0D\u662F\u56FA\u5B9A\u8868\u65F6\u624D\u751F\u6548</td><td style="text-align:left;"><code>Number</code></td><td>0</td></tr><tr><td style="text-align:left;">flexShrink</td><td style="text-align:left;">CSS \u5C5E\u6027 flex shrink, \u4EC5\u5F53\u4E0D\u662F\u56FA\u5B9A\u8868\u65F6\u624D\u751F\u6548</td><td style="text-align:left;"><code>Number</code></td><td>1</td></tr><tr><td style="text-align:left;">headerClass</td><td style="text-align:left;">\u81EA\u5B9A\u4E49 header \u5934\u90E8\u7C7B\u540D</td><td style="text-align:left;"><code>String</code></td><td>--</td></tr><tr><td style="text-align:left;">hidden</td><td style="text-align:left;">\u6B64\u5217\u662F\u5426\u4E0D\u53EF\u89C1</td><td style="text-align:left;"><code>Boolean</code></td><td>--</td></tr><tr><td style="text-align:left;">style</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u5217\u5355\u5143\u683C\u7684\u7C7B\u540D\uFF0C\u5C06\u4F1A\u4E0E gird \u5355\u5143\u683C\u5408\u5E76</td><td style="text-align:left;"><code>CSSProperties</code></td><td>--</td></tr><tr><td style="text-align:left;">sortable</td><td style="text-align:left;">\u8BBE\u7F6E\u5217\u662F\u5426\u53EF\u6392\u5E8F</td><td style="text-align:left;"><code>Boolean</code></td><td>--</td></tr><tr><td style="text-align:left;">title</td><td style="text-align:left;">Header \u5934\u90E8\u5355\u5143\u683C\u4E2D\u7684\u9ED8\u8BA4\u6587\u672C</td><td style="text-align:left;"><code>String</code></td><td>--</td></tr><tr><td style="text-align:left;">maxWidth</td><td style="text-align:left;">\u5217\u7684\u6700\u5927\u5BBD\u5EA6</td><td style="text-align:left;"><code>String</code></td><td>--</td></tr><tr><td style="text-align:left;">minWidth</td><td style="text-align:left;">\u5217\u7684\u6700\u5C0F\u5BBD\u5EA6</td><td style="text-align:left;"><code>String</code></td><td>--</td></tr><tr><td style="text-align:left;">width *</td><td style="text-align:left;">\u5217\u7684\u5BBD\u5EA6 \u5FC5\u586B</td><td style="text-align:left;"><code>Number</code></td><td>--</td></tr><tr><td style="text-align:left;">cellRenderer</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u5355\u5143\u683C\u6E32\u67D3\u5668</td><td style="text-align:left;"><code>VueComponent/(props: CellRenderProps) =&gt; VNode</code></td><td>--</td></tr><tr><td style="text-align:left;">headerCellRenderer</td><td style="text-align:left;">\u81EA\u5B9A\u4E49\u5934\u90E8\u6E32\u67D3\u5668</td><td style="text-align:left;"><code>VueComponent/(props: HeaderRenderProps) =&gt; VNode</code></td><td>--</td></tr></tbody></table>',10);function In(f,g,x,w,E,C){const F=$("render-demo-0"),d=$("demo"),r=$("render-demo-1"),s=$("render-demo-2"),u=$("render-demo-3"),c=$("render-demo-4"),l=$("render-demo-5"),y=$("render-demo-6"),o=$("render-demo-7"),e=$("render-demo-8"),i=$("render-demo-9"),m=$("render-demo-10"),p=$("render-demo-11"),a=$("render-demo-12"),k=$("render-demo-13");return M(),P("div",null,[O,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :width="850" :height="400" fixed style="width:100%" />
  <!-- <n-my-table :attrList="attrList" :tableData="dataSource" :isAction="true" borderType="bordered">
    <template #action="scoped">
      <n-button type="text" @click="test(scoped)">\u6D4B\u8BD5</n-button>
    </template>
  </n-my-table> -->
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(2);
    const data = generateData(columns, 100000);

    return { data, columns };
  },
});
<\/script>

<style></style>
`},{highlight:A(()=>[L]),default:A(()=>[b(F)]),_:1}),H,b(d,{sourceCode:`<template>
  <div style="height: 400px">
    <n-auto-resizer>
      <template #default="{ height, width }">
        <n-table-v :columns="columns" :data="data" :width="width" :height="height" fixed />
      </template>
    </n-auto-resizer>
  </div>
</template>

<script lang="ts">
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 1000);

    return { data, columns };
  },
});
<\/script>

<style></style>
`},{highlight:A(()=>[U]),default:A(()=>[b(r)]),_:1}),Q,J,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :width="700" :height="400" fixed />
</template>

<script lang="tsx">
import { defineComponent, ref } from 'vue';
export default defineComponent({
  setup() {
    let id = 0;

    const dataGenerator = () => ({
      id: \`random-id-\${++id}\`,
      name: 'Tom',
      date: '2020-10-1',
    });

    const columns = [
      {
        key: 'date',
        title: 'Date',
        dataKey: 'date',
        width: 150,
        fixed: 'right',
        // cellRenderer: ({ cellData: date }) => {
        //   return (
        //     <n-tooltip content="test">
        //       <span class="flex items-center">tooltip</span>
        //     </n-tooltip>
        //   );
        // },
      },
      {
        key: 'name',
        title: 'Name',
        dataKey: 'name',
        align: 'center',
        width: 200,
        cellRenderer: ({ cellData: name }) => {
          return 666;
        },
      },
      {
        key: 'operations',
        title: 'Operations',
        width: 200,
        // cellRenderer: () => (
        //   <>
        //     <n-button size="small">Edit</n-button>
        //     <n-button size="small" type="danger">
        //       Delete
        //     </n-button>
        //   </>
        // ),
        align: 'center',
      },
    ];

    const data = ref(Array.from({ length: 200 }).map(dataGenerator));
    return { data, columns };
  },
});
<\/script>

<style></style>
`},{highlight:A(()=>[W]),default:A(()=>[b(s)]),_:1}),X,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :row-class="rowClass" :width="700" :height="400" />
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    let id = 0;

    const dataGenerator = () => ({
      id: \`random-id-\${++id}\`,
      name: 'Tom',
      date: '2020-10-1',
    });

    const columns = [
      {
        key: 'date',
        title: 'Date',
        dataKey: 'date',
        width: 150,
        fixed: 'left',
        // cellRenderer: ({ cellData: date }) => <div>test</div>,
      },
      {
        key: 'name',
        title: 'Name',
        dataKey: 'name',
        width: 150,
        align: 'center',
        // cellRenderer: ({ cellData: name }) => <ElTag>{name}</ElTag>,
      },
      {
        key: 'operations',
        title: 'Operations',
        // cellRenderer: () => (
        //   <>
        //     <ElButton size="small">Edit</ElButton>
        //     <ElButton size="small" type="danger">
        //       Delete
        //     </ElButton>
        //   </>
        // ),
        width: 150,
        align: 'center',
        flexGrow: 1,
      },
    ];

    const data = ref(Array.from({ length: 200 }).map(dataGenerator));

    const rowClass = ({ rowIndex }) => {
      if (rowIndex % 10 === 5) {
        return 'bg-red-100';
      } else if (rowIndex % 10 === 0) {
        return 'bg-blue-200';
      }
      return '';
    };
    return { columns, rowClass, data };
  },
});
<\/script>
<style>
.bg-blue-200 {
  background: blue;
}
.bg-red-100 {
  background: red;
}
</style>
`},{highlight:A(()=>[Y]),default:A(()=>[b(u)]),_:1}),Z,nn,tn,b(d,{sourceCode:`<template>
  <n-table-v
    :columns="columns"
    :data="tableData"
    :fixed-data="fixedData"
    :width="700"
    :height="400"
    :row-class="rowClass"
    fixed
    @scroll="onScroll"
  />
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 200);

    const rowClass = ({ rowIndex }) => {
      if (rowIndex < 0 || (rowIndex + 1) % 5 === 0) return 'sticky-row';
    };

    const stickyIndex = ref(0);

    const fixedData = computed(() => data.slice(stickyIndex.value, stickyIndex.value + 1));

    const tableData = computed(() => {
      return data.slice(1);
    });

    const onScroll = ({ scrollTop }) => {
      stickyIndex.value = Math.floor(scrollTop / 250) * 5;
    };

    return { columns, rowClass, tableData, onScroll, fixedData };
  },
});
<\/script>
`},{highlight:A(()=>[an]),default:A(()=>[b(c)]),_:1}),sn,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :sort-by="sortBy" :width="700" :height="400" fixed @column-sort="onSort" />
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    let data = generateData(columns, 200);

    const sortBy = ref<any>({
      key: 'column-0',
      order: 'asc',
    });

    const onSort = (_sortBy: any) => {
      data = data.reverse();
      sortBy.value = _sortBy;
    };

    columns[0].fixed = true;
    columns[1].fixed = 'left';
    columns[9].fixed = 'right';

    for (let i = 0; i < 3; i++) columns[i].sortable = true;

    return { columns, data, sortBy, onSort };
  },
});
<\/script>
`},{highlight:A(()=>[on]),default:A(()=>[b(l)]),_:1}),T(` ### \u8868\u5934\u5206\u7EC4

\u6B63\u5982\u8FD9\u4E2A\u793A\u4F8B\uFF0C\u901A\u8FC7\u81EA\u5B9A\u4E49\u8868\u5934\u6E32\u67D3\u4EE5\u5C06\u8868\u5934\u5206\u7EC4\u3002

\u5728\u8FD9\u79CD\u5F62\u51B5\u4E0B\uFF0C\u6211\u4EEC\u4F7F\u7528 JSX \u7279\u6027\uFF08\u8BE5\u529F\u80FD\u5728 \`playground\` \u4E2D\u4E0D\u88AB\u652F\u6301\uFF0C\u60A8\u53EF\u4EE5\u5728\u60A8\u7684\u672C\u5730\u73AF\u5883\u6216\u5728\u7EBF IDE \uFF08\u5982 codesandbox \uFF09\u4E2D\u4F7F\u7528\uFF09

\u5EFA\u8BAE\u60A8\u4F7F\u7528 JSX \u4F7F\u7528\u60A8\u7684\u8868\u683C\u7EC4\u4EF6\uFF0C\u56E0\u4E3A\u5B83\u5305\u542B VNode \u64CD\u4F5C\u3002
::: demo

\`\`\`vue
<template>
  <n-table-v
    fixed
    :columns="fixedColumns"
    :data="data"
    :header-height="[50, 40, 50]"
    :header-class="headerClass"
    :width="700"
    :height="400"
  >
    <template #header="props">
      <customized-header v-bind="props" />
    </template>
  </n-table-v>
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });
    const columns = generateColumns(15);
    const data = generateData(columns, 200);

    const fixedColumns = columns.map((column, columnIndex) => {
      let fixed = undefined;
      if (columnIndex < 3) fixed = TableV2FixedDir.LEFT;
      if (columnIndex > 12) fixed = TableV2FixedDir.RIGHT;
      return { ...column, fixed, width: 100 };
    });

    const CustomizedHeader: any = ({ cells, columns, headerIndex }) => {
      if (headerIndex === 2) return cells;

      const groupCells = [] as typeof cells;
      let width = 0;
      let idx = 0;

      columns.forEach((column, columnIndex) => {
        if (column.placeholderSign === TableV2Placeholder) groupCells.push(cells[columnIndex]);
        else {
          width += cells[columnIndex].props!.column.width;
          idx++;

          const nextColumn = columns[columnIndex + 1];
          if (
            columnIndex === columns.length - 1 ||
            nextColumn.placeholderSign === TableV2Placeholder ||
            idx === (headerIndex === 0 ? 4 : 2)
          ) {
            groupCells.push(
              <div
                class="flex items-center justify-center custom-header-cell"
                role="columnheader"
                style={{
                  ...cells[columnIndex].props!.style,
                  width: \`\${width}px\`,
                }}>
                Group width {width}
              </div>
            );
            width = 0;
            idx = 0;
          }
        }
      });
      return groupCells;
    };

    const headerClass = ({ headerIndex }: any) => {
      if (headerIndex === 1) return 'el-primary-color';
      return '';
    };
    return { columns, data, sortBy, onSort };
  },
});
<\/script>

<style>
.el-el-table-v2__header-row .custom-header-cell {
  border-right: 1px solid var(--el-border-color);
}

.el-el-table-v2__header-row .custom-header-cell:last-child {
  border-right: none;
}

.el-primary-color {
  background-color: var(--el-color-primary);
  color: var(--el-color-white);
  font-size: 14px;
  font-weight: bold;
}

.el-primary-color .custom-header-cell {
  padding: 0 4px;
}
</style>
\`\`\`

::: `),en,pn,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :sort-by="sortState" :width="700" :height="400" fixed @column-sort="onSort" />
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    let data = generateData(columns, 200);

    columns[0].sortable = true;

    const sortState = ref<any>({
      key: 'column-0',
      order: 'asc',
    });

    const onSort = (sortBy: any) => {
      console.log(sortBy);
      data = data.reverse();
      sortState.value = sortBy;
    };

    return { columns, data, onSort, sortState };
  },
});
<\/script>
`},{highlight:A(()=>[un]),default:A(()=>[b(y)]),_:1}),cn,ln,b(d,{sourceCode:`<template>
  <n-table-v v-model:sort-state="sortState" :columns="columns" :data="data" :width="700" :height="400" fixed @column-sort="onSort" />
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = ref(generateData(columns, 200));

    columns[0].sortable = true;
    columns[1].sortable = true;

    const sortState = ref({
      'column-0': 'desc',
      'column-1': 'asc',
    });

    const onSort = ({ key, order }) => {
      sortState.value[key] = order;
      data.value = data.value.reverse();
    };

    return { columns, data, onSort, sortState };
  },
});
<\/script>
`},{highlight:A(()=>[rn]),default:A(()=>[b(o)]),_:1}),T(` ### \u9AD8\u4EAE\u663E\u793A\u9F20\u6807\u60AC\u505C\u5355\u5143\u683C

\u5F53\u6570\u636E\u5217\u8868\u5F88\u5927\u65F6\uFF0C\u6709\u65F6\u5019\u4F1A\u5FD8\u8BB0\u6B63\u5728\u8BBF\u95EE\u7684\u884C\u548C\u5217\uFF0C\u4F7F\u7528\u8FD9\u4E2A\u5C5E\u6027\u53EF\u4EE5\u7ED9\u4E88\u4F60\u8FD9\u4E2A\u5E2E\u52A9\u3002
::: demo

\`\`\`vue
<template>
  <div style="height: 400px">
    <n-auto-resizer>
      <template #default="{ height, width }">
        <n-table-v :columns="columns" :cell-props="cellProps" :class="kls" :data="data" :width="width" :height="height" />
      </template>
    </n-auto-resizer>
  </div>
</template>

<script lang="tsx">
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    columns.unshift({
      key: 'column-n-1',
      width: 50,
      title: 'Row No.',
      cellRenderer: ({ rowIndex }) => \`\${rowIndex + 1}\`,
      align: 'center',
    });
    const data = generateData(columns, 200);

    const cellProps = ({ columnIndex }) => {
      const key = \`hovering-col-\${columnIndex}\`;
      return {
        ['data-key']: key,
        onMouseenter: () => {
          kls.value = key;
        },
        onMouseleave: () => {
          kls.value = '';
        },
      };
    };

    const kls = ref<string>('');

    return { columns, data, cellProps, kls };
  },
});
<\/script>

<style>
.hovering-col-0 [data-key='hovering-col-0'],
.hovering-col-1 [data-key='hovering-col-1'],
.hovering-col-2 [data-key='hovering-col-2'],
.hovering-col-3 [data-key='hovering-col-3'],
.hovering-col-4 [data-key='hovering-col-4'],
.hovering-col-5 [data-key='hovering-col-5'],
.hovering-col-6 [data-key='hovering-col-6'],
.hovering-col-7 [data-key='hovering-col-7'],
.hovering-col-8 [data-key='hovering-col-8'],
.hovering-col-9 [data-key='hovering-col-9'],
.hovering-col-10 [data-key='hovering-col-10'] {
  background: var(red);
}

[data-key='hovering-col-0'] {
  font-weight: bold;
  user-select: none;
  pointer-events: none;
}
</style>
\`\`\`

::: `),T(` ### \u6A2A\u8DE8\u5217

\u865A\u62DF\u5316\u8868\u683C\u6CA1\u6709\u4F7F\u7528\u5185\u7F6E\u7684 \`table\` \u5143\u7D20\uFF0C\u6545 \`colspan\` \u548C \`rowspan\` \u4E0E \`Table\` \u6BD4\u8F83\u7565\u6709\u4E0D\u540C\u3002 \u901A\u8FC7\u5B9A\u5236\u7684\u884C\u6E32\u67D3\u5668\uFF0C\u6211\u4EEC\u4ECD\u7136\u53EF\u4EE5\u5B9E\u73B0\u8FD9\u4E2A\u9700\u6C42\u3002 \u5728\u5982\u4E0B\u4F8B\u5B50\uFF0C\u4F60\u4F1A\u5B66\u4E60\u5982\u4F55\u505A\u5230\u8FD9\u4E00\u70B9\u3002
::: demo

\`\`\`vue
<template>
  <n-table-v fixed :columns="columns" :data="data" :width="700" :height="400">
    <template #row="props">
      <Row v-bind="props" />
    </template>
  </n-table-v>
</template>

<script lang="ts">
import { cloneVNode, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 200);

    const colSpanIndex = 1;
    columns[colSpanIndex].colSpan = ({ rowIndex }) => (rowIndex % 4) + 1;
    columns[colSpanIndex].align = 'center';

    const Row = ({ rowData, rowIndex, cells, columns }) => {
      const colSpan = columns[colSpanIndex].colSpan({ rowData, rowIndex });
      if (colSpan > 1) {
        let width = Number.parseInt(cells[colSpanIndex].props.style.width);
        for (let i = 1; i < colSpan; i++) {
          width += Number.parseInt(cells[colSpanIndex + i].props.style.width);
          cells[colSpanIndex + i] = null;
        }
        const style = {
          ...cells[colSpanIndex].props.style,
          width: \`\${width}px\`,
          backgroundColor: 'var(--el-color-primary-light-3)',
        };
        cells[colSpanIndex] = cloneVNode(cells[colSpanIndex], { style });
      }

      return cells;
    };
    return { columns, data, Row };
  },
});
<\/script>
\`\`\`

::: `),kn,dn,b(d,{sourceCode:`<template>
  <n-table-v
    v-model:expanded-row-keys="expandedRowKeys"
    :columns="columns"
    :data="treeData"
    :width="700"
    :expand-column-key="expandColumnKey"
    :height="400"
    fixed
    @row-expand="onRowExpanded"
    @expanded-rows-change="onExpandedRowsChange"
  />
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10).map((column, columnIndex) => {
      let fixed;
      if (columnIndex < 2) fixed = 'left';
      if (columnIndex > 8) fixed = 'right';
      return { ...column, fixed };
    });

    const data = generateData(columns, 200);

    const expandColumnKey = 'column-0';

    // add some sub items
    for (let i = 0; i < 50; i++) {
      data.push(
        {
          ...data[0],
          id: \`\${data[0].id}-sub-\${i}\`,
          parentId: data[0].id,
          [expandColumnKey]: \`Sub \${i}\`,
        },
        {
          ...data[2],
          id: \`\${data[2].id}-sub-\${i}\`,
          parentId: data[2].id,
          [expandColumnKey]: \`Sub \${i}\`,
        },
        {
          ...data[2],
          id: \`\${data[2].id}-sub-sub-\${i}\`,
          parentId: \`\${data[2].id}-sub-\${i}\`,
          [expandColumnKey]: \`Sub-Sub \${i}\`,
        }
      );
    }

    function unflatten(data: ReturnType<typeof generateData>, rootId = null, dataKey = 'id', parentKey = 'parentId') {
      const tree: any[] = [];
      const childrenMap = {};

      for (const datum of data) {
        const item = { ...datum };
        const id = item[dataKey];
        const parentId = item[parentKey];

        if (Array.isArray(item.children)) {
          childrenMap[id] = item.children.concat(childrenMap[id] || []);
        } else if (!childrenMap[id]) {
          childrenMap[id] = [];
        }
        item.children = childrenMap[id];

        if (parentId !== undefined && parentId !== rootId) {
          if (!childrenMap[parentId]) childrenMap[parentId] = [];
          childrenMap[parentId].push(item);
        } else {
          tree.push(item);
        }
      }

      return tree;
    }

    const treeData = computed(() => unflatten(data));

    const expandedRowKeys = ref<string[]>([]);

    const onRowExpanded = ({ expanded }) => {
      console.log('Expanded:', expanded);
    };

    const onExpandedRowsChange = (expandedKeys) => {
      console.log(expandedKeys);
    };

    return { columns, treeData, onExpandedRowsChange, onRowExpanded, expandedRowKeys, expandColumnKey };
  },
});
<\/script>
`},{highlight:A(()=>[mn]),default:A(()=>[b(e)]),_:1}),gn,yn,fn,b(d,{sourceCode:`<template>
  <n-table-v
    :columns="columns"
    :data="data"
    :sort-by="sort"
    :estimated-row-height="80"
    :width="700"
    :height="400"
    fixed
    @column-sort="onColumnSort"
  />
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const longText = 'Quaerat ipsam necessitatibus eum quibusdam est id voluptatem cumque mollitia.';
    const midText = 'Corrupti doloremque a quos vero delectus consequatur.';
    const shortText = 'Eius optio fugiat.';

    const textList = [shortText, midText, longText];

    // generate random number in range 0 to 2

    let id = 0;

    const dataGenerator = () => ({
      id: \`random:\${++id}\`,
      name: 'Tom',
      date: '2016-05-03',
      description: textList[Math.floor(Math.random() * 3)],
    });

    const columns = [
      {
        key: 'id',
        title: 'Id',
        dataKey: 'id',
        width: 150,
        sortable: true,
        fixed: 'left',
      },
      {
        key: 'name',
        title: 'Name',
        dataKey: 'name',
        width: 150,
        align: 'center',
        cellRenderer: ({ cellData: name }) => 'name',
      },
      {
        key: 'description',
        title: 'Description',
        dataKey: 'description',
        width: 150,
        cellRenderer: ({ cellData: description }) => 'description',
      },
      {
        key: 'operations',
        title: 'Operations',
        cellRenderer: () => 'test',
        // <>
        //   <ElButton size="small">Edit</ElButton>
        //   <ElButton size="small" type="danger">
        //     Delete
        //   </ElButton>
        // </>
        width: 150,
        align: 'center',
      },
    ];
    const data = ref(
      Array.from({ length: 200 })
        .map(dataGenerator)
        .sort((a, b) => (a.name > b.name ? 1 : -1))
    );

    const sort = ref({ key: 'name', order: 'asc' });

    const onColumnSort = (sortBy) => {
      const order = sortBy.order === 'asc' ? 1 : -1;
      const dataClone = [...data.value];
      dataClone.sort((a, b) => (a[sortBy.key] > b[sortBy.key] ? order : -order));
      sort.value = sortBy;
      data.value = dataClone;
    };

    return { columns, data, onColumnSort, sort };
  },
});
<\/script>
`},{highlight:A(()=>[xn]),default:A(()=>[b(i)]),_:1}),T(` ### \u53EF\u5C55\u5F00\u7684\u9644\u52A0\u4FE1\u606F

\u901A\u8FC7\u52A8\u6001\u9AD8\u5EA6\u6E32\u67D3\uFF0C\u6211\u4EEC\u53EF\u4EE5\u5728\u8868\u683C\u4E2D\u663E\u793A\u53EF\u5C55\u5F00\u7684\u66F4\u591A\u9644\u52A0\u4FE1\u606F\u3002
::: demo

\`\`\`vue
<template>
  <n-table-v :columns="columns" :data="data" :estimated-row-height="50" :expand-column-key="columns[0].key" :width="700" :height="400">
    <template #row="props">
      <Row v-bind="props" />
    </template>
  </n-table-v>
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const detailedText = \`Velit sed aspernatur tempora. Natus consequatur officiis dicta vel assumenda.
Itaque est temporibus minus quis. Ipsum commodiab porro vel voluptas illum.
Qui quam nulla et dolore autem itaque est.
Id consequatur ipsum ea fuga et odit eligendi impedit.
Maiores officiis occaecati et magnam et sapiente est velit sunt.
Non et tempore temporibus. Excepturi et quos. Minus distinctio aut.
Voluptatem ea excepturi omnis vel. Non aperiam sit sed laboriosam eaque omnis deleniti.
Est molestiae omnis non et nulla repudiandae fuga sit.\`;

    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = ref(
      generateData(columns, 200).map((data) => {
        data.children = [
          {
            id: \`\${data.id}-detail-content\`,
            detail: detailedText,
          },
        ];
        return data;
      })
    );

    const Row = ({ cells, rowData }) => {
      if (rowData.detail) return rowData.detail;
      return cells;
    };

    Row.inheritAttrs = false;

    return { columns, data, Row };
  },
});
<\/script>
\`\`\`

::: `),hn,wn,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :row-height="40" :width="700" :height="400" :footer-height="50" fixed>
    <template #footer
      ><div
        class="flex items-center"
        style="
          justify-content: center;
          height: 100%;
          background-color: #447DFD;
        "
      >
        Display a message in the footer
      </div>
    </template>
  </n-table-v>
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 200);

    return { columns, data };
  },
});
<\/script>
`},{highlight:A(()=>[Cn]),default:A(()=>[b(m)]),_:1}),En,Fn,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="[]" :row-height="40" :width="700" :height="400" :footer-height="50">
    <template #empty>
      <div class="flex items-center justify-center h-100%">testEmpty</div>
    </template>
  </n-table-v>
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const columns = generateColumns(10);

    return { columns };
  },
});
<\/script>
`},{highlight:A(()=>[vn]),default:A(()=>[b(p)]),_:1}),bn,An,b(d,{sourceCode:`<template>
  <n-table-v :columns="columns" :data="data" :row-height="40" :width="700" :height="400">
    <template #overlay>
      <div class="el-loading-mask" style="display: flex; align-items: center; justify-content: center">
        <n-icon name="icon-loading" class="is-loading" :size="26" />
      </div>
    </template>
  </n-table-v>
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 200);

    return { columns };
  },
});
<\/script>
<style>
.example-showcase .nancalui-table-v__overlay {
  z-index: 9;
}
</style>
`},{highlight:A(()=>[Dn]),default:A(()=>[b(a)]),_:1}),Bn,b(d,{sourceCode:`<template>
  <div class="mb-4 flex items-center">
    <n-form-item label="Scroll pixels" class="mr-4">
      <n-input v-model="scrollDelta" />
    </n-form-item>
    <n-form-item label="Scroll rows">
      <n-input v-model="scrollRows" />
    </n-form-item>
  </div>
  <div class="mb-4 flex items-center">
    <n-button @click="scrollByPixels"> Scroll by pixels </n-button>
    <n-button @click="scrollByRows"> Scroll by rows </n-button>
  </div>
  <div style="height: 400px">
    <n-auto-resizer>
      <template #default="{ height, width }">
        <n-table-v ref="tableRef" :columns="columns" :data="data" :width="width" :height="height" fixed />
      </template>
    </n-auto-resizer>
  </div>
</template>

<script lang="tsx">
import { ref, defineComponent, computed } from 'vue';

export default defineComponent({
  setup() {
    const generateColumns = (length = 10, prefix = 'column-', props?: any) =>
      Array.from({ length }).map((_, columnIndex) => ({
        ...props,
        key: \`\${prefix}\${columnIndex}\`,
        dataKey: \`\${prefix}\${columnIndex}\`,
        title: \`Column \${columnIndex}\`,
        width: 150,
      }));

    const generateData = (columns: ReturnType<typeof generateColumns>, length = 200, prefix = 'row-') =>
      Array.from({ length }).map((_, rowIndex) => {
        return columns.reduce(
          (rowData, column, columnIndex) => {
            rowData[column.dataKey] = \`Row \${rowIndex} - Col \${columnIndex}\`;
            return rowData;
          },
          {
            id: \`\${prefix}\${rowIndex}\`,
            parentId: null,
          }
        );
      });

    const columns = generateColumns(10);
    const data = generateData(columns, 200);
    const tableRef = ref();
    const scrollDelta = ref(200);
    const scrollRows = ref(10);

    function scrollByPixels() {
      tableRef.value?.scrollToTop(scrollDelta.value);
    }

    function scrollByRows() {
      tableRef.value?.scrollToRow(scrollRows.value);
    }

    return { columns, scrollRows, data, scrollDelta, scrollByPixels, scrollByRows, tableRef };
  },
});
<\/script>
`},{highlight:A(()=>[_n]),default:A(()=>[b(k)]),_:1}),$n])}var Vn=j(G,[["render",In]]);export{Tn as __pageData,Vn as default};
