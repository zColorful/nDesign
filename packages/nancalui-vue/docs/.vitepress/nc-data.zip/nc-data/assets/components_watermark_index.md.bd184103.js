import{V as m}from"./framework.1c17ccd8.js";import{_ as w}from"./plugin-vue_export-helper.21dcd24c.js";import{f as x,G as D,H as A,b as F,a6 as f,V as C,I as t,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const _={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:u,createVNode:o,createElementVNode:c,withCtx:r,openBlock:i,createElementBlock:k}=m,l=c("div",{class:"watermark-demo-block"},null,-1);function s(a,e){const g=u("n-textarea"),E=u("n-watermark");return i(),k("div",null,[o(g,{modelValue:a.data,"onUpdate:modelValue":e[0]||(e[0]=B=>a.data=B),rows:5},null,8,["modelValue"]),o(E,{show:a.show,content:a.content,style:{width:"100%"}},{default:r(()=>[l]),_:1},8,["show","content"])])}const{defineComponent:p,ref:y,computed:h}=m,d=p({setup(){const a=y(`NANCAL UI 
 \u80FD\u79D1\u79D1\u6280`),e=h(()=>{var g;return(g=a.value)==null?void 0:g.split(`
`)});return{data:a,content:e}}});return{render:s,...d}}(),"render-demo-1":function(){const{createElementVNode:u,resolveComponent:o,withCtx:c,createVNode:r,openBlock:i,createElementBlock:k}=m,l=u("div",{class:"watermark-demo-block"},null,-1);function s(d,a){const e=o("n-watermark");return i(),k("div",null,[r(e,{image:d.data,content:["2023/05/26 11:05-\u5F20\u4E09-\u80FD\u79D1\u79D1\u6280","\u5185\u90E8\u4F7F\u7528\uFF0C\u8BF7\u52FF\u5916\u4F20"],style:{width:"100%"},gap:[0,0]},{default:c(()=>[l]),_:1},8,["image"])])}const{defineComponent:p,ref:y}=m,h=p({setup(){return{data:y("/../../assets/logo.png")}}});return{render:s,...h}}()}},$='{"title":"Watermark \u6C34\u5370","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"\u56FE\u7247\u6C34\u5370","slug":"\u56FE\u7247\u6C34\u5370"},{"level":3,"title":"Watermark \u53C2\u6570","slug":"watermark-\u53C2\u6570"},{"level":3,"title":"Font \u53C2\u6570","slug":"font-\u53C2\u6570"},{"level":3,"title":"Watermark \u7C7B\u578B\u5B9A\u4E49","slug":"watermark-\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/watermark/index.md","lastUpdated":1686120785144}',v=C('<h1 id="watermark-\u6C34\u5370" tabindex="-1">Watermark \u6C34\u5370 <a class="header-anchor" href="#watermark-\u6C34\u5370" aria-hidden="true">#</a></h1><p>\u7ED9\u9875\u9762\u7684\u67D0\u4E2A\u533A\u57DF\u52A0\u4E0A\u6C34\u5370</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u9875\u9762\u9700\u8981\u6DFB\u52A0\u6C34\u5370\u6807\u8BC6\u7248\u6743\u65F6\u4F7F\u7528\u3002 \u9002\u7528\u4E8E\u9632\u6B62\u4FE1\u606F\u76D7\u7528\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),b=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-textarea")]),n(),t("span",{class:"token attr-name"},"v-model"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":rows"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("5"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-textarea")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-watermark")]),n(),t("span",{class:"token attr-name"},":show"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("show"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":content"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("content"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 100%")]),t("span",{class:"token punctuation"},'"')])]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("watermark-demo-block"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-watermark")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref"),t("span",{class:"token punctuation"},","),n(" computed "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" data "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'NANCAL UI \\n \u80FD\u79D1\u79D1\u6280'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" content "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"computed"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token operator"},"=>"),n(" data"),t("span",{class:"token punctuation"},"."),n("value"),t("span",{class:"token operator"},"?."),t("span",{class:"token function"},"split"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'\\n'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      data`),t("span",{class:"token punctuation"},","),n(`
      content`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("scss"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},`// demo\u4E2D\u7684\u6837\u5F0F\u4E0D\u652F\u6301 scoped\uFF0C\u9700\u8981\u4F7F\u7528\u7EA6\u5B9A\u7684class\u540D\u79F0\u5305\u88F9\uFF0C\u683C\u5F0F\uFF1Ademo-componentname-demoname

// css
.watermark-demo-block`),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n(" 500px"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 100%"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),N=t("h3",{id:"\u56FE\u7247\u6C34\u5370",tabindex:"-1"},[n("\u56FE\u7247\u6C34\u5370 "),t("a",{class:"header-anchor",href:"#\u56FE\u7247\u6C34\u5370","aria-hidden":"true"},"#")],-1),V=t("div",{class:"language-vue"},[t("pre",null,[t("code",null,[t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("n-watermark")]),n(),t("span",{class:"token attr-name"},":image"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("data"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token attr-name"},":content"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("['2023/05/26 11:05-\u5F20\u4E09-\u80FD\u79D1\u79D1\u6280', '\u5185\u90E8\u4F7F\u7528\uFF0C\u8BF7\u52FF\u5916\u4F20']"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token special-attr"},[t("span",{class:"token attr-name"},"style"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),t("span",{class:"token value css language-css"},[t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 100%")]),t("span",{class:"token punctuation"},'"')])]),n(),t("span",{class:"token attr-name"},":gap"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("[0, 0]"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),n(`
    `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("div")]),n(),t("span",{class:"token attr-name"},"class"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("watermark-demo-block"),t("span",{class:"token punctuation"},'"')]),n(),t("span",{class:"token punctuation"},"/>")]),n(`
  `),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("n-watermark")]),t("span",{class:"token punctuation"},">")]),n(`
`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("template")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("script")]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token script"},[t("span",{class:"token language-javascript"},[n(`
`),t("span",{class:"token keyword"},"import"),n(),t("span",{class:"token punctuation"},"{"),n(" defineComponent"),t("span",{class:"token punctuation"},","),n(" ref "),t("span",{class:"token punctuation"},"}"),n(),t("span",{class:"token keyword"},"from"),n(),t("span",{class:"token string"},"'vue'"),t("span",{class:"token punctuation"},";"),n(`

`),t("span",{class:"token keyword"},"export"),n(),t("span",{class:"token keyword"},"default"),n(),t("span",{class:"token function"},"defineComponent"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token function"},"setup"),t("span",{class:"token punctuation"},"("),t("span",{class:"token punctuation"},")"),n(),t("span",{class:"token punctuation"},"{"),n(`
    `),t("span",{class:"token keyword"},"const"),n(" data "),t("span",{class:"token operator"},"="),n(),t("span",{class:"token function"},"ref"),t("span",{class:"token punctuation"},"("),t("span",{class:"token string"},"'/../../assets/logo.png'"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`

    `),t("span",{class:"token keyword"},"return"),n(),t("span",{class:"token punctuation"},"{"),n(`
      data`),t("span",{class:"token punctuation"},","),n(`
    `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},","),n(`
`),t("span",{class:"token punctuation"},"}"),t("span",{class:"token punctuation"},")"),t("span",{class:"token punctuation"},";"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("script")]),t("span",{class:"token punctuation"},">")]),n(`

`),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"<"),n("style")]),n(),t("span",{class:"token attr-name"},"lang"),t("span",{class:"token attr-value"},[t("span",{class:"token punctuation attr-equals"},"="),t("span",{class:"token punctuation"},'"'),n("scss"),t("span",{class:"token punctuation"},'"')]),t("span",{class:"token punctuation"},">")]),t("span",{class:"token style"},[t("span",{class:"token language-css"},[n(`
`),t("span",{class:"token selector"},`// demo\u4E2D\u7684\u6837\u5F0F\u4E0D\u652F\u6301 scoped\uFF0C\u9700\u8981\u4F7F\u7528\u7EA6\u5B9A\u7684class\u540D\u79F0\u5305\u88F9\uFF0C\u683C\u5F0F\uFF1Ademo-componentname-demoname

// css
.watermark-demo-block`),n(),t("span",{class:"token punctuation"},"{"),n(`
  `),t("span",{class:"token property"},"height"),t("span",{class:"token punctuation"},":"),n(" 500px"),t("span",{class:"token punctuation"},";"),n(`
  `),t("span",{class:"token property"},"width"),t("span",{class:"token punctuation"},":"),n(" 100%"),t("span",{class:"token punctuation"},";"),n(`
`),t("span",{class:"token punctuation"},"}"),n(`
`)])]),t("span",{class:"token tag"},[t("span",{class:"token tag"},[t("span",{class:"token punctuation"},"</"),n("style")]),t("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),q=C(`<h3 id="watermark-\u53C2\u6570" tabindex="-1">Watermark \u53C2\u6570 <a class="header-anchor" href="#watermark-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">content</td><td style="text-align:left;">string/ string[]</td><td style="text-align:left;"></td><td style="text-align:left;">\u6C34\u5370\u6587\u5B57\u5185\u5BB9\uFF0C\u6570\u7EC4\u4E3A\u591A\u884C</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">zIndex</td><td style="text-align:left;">number</td><td style="text-align:left;">9</td><td style="text-align:left;">\u8FFD\u52A0\u7684\u6C34\u5370\u5143\u7D20\u7684 z-index</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">rotate</td><td style="text-align:left;">number</td><td style="text-align:left;">-22</td><td style="text-align:left;">\u6C34\u5370\u7ED8\u5236\u65F6\uFF0C\u65CB\u8F6C\u7684\u89D2\u5EA6\uFF0C\u5355\u4F4D \xB0</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">width</td><td style="text-align:left;">number</td><td style="text-align:left;"></td><td style="text-align:left;">\u6C34\u5370\u7684\u5BBD\u5EA6\uFF0C\u9ED8\u8BA4\u4F1A\u81EA\u52A8\u8BA1\u7B97</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">height</td><td style="text-align:left;">number</td><td style="text-align:left;"></td><td style="text-align:left;">\u6C34\u5370\u7684\u9AD8\u5EA6\uFF0C\u9ED8\u8BA4\u81EA\u52A8\u8BA1\u7B97</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">image</td><td style="text-align:left;">string</td><td style="text-align:left;"></td><td style="text-align:left;">\u56FE\u7247\u6E90\uFF0C\u5EFA\u8BAE\u5BFC\u51FA 2 \u500D\u6216 3 \u500D\u56FE</td><td style="text-align:left;"><a href="#%E5%9B%BE%E7%89%87%E6%B0%B4%E5%8D%B0">\u56FE\u7247\u6C34\u5370</a></td></tr><tr><td style="text-align:left;">imageRight</td><td style="text-align:left;">number</td><td style="text-align:left;"></td><td style="text-align:left;">\u540C\u65F6\u5B58\u5728\u56FE\u7247\u548C\u6587\u5B57\u65F6\u53F3\u4FA7\u95F4\u9694</td><td style="text-align:left;"><a href="#%E5%9B%BE%E7%89%87%E6%B0%B4%E5%8D%B0">\u56FE\u7247\u6C34\u5370</a></td></tr><tr><td style="text-align:left;">imageSize</td><td style="text-align:left;">Size/undefined</td><td style="text-align:left;"></td><td style="text-align:left;">\u56FE\u7247\u5C3A\u5BF8\uFF0C\u4E3A\u4E86\u907F\u514D\u56FE\u7247\u62C9\u4F38\u7684\u95EE\u9898\uFF0C\u5EFA\u8BAE\u53EA\u8BBE\u7F6E\u5BBD/\u9AD8\u5176\u4E00, \u4E3A\u8BBE\u7F6E\u4F1A\u4F7F\u7528\u6587\u5B57\u9AD8\u5EA6</td><td style="text-align:left;"><a href="#%E5%9B%BE%E7%89%87%E6%B0%B4%E5%8D%B0">\u56FE\u7247\u6C34\u5370</a></td></tr><tr><td style="text-align:left;">font</td><td style="text-align:left;">FontStyle</td><td style="text-align:left;">{}</td><td style="text-align:left;">\u6587\u5B57\u6837\u5F0F</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">gap</td><td style="text-align:left;">NumEum2</td><td style="text-align:left;">[100, 100]</td><td style="text-align:left;">\u6C34\u5370\u4E4B\u95F4\u7684\u95F4\u8DDD</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">offset</td><td style="text-align:left;">NumEum2</td><td style="text-align:left;">[gap[0]/2, gap[1]/2]</td><td style="text-align:left;">\u6C34\u5370\u8DDD\u79BB\u5BB9\u5668\u5DE6\u4E0A\u89D2\u7684\u504F\u79FB\u91CF\uFF0C\u9ED8\u8BA4\u4E3A gap/2</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="font-\u53C2\u6570" tabindex="-1">Font \u53C2\u6570 <a class="header-anchor" href="#font-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">color</td><td style="text-align:left;">string</td><td style="text-align:left;"><code>rgba(0,0,0,.15)</code></td><td style="text-align:left;">\u6587\u5B57\u989C\u8272</td></tr><tr><td style="text-align:left;">fontSize</td><td style="text-align:left;">number/string</td><td style="text-align:left;">16</td><td style="text-align:left;">\u6587\u5B57\u5927\u5C0F</td></tr><tr><td style="text-align:left;">fontWeight</td><td style="text-align:left;">number</td><td style="text-align:left;"><code>normal</code></td><td style="text-align:left;">\u6587\u5B57\u6743\u91CD</td></tr><tr><td style="text-align:left;">fontStyle</td><td style="text-align:left;">number</td><td style="text-align:left;"><code>normal</code></td><td style="text-align:left;">\u6587\u5B57\u6837\u5F0F</td></tr><tr><td style="text-align:left;">fontFamily</td><td style="text-align:left;">string</td><td style="text-align:left;"><code>sans-serif</code></td><td style="text-align:left;">\u5B57\u4F53\u7CFB\u5217</td></tr></tbody></table><h3 id="watermark-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">Watermark \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#watermark-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="ixxx" tabindex="-1">IXxx <a class="header-anchor" href="#ixxx" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">interface</span> <span class="token class-name">FontStyle</span> <span class="token punctuation">{</span>
  color<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  fontSize<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">number</span> <span class="token operator">|</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  fontWeight<span class="token operator">?</span><span class="token operator">:</span> <span class="token string">&#39;normal&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;light&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;weight&#39;</span> <span class="token operator">|</span> <span class="token builtin">number</span><span class="token punctuation">;</span>
  fontStyle<span class="token operator">?</span><span class="token operator">:</span> <span class="token string">&#39;none&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;normal&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;italic&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;oblique&#39;</span><span class="token punctuation">;</span>
  fontFamily<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>

<span class="token keyword">type</span> <span class="token class-name">NumEum2</span> <span class="token operator">=</span> <span class="token punctuation">[</span><span class="token builtin">number</span><span class="token punctuation">,</span> <span class="token builtin">number</span><span class="token punctuation">]</span><span class="token punctuation">;</span>

<span class="token keyword">export</span> <span class="token keyword">interface</span> <span class="token class-name">Size</span> <span class="token punctuation">{</span>
  width<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">number</span> <span class="token operator">|</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
  height<span class="token operator">?</span><span class="token operator">:</span> <span class="token builtin">number</span> <span class="token operator">|</span> <span class="token builtin">string</span><span class="token punctuation">;</span>
<span class="token punctuation">}</span>
</code></pre></div>`,7);function S(u,o,c,r,i,k){const l=x("render-demo-0"),s=x("demo"),p=x("render-demo-1");return D(),A("div",null,[v,F(s,{sourceCode:`<template>
  <n-textarea v-model="data" :rows="5"></n-textarea>
  <n-watermark :show="show" :content="content" style="width: 100%">
    <div class="watermark-demo-block" />
  </n-watermark>
</template>

<script>
import { defineComponent, ref, computed } from 'vue';

export default defineComponent({
  setup() {
    const data = ref('NANCAL UI \\n \u80FD\u79D1\u79D1\u6280');
    const content = computed(() => data.value?.split('\\n'));

    return {
      data,
      content,
    };
  },
});
<\/script>

<style lang="scss">
// demo\u4E2D\u7684\u6837\u5F0F\u4E0D\u652F\u6301 scoped\uFF0C\u9700\u8981\u4F7F\u7528\u7EA6\u5B9A\u7684class\u540D\u79F0\u5305\u88F9\uFF0C\u683C\u5F0F\uFF1Ademo-componentname-demoname

// css
.watermark-demo-block {
  height: 500px;
  width: 100%;
}
</style>
`},{highlight:f(()=>[b]),default:f(()=>[F(l)]),_:1}),N,F(s,{sourceCode:`<template>
  <n-watermark :image="data" :content="['2023/05/26 11:05-\u5F20\u4E09-\u80FD\u79D1\u79D1\u6280', '\u5185\u90E8\u4F7F\u7528\uFF0C\u8BF7\u52FF\u5916\u4F20']" style="width: 100%" :gap="[0, 0]">
    <div class="watermark-demo-block" />
  </n-watermark>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const data = ref('/../../assets/logo.png');

    return {
      data,
    };
  },
});
<\/script>

<style lang="scss">
// demo\u4E2D\u7684\u6837\u5F0F\u4E0D\u652F\u6301 scoped\uFF0C\u9700\u8981\u4F7F\u7528\u7EA6\u5B9A\u7684class\u540D\u79F0\u5305\u88F9\uFF0C\u683C\u5F0F\uFF1Ademo-componentname-demoname

// css
.watermark-demo-block {
  height: 500px;
  width: 100%;
}
</style>
`},{highlight:f(()=>[V]),default:f(()=>[F(p)]),_:1}),q])}var L=w(_,[["render",S]]);export{$ as __pageData,L as default};
