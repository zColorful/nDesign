import{V as y}from"./framework.1c17ccd8.js";import{_ as A}from"./plugin-vue_export-helper.21dcd24c.js";import{f as C,G as D,H as w,b as v,a6 as f,V as _,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const V={name:"component-doc",components:{"render-demo-0":function(){const{createTextVNode:o,resolveComponent:i,withCtx:u,createVNode:l,createElementVNode:r,openBlock:k,createElementBlock:d}=y,c=r("div",{class:"demo-fixed-overlay-container"},"Hello nancalui!",-1);function g(e,p){const h=i("n-button"),s=i("n-fixed-overlay");return k(),d("div",null,[l(h,{onClick:p[0]||(p[0]=a=>e.visible=!e.visible)},{default:u(()=>[o("\u663E\u793A\u56FA\u5B9A\u906E\u7F69\u5C42")]),_:1}),l(s,{modelValue:e.visible,"onUpdate:modelValue":p[1]||(p[1]=a=>e.visible=a),class:"demo-fixed-overlay-bg"},{default:u(()=>[c]),_:1},8,["modelValue"])])}const{defineComponent:F,ref:m}=y,x=F({setup(){return{visible:m(!1)}}});return{render:g,...x}}(),"render-demo-1":function(){const{createElementVNode:o,toDisplayString:i,createTextVNode:u,resolveComponent:l,withCtx:r,createVNode:k,openBlock:d,createElementBlock:c}=y,g={ref:"origin",class:"demo-flexible-overlay-origin"},F=o("br",null,null,-1);function m(s,a){const E=l("n-button"),b=l("n-flexible-overlay");return d(),c("div",null,[o("div",null,[o("div",g,"origin",512),F,k(E,{onClick:a[0]||(a[0]=B=>s.visible=!s.visible)},{default:r(()=>[u(i(s.title),1)]),_:1}),k(b,{modelValue:s.visible,"onUpdate:modelValue":a[1]||(a[1]=B=>s.visible=B),origin:s.origin,position:s.position,"show-arrow":"",class:"custom-overlay"},{default:r(()=>[u(" Hello nancalui! ")]),_:1},8,["modelValue","origin","position"])])])}const{defineComponent:x,ref:e,computed:p}=y,h=x({setup(){const s=e(),a=e(!1),E=e(["top","right"]),b=p(()=>a.value?"\u9690\u85CF":"\u663E\u793A");return{origin:s,visible:a,title:b,position:E}}});return{render:m,...h}}()}},I='{"title":"Overlay \u906E\u7F69\u5C42","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u56FA\u5B9A\u906E\u7F69\u5C42","slug":"\u56FA\u5B9A\u906E\u7F69\u5C42"},{"level":3,"title":"\u5F39\u6027\u906E\u7F69\u5C42","slug":"\u5F39\u6027\u906E\u7F69\u5C42"},{"level":3,"title":"FixedOverlay \u53C2\u6570","slug":"fixedoverlay-\u53C2\u6570"},{"level":3,"title":"FlexibleOverlay \u53C2\u6570","slug":"flexibleoverlay-\u53C2\u6570"},{"level":3,"title":"\u7C7B\u578B\u5B9A\u4E49","slug":"\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/overlay/index.md","lastUpdated":1672994787102}',N=_('<h1 id="overlay-\u906E\u7F69\u5C42" tabindex="-1">Overlay \u906E\u7F69\u5C42 <a class="header-anchor" href="#overlay-\u906E\u7F69\u5C42" aria-hidden="true">#</a></h1><p>\u906E\u7F69\u5C42\u5C5E\u4E8E\u57FA\u7840\u7EC4\u4EF6\uFF0C\u7528\u4E8E\u6784\u5EFA\u72EC\u7ACB\u4E8E\u5F53\u524D\u9875\u9762\u5E03\u5C40\u7684\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u4F60\u9700\u8981\u5168\u5C40\u5F39\u7A97\uFF0C\u6216\u8005\u9700\u8981\u5143\u7D20\u8DDF\u968F\u529F\u80FD\uFF0C\u4FBF\u53EF\u4EE5\u4F7F\u7528\u8BE5\u7EC4\u4EF6\u3002</p><h3 id="\u56FA\u5B9A\u906E\u7F69\u5C42" tabindex="-1">\u56FA\u5B9A\u906E\u7F69\u5C42 <a class="header-anchor" href="#\u56FA\u5B9A\u906E\u7F69\u5C42" aria-hidden="true">#</a></h3>',5),q=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible = !visible"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u663E\u793A\u56FA\u5B9A\u906E\u7F69\u5C42"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-fixed-overlay")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("demo-fixed-overlay-bg"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("demo-fixed-overlay-container"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("Hello nancalui!"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-fixed-overlay")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(" visible "),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".demo-fixed-overlay-container"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 10vw"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 10vh"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" #fff"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),t(" #000"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`

`),n("span",{class:"token selector"},".demo-fixed-overlay-bg"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),j=n("h3",{id:"\u5F39\u6027\u906E\u7F69\u5C42",tabindex:"-1"},[t("\u5F39\u6027\u906E\u7F69\u5C42 "),n("a",{class:"header-anchor",href:"#\u5F39\u6027\u906E\u7F69\u5C42","aria-hidden":"true"},"#")],-1),H=n("div",null,[t("\u8DDF\u968F\u8D77\u70B9\u5143\u7D20\u79FB\u52A8\uFF0C\u5E76\u4E14\u5728\u9047\u5230\u8FB9\u754C\u65F6\u6839\u636E"),n("code",null,"position"),t("\u53C2\u6570\u6307\u5B9A\u7684\u53EF\u9009\u4F4D\u7F6E\u81EA\u52A8\u8C03\u6574\u3002")],-1),O=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"ref"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("origin"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("demo-flexible-overlay-origin"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("origin"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("br")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible = !visible"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("{{ title }}"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-flexible-overlay")]),t(),n("span",{class:"token attr-name"},"v-model"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("visible"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":origin"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("origin"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":position"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("position"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"show-arrow"),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("custom-overlay"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      Hello nancalui!
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-flexible-overlay")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref"),n("span",{class:"token punctuation"},","),t(" computed "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" origin "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" visible "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token boolean"},"false"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" position "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),n("span",{class:"token string"},"'top'"),n("span",{class:"token punctuation"},","),t(),n("span",{class:"token string"},"'right'"),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" title "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"computed"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"("),t("visible"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"?"),t(),n("span",{class:"token string"},"'\u9690\u85CF'"),t(),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u663E\u793A'"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`

    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      origin`),n("span",{class:"token punctuation"},","),t(`
      visible`),n("span",{class:"token punctuation"},","),t(`
      title`),n("span",{class:"token punctuation"},","),t(`
      position`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".demo-flexible-overlay-origin"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"align-items"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 100px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"background"),n("span",{class:"token punctuation"},":"),t(" #ecf7ff"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"color"),n("span",{class:"token punctuation"},":"),t(" #252b3a"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`

`),n("span",{class:"token selector"},".custom-overlay"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"width"),n("span",{class:"token punctuation"},":"),t(" 100px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"height"),n("span",{class:"token punctuation"},":"),t(" 100px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"line-height"),n("span",{class:"token punctuation"},":"),t(" 100px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"text-align"),n("span",{class:"token punctuation"},":"),t(" center"),n("span",{class:"token punctuation"},";"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),T=_(`<h3 id="fixedoverlay-\u53C2\u6570" tabindex="-1">FixedOverlay \u53C2\u6570 <a class="header-anchor" href="#fixedoverlay-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u906E\u7F69\u5C42\u662F\u5426\u53EF\u89C1</td><td style="text-align:left;"><a href="#%E5%9B%BA%E5%AE%9A%E9%81%AE%E7%BD%A9%E5%B1%82">\u56FA\u5B9A\u906E\u7F69\u5C42</a></td></tr><tr><td style="text-align:left;">lock-scroll</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u9501\u5B9A\u80CC\u666F\u6EDA\u52A8</td><td style="text-align:left;"></td></tr><tr><td style="text-align:left;">close-on-click-overlay</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">true</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u70B9\u51FB\u906E\u7F69\u5C42\u5173\u95ED</td><td style="text-align:left;"></td></tr></tbody></table><h3 id="flexibleoverlay-\u53C2\u6570" tabindex="-1">FlexibleOverlay \u53C2\u6570 <a class="header-anchor" href="#flexibleoverlay-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th></tr></thead><tbody><tr><td style="text-align:left;">v-model</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u63A7\u5236\u662F\u5426\u663E\u793A</td></tr><tr><td style="text-align:left;">origin</td><td style="text-align:left;"><code>HTMLElement</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u4F60\u5FC5\u987B\u6307\u5B9A\u8D77\u70B9\u5143\u7D20\u624D\u80FD\u8BA9\u906E\u7F69\u5C42\u4E0E\u8BE5\u5143\u7D20\u8FDE\u63A5\u5728\u4E00\u8D77</td></tr><tr><td style="text-align:left;">position</td><td style="text-align:left;"><a href="#placement">Placement[]</a></td><td style="text-align:left;">[&#39;bottom&#39;]</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6307\u5B9A\u663E\u793A\u4F4D\u7F6E</td></tr><tr><td style="text-align:left;">align</td><td style="text-align:left;"><code>start | end | center</code></td><td style="text-align:left;">center</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6307\u5B9A\u5BF9\u5BF9\u9F50\u65B9\u5F0F\uFF0C\u9ED8\u8BA4\u5C45\u4E2D\u5BF9\u9F50</td></tr><tr><td style="text-align:left;">offset</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">8</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u6307\u5B9A\u4E0E\u8D77\u70B9\u5143\u7D20\u7684\u95F4\u8DDD</td></tr><tr><td style="text-align:left;">show-arrow</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u662F\u5426\u663E\u793A\u7BAD\u5934</td></tr></tbody></table><h3 id="\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">\u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="placement" tabindex="-1">Placement <a class="header-anchor" href="#placement" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">Placement</span> <span class="token operator">=</span>
  <span class="token operator">|</span> <span class="token string">&#39;top&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;right&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;bottom&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;left&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;top-start&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;top-end&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;right-start&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;right-end&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;bottom-start&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;bottom-end&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;left-start&#39;</span>
  <span class="token operator">|</span> <span class="token string">&#39;left-end&#39;</span><span class="token punctuation">;</span>
</code></pre></div>`,7);function $(o,i,u,l,r,k){const d=C("render-demo-0"),c=C("demo"),g=C("render-demo-1");return D(),w("div",null,[N,v(c,{sourceCode:`<template>
  <n-button @click="visible = !visible">\u663E\u793A\u56FA\u5B9A\u906E\u7F69\u5C42</n-button>
  <n-fixed-overlay v-model="visible" class="demo-fixed-overlay-bg">
    <div class="demo-fixed-overlay-container">Hello nancalui!</div>
  </n-fixed-overlay>
</template>
<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const visible = ref(false);

    return { visible };
  },
});
<\/script>

<style>
.demo-fixed-overlay-container {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 10vw;
  height: 10vh;
  background: #fff;
  color: #000;
}

.demo-fixed-overlay-bg {
  display: flex;
  align-items: center;
  justify-content: center;
}
</style>
`},{highlight:f(()=>[q]),default:f(()=>[v(d)]),_:1}),j,v(c,{sourceCode:`<template>
  <div>
    <div ref="origin" class="demo-flexible-overlay-origin">origin</div>
    <br />
    <n-button @click="visible = !visible">{{ title }}</n-button>
    <n-flexible-overlay v-model="visible" :origin="origin" :position="position" show-arrow class="custom-overlay">
      Hello nancalui!
    </n-flexible-overlay>
  </div>
</template>
<script>
import { defineComponent, ref, computed } from 'vue';

export default defineComponent({
  setup() {
    const origin = ref();
    const visible = ref(false);
    const position = ref(['top', 'right']);
    const title = computed(() => (visible.value ? '\u9690\u85CF' : '\u663E\u793A'));

    return {
      origin,
      visible,
      title,
      position,
    };
  },
});
<\/script>

<style>
.demo-flexible-overlay-origin {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100px;
  height: 100px;
  background: #ecf7ff;
  color: #252b3a;
}

.custom-overlay {
  width: 100px;
  height: 100px;
  line-height: 100px;
  text-align: center;
}
</style>
`},{description:f(()=>[H]),highlight:f(()=>[O]),default:f(()=>[v(g)]),_:1}),T])}var L=A(V,[["render",$]]);export{I as __pageData,L as default};
