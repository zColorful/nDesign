import{V as k}from"./framework.1c17ccd8.js";import{_ as A}from"./plugin-vue_export-helper.21dcd24c.js";import{f,G as C,H as x,b as g,a6 as h,V as _,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const b={name:"component-doc",components:{"render-demo-0":function(){const{createElementVNode:a,resolveComponent:u,createVNode:e,openBlock:c,createElementBlock:o}=k,p=a("span",null,"I sit at my window this morning where the world like a passer-by stops for a moment, nods to me and goes.",-1),l=a("span",null,"There little thoughts are the rustle of leaves; they have their whisper of joy in my mind.",-1);function s(m,E){const F=u("n-divider");return c(),o("div",null,[a("div",null,[p,e(F),l])])}const{ref:i,defineComponent:r}=k,d=r({setup(){}});return{render:s,...d}}(),"render-demo-1":function(){const{createElementVNode:a,createTextVNode:u,resolveComponent:e,withCtx:c,createVNode:o,openBlock:p,createElementBlock:l}=k,s=a("span",null,"What you are you do not see, what you see is your shadow. ",-1),i=a("span",null,"My wishes are fools, they shout across thy song, my Master. Let me but listen.",-1),r=a("span",null,"I cannot choose the best. The best chooses me.",-1);function d(y,B){const v=e("n-divider");return p(),l("div",null,[a("div",null,[s,o(v,{"content-position":"left"},{default:c(()=>[u("Rabindranath Tagore")]),_:1}),i,o(v),r,o(v,{"content-position":"right"},{default:c(()=>[u("Rabindranath Tagore")]),_:1})])])}const{ref:m,defineComponent:E}=k,F=E({setup(){}});return{render:d,...F}}(),"render-demo-2":function(){const{createElementVNode:a,resolveComponent:u,createVNode:e,openBlock:c,createElementBlock:o}=k,p=a("span",null,"What language is thine, O sea?",-1),l=a("span",null,"The language of eternal question.",-1),s=a("span",null,"What language is thy answer, O sky?",-1),i=a("span",null,"The language of eternal silence.",-1);function r(F,y){const B=u("n-divider");return c(),o("div",null,[a("div",null,[p,e(B,{"border-style":"dashed"}),l]),e(B,{"border-style":"dotted"}),s,e(B,{"border-style":"double"}),i])}const{ref:d,defineComponent:m}=k,E=m({setup(){}});return{render:r,...E}}(),"render-demo-3":function(){const{createElementVNode:a,resolveComponent:u,createVNode:e,openBlock:c,createElementBlock:o}=k,p=a("span",null,"Rain",-1),l=a("span",null,"Home",-1),s=a("span",null,"Grass",-1);function i(E,F){const y=u("n-divider");return c(),o("div",null,[a("div",null,[p,e(y,{direction:"vertical"}),l,e(y,{direction:"vertical","border-style":"dashed"}),s])])}const{ref:r,defineComponent:d}=k,m=d({setup(){}});return{render:i,...m}}()}},$='{"title":"Divider \u5206\u5272\u7EBF","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u7840\u7528\u6CD5","slug":"\u57FA\u7840\u7528\u6CD5"},{"level":3,"title":"\u8BBE\u7F6E\u6587\u6848","slug":"\u8BBE\u7F6E\u6587\u6848"},{"level":3,"title":"\u865A\u7EBF","slug":"\u865A\u7EBF"},{"level":3,"title":"\u5782\u76F4\u5206\u9694\u7EBF","slug":"\u5782\u76F4\u5206\u9694\u7EBF"},{"level":3,"title":"Divider \u53C2\u6570","slug":"divider-\u53C2\u6570"},{"level":3,"title":"Rate \u4E8B\u4EF6","slug":"rate-\u4E8B\u4EF6"},{"level":3,"title":"Rate \u7C7B\u578B\u5B9A\u4E49","slug":"rate-\u7C7B\u578B\u5B9A\u4E49"}],"relativePath":"components/divider/index.md","lastUpdated":1686813632371}',w=_('<h1 id="divider-\u5206\u5272\u7EBF" tabindex="-1">Divider \u5206\u5272\u7EBF <a class="header-anchor" href="#divider-\u5206\u5272\u7EBF" aria-hidden="true">#</a></h1><p>\u533A\u9694\u5185\u5BB9\u7684\u5206\u5272\u7EBF\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><h3 id="\u57FA\u7840\u7528\u6CD5" tabindex="-1">\u57FA\u7840\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u7840\u7528\u6CD5" aria-hidden="true">#</a></h3><p>\u5BF9\u4E0D\u540C\u6BB5\u843D\u7684\u6587\u672C\u8FDB\u884C\u5206\u5272\u3002</p>',5),D=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("I sit at my window this morning where the world like a passer-by stops for a moment, nods to me and goes."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("There little thoughts are the rustle of leaves; they have their whisper of joy in my mind."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token comment"},"// const valueReadonly = ref(3.5);"),t(`
    `),n("span",{class:"token comment"},"// return {"),t(`
    `),n("span",{class:"token comment"},"//   valueReadonly,"),t(`
    `),n("span",{class:"token comment"},"// };"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),R=n("h3",{id:"\u8BBE\u7F6E\u6587\u6848",tabindex:"-1"},[t("\u8BBE\u7F6E\u6587\u6848 "),n("a",{class:"header-anchor",href:"#\u8BBE\u7F6E\u6587\u6848","aria-hidden":"true"},"#")],-1),V=n("p",null,"\u53EF\u4EE5\u5728\u5206\u5272\u7EBF\u4E0A\u81EA\u5B9A\u4E49\u6587\u672C\u5185\u5BB9\u3002",-1),T=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("What you are you do not see, what you see is your shadow. "),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"content-position"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("left"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("Rabindranath Tagore"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-divider")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("My wishes are fools, they shout across thy song, my Master. Let me but listen."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),n("span",{class:"token punctuation"},">")]),t(),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-divider")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("I cannot choose the best. The best chooses me."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"content-position"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("right"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("Rabindranath Tagore"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-divider")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token comment"},"// const valueReadonly = ref(3.5);"),t(`
    `),n("span",{class:"token comment"},"// return {"),t(`
    `),n("span",{class:"token comment"},"//   valueReadonly,"),t(`
    `),n("span",{class:"token comment"},"// };"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),N=n("h3",{id:"\u865A\u7EBF",tabindex:"-1"},[t("\u865A\u7EBF "),n("a",{class:"header-anchor",href:"#\u865A\u7EBF","aria-hidden":"true"},"#")],-1),q=n("p",null,"\u60A8\u53EF\u4EE5\u8BBE\u7F6E\u5206\u9694\u7B26\u7684\u6837\u5F0F\u3002",-1),W=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("What language is thine, O sea?"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"border-style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("dashed"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("The language of eternal question."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"border-style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("dotted"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("What language is thy answer, O sky?"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"border-style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("double"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("The language of eternal silence."),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token comment"},"// const valueReadonly = ref(3.5);"),t(`
    `),n("span",{class:"token comment"},"// return {"),t(`
    `),n("span",{class:"token comment"},"//   valueReadonly,"),t(`
    `),n("span",{class:"token comment"},"// };"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),j=n("h3",{id:"\u5782\u76F4\u5206\u9694\u7EBF",tabindex:"-1"},[t("\u5782\u76F4\u5206\u9694\u7EBF "),n("a",{class:"header-anchor",href:"#\u5782\u76F4\u5206\u9694\u7EBF","aria-hidden":"true"},"#")],-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("Rain"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"direction"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("vertical"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("Home"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-divider")]),t(),n("span",{class:"token attr-name"},"direction"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("vertical"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"border-style"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("dashed"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("span")]),n("span",{class:"token punctuation"},">")]),t("Grass"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("span")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" ref"),n("span",{class:"token punctuation"},","),t(" defineComponent "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token comment"},"// const valueReadonly = ref(3.5);"),t(`
    `),n("span",{class:"token comment"},"// return {"),t(`
    `),n("span",{class:"token comment"},"//   valueReadonly,"),t(`
    `),n("span",{class:"token comment"},"// };"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),M=_(`<h3 id="divider-\u53C2\u6570" tabindex="-1">Divider \u53C2\u6570 <a class="header-anchor" href="#divider-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4\u503C</th><th style="text-align:left;">\u63CF\u8FF0</th><th>\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">read</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u662F\u5426\u4E3A\u53EA\u8BFB\u6A21\u5F0F\uFF0C\u53EA\u8BFB\u6A21\u5F0F\u65E0\u6CD5\u4EA4\u4E92</td><td><a href="#%E5%8F%AA%E8%AF%BB%E6%A8%A1%E5%BC%8F">\u53EA\u8BFB\u6A21\u5F0F</a></td></tr><tr><td style="text-align:left;">count</td><td style="text-align:left;"><code>number</code></td><td style="text-align:left;">5</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u603B\u7B49\u7EA7\u6570</td><td><a href="#%E5%8F%AA%E8%AF%BB%E6%A8%A1%E5%BC%8F">\u53EA\u8BFB\u6A21\u5F0F</a></td></tr><tr><td style="text-align:left;">distance</td><td style="text-align:left;"><code>number|string</code></td><td style="text-align:left;">20</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u8DDD\u79BB\u4E24\u8FB9\u7684\u957F\u5EA6\uFF0C\u5F53 contentPosition \u4E3A left,\u4E3A\u8DDD\u79BB\u5DE6\u8FB9\u7684\u957F\u5EA6\uFF0CcontentPosition \u4E3A\u53F3\u65F6\u8DDD\u79BB\u53F3\u8FB9\u7684\u957F\u5EA6\uFF0CcontentPosition \u4E3A center \u65F6\u6B64\u9879\u8BBE\u7F6E\u65E0\u6548</td><td><a href="#%E5%8F%AA%E8%AF%BB%E6%A8%A1%E5%BC%8F">\u53EA\u8BFB\u6A21\u5F0F</a></td></tr><tr><td style="text-align:left;">type</td><td style="text-align:left;"><a href="#ratestatustype">RateStatusType</a></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BBE\u7F6E\u5F53\u524D\u8BC4\u5206\u7684\u7C7B\u578B\uFF0C\u4E0D\u540C\u7C7B\u578B\u5BF9\u5E94\u4E0D\u540C\u989C\u8272</td><td><a href="#%E4%BD%BF%E7%94%A8-type-%E5%8F%82%E6%95%B0">\u4F7F\u7528 type \u53C2\u6570</a></td></tr><tr><td style="text-align:left;">color</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u661F\u661F\u989C\u8272</td><td><a href="#%E5%8A%A8%E6%80%81%E6%A8%A1%E5%BC%8F-%E8%87%AA%E5%AE%9A%E4%B9%89">\u52A8\u6001\u6A21\u5F0F-\u81EA\u5B9A\u4E49</a></td></tr><tr><td style="text-align:left;">icon</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BC4\u5206\u56FE\u6807\u7684\u6837\u5F0F\uFF0C\u53EA\u652F\u6301 nancalui \u56FE\u6807\u5E93\u4E2D\u6240\u6709\u56FE\u6807</td><td><a href="#%E5%8A%A8%E6%80%81%E6%A8%A1%E5%BC%8F">\u52A8\u6001\u6A21\u5F0F</a></td></tr><tr><td style="text-align:left;">character</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">--</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u8BC4\u5206\u56FE\u6807\u7684\u6837\u5F0F\uFF0Cicon \u4E0E character \u53EA\u80FD\u8BBE\u7F6E\u5176\u4E2D\u4E00\u4E2A</td><td><a href="#%E5%8A%A8%E6%80%81%E6%A8%A1%E5%BC%8F-%E8%87%AA%E5%AE%9A%E4%B9%89">\u52A8\u6001\u6A21\u5F0F-\u81EA\u5B9A\u4E49</a></td></tr><tr><td style="text-align:left;">allow-half</td><td style="text-align:left;"><code>boolean</code></td><td style="text-align:left;">false</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u52A8\u6001\u6A21\u5F0F\u4E0B\u662F\u5426\u5141\u8BB8\u534A\u9009</td><td><a href="#%E5%8D%8A%E9%80%89%E6%A8%A1%E5%BC%8F">\u534A\u9009\u6A21\u5F0F</a></td></tr></tbody></table><h3 id="rate-\u4E8B\u4EF6" tabindex="-1">Rate \u4E8B\u4EF6 <a class="header-anchor" href="#rate-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u4E8B\u4EF6\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u56DE\u8C03\u53C2\u6570</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">change</td><td style="text-align:left;"><code>EventEmitter&lt;number&gt;</code></td><td style="text-align:left;">\u5206\u503C\u6539\u53D8\u65F6\u89E6\u53D1</td><td style="text-align:left;">\u6539\u53D8\u540E\u7684\u5206\u503C</td><td style="text-align:left;"><a href="#%E5%8D%8A%E9%80%89%E6%A8%A1%E5%BC%8F">\u534A\u9009\u6A21\u5F0F</a></td></tr></tbody></table><h3 id="rate-\u7C7B\u578B\u5B9A\u4E49" tabindex="-1">Rate \u7C7B\u578B\u5B9A\u4E49 <a class="header-anchor" href="#rate-\u7C7B\u578B\u5B9A\u4E49" aria-hidden="true">#</a></h3><h4 id="ratestatustype" tabindex="-1">RateStatusType <a class="header-anchor" href="#ratestatustype" aria-hidden="true">#</a></h4><div class="language-ts"><pre><code><span class="token keyword">type</span> <span class="token class-name">RateStatusType</span> <span class="token operator">=</span> <span class="token string">&#39;success&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;warning&#39;</span> <span class="token operator">|</span> <span class="token string">&#39;error&#39;</span><span class="token punctuation">;</span>
</code></pre></div>`,7);function O(a,u,e,c,o,p){const l=f("render-demo-0"),s=f("demo"),i=f("render-demo-1"),r=f("render-demo-2"),d=f("render-demo-3");return C(),x("div",null,[w,g(s,{sourceCode:`<template>
  <div>
    <span>I sit at my window this morning where the world like a passer-by stops for a moment, nods to me and goes.</span>
    <n-divider />
    <span>There little thoughts are the rustle of leaves; they have their whisper of joy in my mind.</span>
  </div>
</template>
<script>
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    // const valueReadonly = ref(3.5);
    // return {
    //   valueReadonly,
    // };
  },
});
<\/script>
`},{highlight:h(()=>[D]),default:h(()=>[g(l)]),_:1}),R,V,g(s,{sourceCode:`<template>
  <div>
    <span>What you are you do not see, what you see is your shadow. </span>
    <n-divider content-position="left">Rabindranath Tagore</n-divider>
    <span>My wishes are fools, they shout across thy song, my Master. Let me but listen.</span>
    <n-divider> </n-divider>
    <span>I cannot choose the best. The best chooses me.</span>
    <n-divider content-position="right">Rabindranath Tagore</n-divider>
  </div>
</template>
<script>
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    // const valueReadonly = ref(3.5);
    // return {
    //   valueReadonly,
    // };
  },
});
<\/script>
`},{highlight:h(()=>[T]),default:h(()=>[g(i)]),_:1}),N,q,g(s,{sourceCode:`<template>
  <div>
    <span>What language is thine, O sea?</span>
    <n-divider border-style="dashed" />
    <span>The language of eternal question.</span>
  </div>
  <n-divider border-style="dotted" />
  <span>What language is thy answer, O sky?</span>
  <n-divider border-style="double" />
  <span>The language of eternal silence.</span>
</template>
<script>
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    // const valueReadonly = ref(3.5);
    // return {
    //   valueReadonly,
    // };
  },
});
<\/script>
`},{highlight:h(()=>[W]),default:h(()=>[g(r)]),_:1}),j,g(s,{sourceCode:`<template>
  <div>
    <span>Rain</span>
    <n-divider direction="vertical" />
    <span>Home</span>
    <n-divider direction="vertical" border-style="dashed" />
    <span>Grass</span>
  </div>
</template>
<script>
import { ref, defineComponent } from 'vue';

export default defineComponent({
  setup() {
    // const valueReadonly = ref(3.5);
    // return {
    //   valueReadonly,
    // };
  },
});
<\/script>
`},{highlight:h(()=>[I]),default:h(()=>[g(d)]),_:1}),M])}var L=A(b,[["render",O]]);export{$ as __pageData,L as default};
