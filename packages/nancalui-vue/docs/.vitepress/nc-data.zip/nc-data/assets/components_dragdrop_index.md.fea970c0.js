import{V as i}from"./framework.1c17ccd8.js";import{_ as S}from"./plugin-vue_export-helper.21dcd24c.js";import{f as k,G as q,H as V,b as g,a6 as r,V as v,I as a,k as n}from"./framework.1f85532f.js";import"./framework.40290dff.js";const w={name:"component-doc",components:{"render-demo-0":function(){const{createElementVNode:t,createTextVNode:c,resolveDirective:u,openBlock:s,createElementBlock:e,withDirectives:o}=i,p={class:"dragdrop-card-container"},l={class:"dragdrop-card"},E=t("div",{class:"dragdrop-card-header"},"Draggable Item",-1),h={class:"dragdrop-card-block drag"},m={id:"draggable-item",class:"draggable-item"},F={id:"draggable-item2",class:"draggable-item"},D={class:"dragdrop-card"},b=[t("div",{class:"dragdrop-card-header"},"Drop Area",-1),t("div",{class:"dragdrop-card-block droppable"},null,-1)],C={class:"dragdrop-card"},_=[t("div",{class:"dragdrop-card-header"},"Drop Area With Sortable",-1),t("div",{class:"dragdrop-card-block"},null,-1)];function f(L,O){const d=u("n-draggable"),x=u("n-droppable"),y=u("n-sortable");return s(),e("div",null,[t("div",p,[t("div",l,[E,t("div",h,[o((s(),e("div",m,[c(" VSCode ")])),[[d,{dragScope:"default-css",dragData:{item:"item",parent:"list1"}}]]),o((s(),e("div",F,[c(" Sublime ")])),[[d,{dragScope:"default-css",dragData:{item:"item",parent:"list1"}}]])])]),o((s(),e("div",D,b)),[[x]]),o((s(),e("div",C,_)),[[y]])])])}const{defineComponent:A}=i,B=A({setup(){return{msg:"Dragdrop \u62D6\u62FD \u7EC4\u4EF6\u6587\u6863\u793A\u4F8B"}}});return{render:f,...B}}()}},M='{"title":"Dragdrop \u62D6\u62FD","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"Draggable \u53C2\u6570","slug":"draggable-\u53C2\u6570"},{"level":3,"title":"Draggable \u4E8B\u4EF6","slug":"draggable-\u4E8B\u4EF6"}],"relativePath":"components/dragdrop/index.md","lastUpdated":1685348482055}',N=v('<h1 id="dragdrop-\u62D6\u62FD" tabindex="-1">Dragdrop \u62D6\u62FD <a class="header-anchor" href="#dragdrop-\u62D6\u62FD" aria-hidden="true">#</a></h1><p>\u62D6\u62FD\u7EC4\u4EF6\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u9700\u8981\u4F7F\u7528\u6570\u4E2A\u64CD\u4F5C\u6B65\u9AA4\uFF0C\u4E14\u6B65\u9AA4\u7684\u987A\u5E8F\u9700\u8981\u7075\u6D3B\u8C03\u6574\u65F6\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),z=a("div",null,"\u4ECE\u4E00\u4E2A container \u62D6\u52A8\u5230\u53E6\u5916\u4E00\u4E2A container\u3002",-1),I=a("div",{class:"language-vue"},[a("pre",null,[a("code",null,[a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("template")]),a("span",{class:"token punctuation"},">")]),n(`
  `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-container"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-header"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n("Draggable Item"),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-block drag"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n(`
        `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(`
          `),a("span",{class:"token attr-name"},"id"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("draggable-item"),a("span",{class:"token punctuation"},'"')]),n(`
          `),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("draggable-item"),a("span",{class:"token punctuation"},'"')]),n(`
          `),a("span",{class:"token attr-name"},"v-n-draggable"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n(`{
            dragScope: 'default-css',
            dragData: { item: 'item', parent: 'list1' },
          }`),a("span",{class:"token punctuation"},'"')]),n(`
        `),a("span",{class:"token punctuation"},">")]),n(`
          VSCode
        `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
        `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(`
          `),a("span",{class:"token attr-name"},"id"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("draggable-item2"),a("span",{class:"token punctuation"},'"')]),n(`
          `),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("draggable-item"),a("span",{class:"token punctuation"},'"')]),n(`
          `),a("span",{class:"token attr-name"},"v-n-draggable"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n(`{
            dragScope: 'default-css',
            dragData: { item: 'item', parent: 'list1' },
          }`),a("span",{class:"token punctuation"},'"')]),n(`
        `),a("span",{class:"token punctuation"},">")]),n(`
          Sublime
        `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card"),a("span",{class:"token punctuation"},'"')]),n(),a("span",{class:"token attr-name"},"v-n-droppable"),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-header"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n("Drop Area"),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-block droppable"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card"),a("span",{class:"token punctuation"},'"')]),n(),a("span",{class:"token attr-name"},"v-n-sortable"),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-header"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),n("Drop Area With Sortable"),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
      `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("div")]),n(),a("span",{class:"token attr-name"},"class"),a("span",{class:"token attr-value"},[a("span",{class:"token punctuation attr-equals"},"="),a("span",{class:"token punctuation"},'"'),n("dragdrop-card-block"),a("span",{class:"token punctuation"},'"')]),a("span",{class:"token punctuation"},">")]),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
    `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
  `),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("div")]),a("span",{class:"token punctuation"},">")]),n(`
`),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("template")]),a("span",{class:"token punctuation"},">")]),n(`

`),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("script")]),a("span",{class:"token punctuation"},">")]),a("span",{class:"token script"},[a("span",{class:"token language-javascript"},[n(`
`),a("span",{class:"token keyword"},"import"),n(),a("span",{class:"token punctuation"},"{"),n(" defineComponent "),a("span",{class:"token punctuation"},"}"),n(),a("span",{class:"token keyword"},"from"),n(),a("span",{class:"token string"},"'vue'"),a("span",{class:"token punctuation"},";"),n(`

`),a("span",{class:"token keyword"},"export"),n(),a("span",{class:"token keyword"},"default"),n(),a("span",{class:"token function"},"defineComponent"),a("span",{class:"token punctuation"},"("),a("span",{class:"token punctuation"},"{"),n(`
  `),a("span",{class:"token function"},"setup"),a("span",{class:"token punctuation"},"("),a("span",{class:"token punctuation"},")"),n(),a("span",{class:"token punctuation"},"{"),n(`
    `),a("span",{class:"token keyword"},"return"),n(),a("span",{class:"token punctuation"},"{"),n(`
      `),a("span",{class:"token literal-property property"},"msg"),a("span",{class:"token operator"},":"),n(),a("span",{class:"token string"},"'Dragdrop \u62D6\u62FD \u7EC4\u4EF6\u6587\u6863\u793A\u4F8B'"),a("span",{class:"token punctuation"},","),n(`
    `),a("span",{class:"token punctuation"},"}"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token punctuation"},"}"),a("span",{class:"token punctuation"},","),n(`
`),a("span",{class:"token punctuation"},"}"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
`)])]),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("script")]),a("span",{class:"token punctuation"},">")]),n(`

`),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"<"),n("style")]),a("span",{class:"token punctuation"},">")]),a("span",{class:"token style"},[a("span",{class:"token language-css"},[n(`
`),a("span",{class:"token selector"},".dragdrop-card-container"),n(),a("span",{class:"token punctuation"},"{"),n(`
  `),a("span",{class:"token property"},"display"),a("span",{class:"token punctuation"},":"),n(" flex"),a("span",{class:"token punctuation"},";"),n(`
`),a("span",{class:"token punctuation"},"}"),n(`

`),a("span",{class:"token selector"},".dragdrop-card"),n(),a("span",{class:"token punctuation"},"{"),n(`
  `),a("span",{class:"token property"},"padding"),a("span",{class:"token punctuation"},":"),n(" 12px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"margin-right"),a("span",{class:"token punctuation"},":"),n(" 12px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"border"),a("span",{class:"token punctuation"},":"),n(" 1px solid #e1e1e1"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"border"),a("span",{class:"token punctuation"},":"),n(" 1px solid "),a("span",{class:"token function"},"var"),a("span",{class:"token punctuation"},"("),n("--nancalui-dividing-line"),a("span",{class:"token punctuation"},","),n(" #e1e1e1"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
`),a("span",{class:"token punctuation"},"}"),n(`

`),a("span",{class:"token selector"},".dragdrop-card .dragdrop-card-header"),n(),a("span",{class:"token punctuation"},"{"),n(`
  `),a("span",{class:"token property"},"padding-bottom"),a("span",{class:"token punctuation"},":"),n(" 12px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"font-size"),a("span",{class:"token punctuation"},":"),n(" 12px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"font-size"),a("span",{class:"token punctuation"},":"),n(),a("span",{class:"token function"},"var"),a("span",{class:"token punctuation"},"("),n("--nancalui-font-size"),a("span",{class:"token punctuation"},","),n(" 12px"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
`),a("span",{class:"token punctuation"},"}"),n(`

`),a("span",{class:"token selector"},".draggable-item"),n(),a("span",{class:"token punctuation"},"{"),n(`
  `),a("span",{class:"token property"},"padding"),a("span",{class:"token punctuation"},":"),n(" 0 16px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"height"),a("span",{class:"token punctuation"},":"),n(" 30px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"border"),a("span",{class:"token punctuation"},":"),n(" 1px solid #447dfd"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"border"),a("span",{class:"token punctuation"},":"),n(" 1px solid "),a("span",{class:"token function"},"var"),a("span",{class:"token punctuation"},"("),n("--nancalui-brand"),a("span",{class:"token punctuation"},","),n(" #447dfd"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"color"),a("span",{class:"token punctuation"},":"),n(" #fff"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"color"),a("span",{class:"token punctuation"},":"),n(),a("span",{class:"token function"},"var"),a("span",{class:"token punctuation"},"("),n("--nancalui-light-text"),a("span",{class:"token punctuation"},","),n(" #fff"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"margin-bottom"),a("span",{class:"token punctuation"},":"),n(" 5px"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"line-height"),a("span",{class:"token punctuation"},":"),n(" 1.5"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"background-color"),a("span",{class:"token punctuation"},":"),n(" #447dfd"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"background-color"),a("span",{class:"token punctuation"},":"),n(),a("span",{class:"token function"},"var"),a("span",{class:"token punctuation"},"("),n("--nancalui-brand"),a("span",{class:"token punctuation"},","),n(" #447dfd"),a("span",{class:"token punctuation"},")"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"display"),a("span",{class:"token punctuation"},":"),n(" flex"),a("span",{class:"token punctuation"},";"),n(`
  `),a("span",{class:"token property"},"align-items"),a("span",{class:"token punctuation"},":"),n(" center"),a("span",{class:"token punctuation"},";"),n(`
`),a("span",{class:"token punctuation"},"}"),n(`
`)])]),a("span",{class:"token tag"},[a("span",{class:"token tag"},[a("span",{class:"token punctuation"},"</"),n("style")]),a("span",{class:"token punctuation"},">")]),n(`
`)])])],-1),$=v('<h3 id="draggable-\u53C2\u6570" tabindex="-1">Draggable \u53C2\u6570 <a class="header-anchor" href="#draggable-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th>\u53C2\u6570</th><th>\u7C7B\u578B</th><th>\u9ED8\u8BA4</th><th>\u8BF4\u660E</th><th>\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td>dragData</td><td>any</td><td>--</td><td>\u53EF\u9009\uFF0C\u8F6C\u9012\u7ED9 DropEvent \u4E8B\u4EF6\u7684\u6570\u636E</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dragScope</td><td>string | Array&lt;string&gt;</td><td>&#39;default&#39;</td><td>\u53EF\u9009\uFF0C\u9650\u5236 drop \u7684\u4F4D\u7F6E\uFF0C\u5FC5\u987B\u5339\u914D\u5BF9\u5E94\u7684 dropScope</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table><h3 id="draggable-\u4E8B\u4EF6" tabindex="-1">Draggable \u4E8B\u4EF6 <a class="header-anchor" href="#draggable-\u4E8B\u4EF6" aria-hidden="true">#</a></h3><table><thead><tr><th>\u4E8B\u4EF6</th><th>\u7C7B\u578B</th><th>\u8BF4\u660E</th><th>\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td>dragStartEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>\u5F00\u59CB\u62D6\u52A8\u7684 DragStart \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dragEndEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>\u62D6\u52A8\u7ED3\u675F\u7684 DragEnd \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dropEndEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>\u653E\u7F6E\u7ED3\u675F\u7684 Drop \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dragEnterEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>drag \u5143\u7D20\u8FDB\u5165\u7684 dragenter \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dragOverEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>drag \u5143\u7D20\u5728 drop \u533A\u57DF\u4E0A\u7684 dragover \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dragLeaveEvent</td><td>EventEmitter&lt;DragEvent&gt;</td><td>drag \u5143\u7D20\u79BB\u5F00\u7684 dragleave \u4E8B\u4EF6</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td>dropEvent</td><td>EventEmitter&lt;DropEvent&gt;</td><td>\u653E\u7F6E\u4E00\u4E2A\u5143\u7D20, \u63A5\u6536\u7684\u4E8B\u4EF6\uFF0C\u5176\u4E2D nativeEvent \u8868\u793A\u539F\u751F\u7684 drop \u4E8B\u4EF6\uFF0C\u5176\u4ED6\u89C1\u5B9A\u4E49\u6CE8\u91CA</td><td><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table>',4);function T(t,c,u,s,e,o){const p=k("render-demo-0"),l=k("demo");return q(),V("div",null,[N,g(l,{sourceCode:`<template>
  <div class="dragdrop-card-container">
    <div class="dragdrop-card">
      <div class="dragdrop-card-header">Draggable Item</div>
      <div class="dragdrop-card-block drag">
        <div
          id="draggable-item"
          class="draggable-item"
          v-n-draggable="{
            dragScope: 'default-css',
            dragData: { item: 'item', parent: 'list1' },
          }"
        >
          VSCode
        </div>
        <div
          id="draggable-item2"
          class="draggable-item"
          v-n-draggable="{
            dragScope: 'default-css',
            dragData: { item: 'item', parent: 'list1' },
          }"
        >
          Sublime
        </div>
      </div>
    </div>
    <div class="dragdrop-card" v-n-droppable>
      <div class="dragdrop-card-header">Drop Area</div>
      <div class="dragdrop-card-block droppable"></div>
    </div>
    <div class="dragdrop-card" v-n-sortable>
      <div class="dragdrop-card-header">Drop Area With Sortable</div>
      <div class="dragdrop-card-block"></div>
    </div>
  </div>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  setup() {
    return {
      msg: 'Dragdrop \u62D6\u62FD \u7EC4\u4EF6\u6587\u6863\u793A\u4F8B',
    };
  },
});
<\/script>

<style>
.dragdrop-card-container {
  display: flex;
}

.dragdrop-card {
  padding: 12px;
  margin-right: 12px;
  border: 1px solid #e1e1e1;
  border: 1px solid var(--nancalui-dividing-line, #e1e1e1);
}

.dragdrop-card .dragdrop-card-header {
  padding-bottom: 12px;
  font-size: 12px;
  font-size: var(--nancalui-font-size, 12px);
}

.draggable-item {
  padding: 0 16px;
  height: 30px;
  border: 1px solid #447dfd;
  border: 1px solid var(--nancalui-brand, #447dfd);
  color: #fff;
  color: var(--nancalui-light-text, #fff);
  margin-bottom: 5px;
  line-height: 1.5;
  background-color: #447dfd;
  background-color: var(--nancalui-brand, #447dfd);
  display: flex;
  align-items: center;
}
</style>
`},{description:r(()=>[z]),highlight:r(()=>[I]),default:r(()=>[g(p)]),_:1}),$])}var Q=S(w,[["render",T]]);export{M as __pageData,Q as default};
