import{V as f}from"./framework.1c17ccd8.js";import{_ as B}from"./plugin-vue_export-helper.21dcd24c.js";import{f as m,G as h,H as _,b as F,a6 as k,V as E,I as n,k as t}from"./framework.1f85532f.js";import"./framework.40290dff.js";const b={name:"component-doc",components:{"render-demo-0":function(){const{resolveComponent:e,createVNode:a,createTextVNode:o,withCtx:u,createElementVNode:c,openBlock:d,createElementBlock:p}=f,l={class:"out-box-steps"},A={class:"box"};function C(s,i){const x=e("n-customize-steps"),r=e("n-button");return d(),p("div",null,[c("div",l,[a(x,{stepsData:s.stepsData,nowIndex:s.nowIndex},null,8,["stepsData","nowIndex"]),c("div",A,[a(r,{variant:"solid",color:"primary",onClick:s.goNext},{default:u(()=>[o("\u4E0B\u4E00\u6B65")]),_:1},8,["onClick"]),a(r,{color:"primary",onClick:s.goPrev},{default:u(()=>[o("\u4E0A\u4E00\u6B65")]),_:1},8,["onClick"])])])])}const{defineComponent:y,ref:g}=f,v=y({setup(){const s=g(0),i=g([{label:"\u57FA\u7840\u4FE1\u606F"},{label:"\u5173\u8054\u6570\u636E\u6E90"},{label:"\u6388\u6743\u4EBA\u5458"},{label:"\u6838\u5BF9\u4FE1\u606F"}]);return{nowIndex:s,stepsData:i,goNext:()=>{s.value>=i.value.length-1||s.value++},goPrev:()=>{s.value<=0||s.value--}}}});return{render:C,...v}}()}},$='{"title":"CustomizeSteps \u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761","description":"","frontmatter":{},"headers":[{"level":3,"title":"\u57FA\u672C\u7528\u6CD5","slug":"\u57FA\u672C\u7528\u6CD5"},{"level":3,"title":"CustomizeSteps \u53C2\u6570","slug":"customizesteps-\u53C2\u6570"}],"relativePath":"components/customize-steps/index.md","lastUpdated":1675667989282}',D=E('<h1 id="customizesteps-\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761" tabindex="-1">CustomizeSteps \u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761 <a class="header-anchor" href="#customizesteps-\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761" aria-hidden="true">#</a></h1><p>\u81EA\u5B9A\u4E49\u6B65\u9AA4\u6761\u3002</p><h4 id="\u4F55\u65F6\u4F7F\u7528" tabindex="-1">\u4F55\u65F6\u4F7F\u7528 <a class="header-anchor" href="#\u4F55\u65F6\u4F7F\u7528" aria-hidden="true">#</a></h4><p>\u5F53\u65B0\u5EFA\u4EFB\u52A1\u5177\u6709\u660E\u786E\u7684\u5148\u540E\u6B65\u9AA4\u6B21\u5E8F\u65F6\u4F7F\u7528\u3002</p><h3 id="\u57FA\u672C\u7528\u6CD5" tabindex="-1">\u57FA\u672C\u7528\u6CD5 <a class="header-anchor" href="#\u57FA\u672C\u7528\u6CD5" aria-hidden="true">#</a></h3>',5),w=n("div",null,[n("code",null,"stepsData"),t("\u6B65\u9AA4\u6761\u6587\u672C\u63CF\u8FF0"),n("code",null,"nowIndex"),t("\u5F53\u524D\u6B65\u9AA4\u6761\u8FDB\u5EA6"),n("code",null,"icon"),t("\u5B8C\u6210\u6B65\u51D1\u5C55\u793A\u56FE\u6807\u540D"),n("code",null,"iconClass"),t("\u7ED9\u56FE\u6807\u65B0\u589E\u7C7B\u540D\u3002")],-1),I=n("div",{class:"language-vue"},[n("pre",null,[n("code",null,[n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("out-box-steps"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-customize-steps")]),t(),n("span",{class:"token attr-name"},":stepsData"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("stepsData"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},":nowIndex"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("nowIndex"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token punctuation"},"/>")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("div")]),t(),n("span",{class:"token attr-name"},"class"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("box"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"variant"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("solid"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"color"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("primary"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("goNext"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u4E0B\u4E00\u6B65"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
      `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("n-button")]),t(),n("span",{class:"token attr-name"},"color"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("primary"),n("span",{class:"token punctuation"},'"')]),t(),n("span",{class:"token attr-name"},"@click"),n("span",{class:"token attr-value"},[n("span",{class:"token punctuation attr-equals"},"="),n("span",{class:"token punctuation"},'"'),t("goPrev"),n("span",{class:"token punctuation"},'"')]),n("span",{class:"token punctuation"},">")]),t("\u4E0A\u4E00\u6B65"),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("n-button")]),n("span",{class:"token punctuation"},">")]),t(`
    `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
  `),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("div")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("template")]),n("span",{class:"token punctuation"},">")]),t(`

`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("script")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token script"},[n("span",{class:"token language-javascript"},[t(`
`),n("span",{class:"token keyword"},"import"),t(),n("span",{class:"token punctuation"},"{"),t(" defineComponent"),n("span",{class:"token punctuation"},","),t(" ref "),n("span",{class:"token punctuation"},"}"),t(),n("span",{class:"token keyword"},"from"),t(),n("span",{class:"token string"},"'vue'"),n("span",{class:"token punctuation"},";"),t(`

`),n("span",{class:"token keyword"},"export"),t(),n("span",{class:"token keyword"},"default"),t(),n("span",{class:"token function"},"defineComponent"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token function"},"setup"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" nowIndex "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(" stepsData "),n("span",{class:"token operator"},"="),t(),n("span",{class:"token function"},"ref"),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},"["),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u57FA\u7840\u4FE1\u606F'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u5173\u8054\u6570\u636E\u6E90'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6388\u6743\u4EBA\u5458'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"{"),t(`
        `),n("span",{class:"token literal-property property"},"label"),n("span",{class:"token operator"},":"),t(),n("span",{class:"token string"},"'\u6838\u5BF9\u4FE1\u606F'"),n("span",{class:"token punctuation"},","),t(`
      `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"]"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"goNext"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("nowIndex"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},">="),t(" stepsData"),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token punctuation"},"."),t("length "),n("span",{class:"token operator"},"-"),t(),n("span",{class:"token number"},"1"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token keyword"},"return"),n("span",{class:"token punctuation"},";"),t(`
      nowIndex`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"++"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"const"),t(),n("span",{class:"token function-variable function"},"goPrev"),t(),n("span",{class:"token operator"},"="),t(),n("span",{class:"token punctuation"},"("),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token operator"},"=>"),t(),n("span",{class:"token punctuation"},"{"),t(`
      `),n("span",{class:"token keyword"},"if"),t(),n("span",{class:"token punctuation"},"("),t("nowIndex"),n("span",{class:"token punctuation"},"."),t("value "),n("span",{class:"token operator"},"<="),t(),n("span",{class:"token number"},"0"),n("span",{class:"token punctuation"},")"),t(),n("span",{class:"token keyword"},"return"),n("span",{class:"token punctuation"},";"),t(`
      nowIndex`),n("span",{class:"token punctuation"},"."),t("value"),n("span",{class:"token operator"},"--"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
    `),n("span",{class:"token keyword"},"return"),t(),n("span",{class:"token punctuation"},"{"),t(`
      nowIndex`),n("span",{class:"token punctuation"},","),t(`
      stepsData`),n("span",{class:"token punctuation"},","),t(`
      goNext`),n("span",{class:"token punctuation"},","),t(`
      goPrev`),n("span",{class:"token punctuation"},","),t(`
    `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},","),t(`
`),n("span",{class:"token punctuation"},"}"),n("span",{class:"token punctuation"},")"),n("span",{class:"token punctuation"},";"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("script")]),n("span",{class:"token punctuation"},">")]),t(`
`),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"<"),t("style")]),n("span",{class:"token punctuation"},">")]),n("span",{class:"token style"},[n("span",{class:"token language-css"},[t(`
`),n("span",{class:"token selector"},".box"),t(),n("span",{class:"token punctuation"},"{"),t(`
  `),n("span",{class:"token property"},"display"),n("span",{class:"token punctuation"},":"),t(" flex"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"justify-content"),n("span",{class:"token punctuation"},":"),t(" flex-end"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token property"},"margin"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token selector"},"button"),t(),n("span",{class:"token punctuation"},"{"),t(`
    `),n("span",{class:"token property"},"margin-left"),n("span",{class:"token punctuation"},":"),t(" 10px"),n("span",{class:"token punctuation"},";"),t(`
  `),n("span",{class:"token punctuation"},"}"),t(`
`),n("span",{class:"token punctuation"},"}"),t(`
`)])]),n("span",{class:"token tag"},[n("span",{class:"token tag"},[n("span",{class:"token punctuation"},"</"),t("style")]),n("span",{class:"token punctuation"},">")]),t(`
`)])])],-1),N=E('<h3 id="customizesteps-\u53C2\u6570" tabindex="-1">CustomizeSteps \u53C2\u6570 <a class="header-anchor" href="#customizesteps-\u53C2\u6570" aria-hidden="true">#</a></h3><table><thead><tr><th style="text-align:left;">\u53C2\u6570\u540D</th><th style="text-align:left;">\u7C7B\u578B</th><th style="text-align:left;">\u9ED8\u8BA4</th><th style="text-align:left;">\u8BF4\u660E</th><th style="text-align:left;">\u8DF3\u8F6C Demo</th></tr></thead><tbody><tr><td style="text-align:left;">stepsData</td><td style="text-align:left;"><code>Array</code></td><td style="text-align:left;">&#39;[{label: &#39;\u57FA\u7840\u4FE1\u606F&#39;}]&#39;</td><td style="text-align:left;">\u5FC5\u9009\uFF0C\u6B65\u9AA4\u6761\u63CF\u8FF0\u6587\u672C</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">nowIndex</td><td style="text-align:left;"><code>Number</code></td><td style="text-align:left;">\u53EF\u9009\uFF0C\u9ED8\u8BA4 0</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u521D\u59CB\u5316\u8FDB\u5EA6</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">icon</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;right-o&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5B8C\u6210\u6B65\u9AA4\u5C55\u793A\u56FE\u6807 icon \u56FE\u6807 name</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr><tr><td style="text-align:left;">iconClass</td><td style="text-align:left;"><code>string</code></td><td style="text-align:left;">&#39;icon&#39;</td><td style="text-align:left;">\u53EF\u9009\uFF0C\u5B8C\u6210\u6B65\u9AA4\u5C55\u793A\u56FE\u6807\u81EA\u5B9A\u4E49\u7C7B\u540D</td><td style="text-align:left;"><a href="#%E5%9F%BA%E6%9C%AC%E7%94%A8%E6%B3%95">\u57FA\u672C\u7528\u6CD5</a></td></tr></tbody></table>',2);function z(e,a,o,u,c,d){const p=m("render-demo-0"),l=m("demo");return h(),_("div",null,[D,F(l,{sourceCode:`<template>
  <div class="out-box-steps">
    <n-customize-steps :stepsData="stepsData" :nowIndex="nowIndex" />
    <div class="box">
      <n-button variant="solid" color="primary" @click="goNext">\u4E0B\u4E00\u6B65</n-button>
      <n-button color="primary" @click="goPrev">\u4E0A\u4E00\u6B65</n-button>
    </div>
  </div>
</template>

<script>
import { defineComponent, ref } from 'vue';

export default defineComponent({
  setup() {
    const nowIndex = ref(0);
    const stepsData = ref([
      {
        label: '\u57FA\u7840\u4FE1\u606F',
      },
      {
        label: '\u5173\u8054\u6570\u636E\u6E90',
      },
      {
        label: '\u6388\u6743\u4EBA\u5458',
      },
      {
        label: '\u6838\u5BF9\u4FE1\u606F',
      },
    ]);
    const goNext = () => {
      if (nowIndex.value >= stepsData.value.length - 1) return;
      nowIndex.value++;
    };
    const goPrev = () => {
      if (nowIndex.value <= 0) return;
      nowIndex.value--;
    };
    return {
      nowIndex,
      stepsData,
      goNext,
      goPrev,
    };
  },
});
<\/script>
<style>
.box {
  display: flex;
  justify-content: flex-end;
  margin: 10px;
  button {
    margin-left: 10px;
  }
}
</style>
`},{description:k(()=>[w]),highlight:k(()=>[I]),default:k(()=>[F(p)]),_:1}),N])}var j=B(b,[["render",z]]);export{$ as __pageData,j as default};
